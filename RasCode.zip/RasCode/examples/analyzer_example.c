/*
 * analyzer_example.c - Using RasCode's Intelligent Features
 * 
 * This example demonstrates how to use the analyzer API
 * for code completion, error prediction, and optimization hints
 * 
 * Compile:
 *   gcc -std=c99 -I../include analyzer_example.c ../src/analyzer.c \
 *       ../src/lexer.c ../src/parser.c ../src/ast.c ../src/common.c \
 *       -o analyzer_example
 * 
 * Run:
 *   ./analyzer_example
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/analyzer.h"
#include "../include/lexer.h"
#include "../include/parser.h"
#include "../include/ast.h"

// ============================================
// Example 1: Code Completion
// ============================================

void example_code_completion(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 1: Smart Code Completion                    ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    // Simulate user typing different prefixes
    const char *prefixes[] = {
        "lo",        // loop, show
        "if",        // if
        "wh",        // while
        "@",         // built-in functions
        "gr",        // group
        "ar",        // arr
    };
    
    int num_prefixes = sizeof(prefixes) / sizeof(prefixes[0]);
    
    for (int i = 0; i < num_prefixes; i++) {
        printf("User typed: \"%s\"\n", prefixes[i]);
        printf("─────────────────────────────────────\n");
        
        // Get completions for this prefix
        CompletionList *completions = analyzer_get_completions(
            prefixes[i],
            NULL,  // No scope context needed for basics
            0, 0
        );
        
        // Display suggestions
        char *formatted = analyzer_format_completions(completions);
        printf("%s", formatted);
        
        // Cleanup
        free(formatted);
        completion_list_free(completions);
    }
}

// ============================================
// Example 2: Error Prediction with Sample AST
// ============================================

void example_error_prediction(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 2: Error Prediction                         ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    printf("Analyzing code for potential errors...\n");
    printf("─────────────────────────────────────\n\n");
    
    // To properly test this, we would parse actual RasLang code
    // For now, demonstrate the API
    
    // Build sample AST (simplified)
    ASTNode *program = ast_node_new(AST_PROGRAM);
    if (!program) {
        printf("Failed to create AST node\n");
        return;
    }
    
    // Initialize program members
    program->program.imports = NULL;
    program->program.constants = NULL;
    program->program.groups = NULL;
    program->program.functions = NULL;
    
    // Predict errors
    PredictionList *errors = analyzer_predict_errors(program);
    
    if (errors->count == 0) {
        printf("✓ No errors predicted in this code sample\n\n");
    } else {
        char *formatted = analyzer_format_predictions(errors);
        printf("%s", formatted);
        free(formatted);
    }
    
    // Cleanup
    prediction_list_free(errors);
    ast_node_free(program);
}

// ============================================
// Example 3: Performance Hints
// ============================================

void example_performance_hints(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 3: Performance Optimization Hints            ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    printf("Scanning for performance improvement opportunities...\n");
    printf("─────────────────────────────────────\n\n");
    
    // Sample program
    ASTNode *program = ast_node_new(AST_PROGRAM);
    
    program->program.imports = NULL;
    program->program.constants = NULL;
    program->program.groups = NULL;
    program->program.functions = NULL;
    
    // Get hints
    HintList *hints = analyzer_get_performance_hints(program);
    
    if (hints->count == 0) {
        printf("✓ Code is optimized! No specific hints at this stage.\n");
        printf("  (Full analysis requires deeper AST inspection)\n\n");
    } else {
        char *formatted = analyzer_format_hints(hints);
        printf("%s", formatted);
        free(formatted);
    }
    
    hint_list_free(hints);
    ast_node_free(program);
}

// ============================================
// Example 4: Type Inference
// ============================================

void example_type_inference(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 4: Type Inference                           ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    printf("Type Inference Examples:\n");
    printf("─────────────────────────────────────\n\n");
    
    // Create expression nodes for testing
    ASTNode *expr1 = ast_node_new(AST_LITERAL);
    ASTNode *expr2 = ast_node_new(AST_LITERAL);
    
    // Infer types
    TypeInfo *type1 = analyzer_infer_type(expr1, NULL);
    TypeInfo *type2 = analyzer_infer_type(expr2, NULL);
    
    printf("Inferred type 1: ");
    switch (type1->type) {
        case TYPE_INT:   printf("INT\n"); break;
        case TYPE_DECI:  printf("DECI\n"); break;
        case TYPE_STR:   printf("STR\n"); break;
        case TYPE_BOOL:  printf("BOOL\n"); break;
        default:         printf("UNKNOWN\n"); break;
    }
    
    printf("Inferred type 2: ");
    switch (type2->type) {
        case TYPE_INT:   printf("INT\n"); break;
        case TYPE_DECI:  printf("DECI\n"); break;
        case TYPE_STR:   printf("STR\n"); break;
        case TYPE_BOOL:  printf("BOOL\n"); break;
        default:         printf("UNKNOWN\n"); break;
    }
    
    printf("\nType Compatibility:\n");
    int compatible = analyzer_types_compatible(type1, type2);
    printf("  Type1 ↔ Type2: %s\n", compatible ? "✓ Compatible" : "✗ Incompatible");
    
    // Cleanup
    type_info_free(type1);
    type_info_free(type2);
    ast_node_free(expr1);
    ast_node_free(expr2);
    
    printf("\n");
}

// ============================================
// Example 5: Symbol Table Management
// ============================================

void example_symbol_table(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 5: Symbol Table for Scope Management        ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    printf("Managing variable scopes and symbols...\n");
    printf("─────────────────────────────────────\n\n");
    
    // Create global scope
    SymbolTable *global = symbol_table_new(NULL);
    
    // Add variables to global scope
    TypeInfo *int_type = type_info_new(TYPE_INT);
    TypeInfo *str_type = type_info_new(TYPE_STR);
    
    symbol_table_add(global, "counter", int_type, 10);
    symbol_table_add(global, "name", str_type, 20);
    symbol_table_add(global, "flag", type_info_new(TYPE_BOOL), 30);
    
    printf("Global scope variables:\n");
    for (int i = 0; i < global->count; i++) {
        printf("  - %s (line %d) ", global->symbols[i]->name, global->symbols[i]->line);
        switch (global->symbols[i]->type->type) {
            case TYPE_INT:   printf("[INT]\n"); break;
            case TYPE_STR:   printf("[STR]\n"); break;
            case TYPE_BOOL:  printf("[BOOL]\n"); break;
            default:         printf("[UNKNOWN]\n"); break;
        }
    }
    
    printf("\nLooking up symbols:\n");
    
    Symbol *sym1 = symbol_table_lookup(global, "counter");
    if (sym1) {
        printf("  ✓ Found 'counter' at line %d\n", sym1->line);
    }
    
    Symbol *sym2 = symbol_table_lookup(global, "undefined");
    if (!sym2) {
        printf("  ✗ 'undefined' not found\n");
    }
    
    printf("\nCreating nested scope (function local scope):\n");
    SymbolTable *local = symbol_table_new(global);
    
    symbol_table_add(local, "local_var", type_info_new(TYPE_INT), 50);
    
    printf("  Local scope variables:\n");
    for (int i = 0; i < local->count; i++) {
        printf("    - %s (line %d)\n", local->symbols[i]->name, local->symbols[i]->line);
    }
    
    printf("\nSymbol lookup with scope chain:\n");
    Symbol *sym3 = symbol_table_lookup(local, "counter");  // From parent
    if (sym3) {
        printf("  ✓ Found 'counter' from parent scope (line %d)\n", sym3->line);
    }
    
    Symbol *sym4 = symbol_table_lookup(local, "local_var");  // Local
    if (sym4) {
        printf("  ✓ Found 'local_var' in local scope (line %d)\n", sym4->line);
    }
    
    // Cleanup
    symbol_table_free(local);
    symbol_table_free(global);
    printf("\n");
}

// ============================================
// Example 6: Full Analysis Report
// ============================================

void example_full_analysis(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Example 6: Full Analysis Report                     ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    // Create a minimal program
    ASTNode *program = ast_node_new(AST_PROGRAM);
    
    program->program.imports = NULL;
    program->program.constants = NULL;
    program->program.groups = NULL;
    program->program.functions = NULL;
    
    // Run full analysis
    analyzer_analyze_and_report(program);
    
    ast_node_free(program);
}

// ============================================
// Main
// ============================================

int main(void) {
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   RasCode Intelligent Features - API Examples         ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n");
    
    // Run examples
    example_code_completion();
    example_error_prediction();
    example_performance_hints();
    example_type_inference();
    example_symbol_table();
    example_full_analysis();
    
    printf("\n");
    printf("╔════════════════════════════════════════════════════════╗\n");
    printf("║   Examples Complete                                   ║\n");
    printf("╚════════════════════════════════════════════════════════╝\n\n");
    
    printf("To integrate these in your project:\n");
    printf("1. Include \"analyzer.h\" in your code\n");
    printf("2. Call analyzer functions after parsing\n");
    printf("3. Format and display results\n");
    printf("4. Link with analyzer.c in your build\n\n");
    
    return 0;
}
