global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    mov rax, 85
    push rax            ; var score
    mov rax, [rbp - 8]  ; load score
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 90
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L3
    mov rax, 1
    ; emit value left in rax for cycle expression
    jmp .L2
.L3:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 80
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L4
    mov rax, 2
    ; emit value left in rax for cycle expression
    jmp .L2
.L4:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 70
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L5
    mov rax, 3
    ; emit value left in rax for cycle expression
    jmp .L2
.L5:
    mov rax, 0
    ; emit value left in rax for cycle expression
.L2:
    add rsp, 8          ; clean up cycle value
    push rax            ; var grade
    lea rax, [rel .STR6]
section .data
.STR6: db 0x53, 0x63, 0x6f, 0x72, 0x65, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load score
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR10]
section .data
.STR10: db 0x20, 0x2d, 0x3e, 0x20, 0x47, 0x72, 0x61, 0x64, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L11:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L13
    cmp byte [rsi], 0
    je .L12
    inc rdx
    inc rsi
    jmp .L11
.L13:
    mov rdx, 0          ; truncate to 0 on overflow
.L12:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load grade
    mov rdi, rax
    call print_int_no_newline
    mov rax, 1
    mov rdi, 1
    mov rsi, $newline
    mov rdx, 1
    syscall
    lea rax, [rel .STR14]
section .data
.STR14: db 0x2d, 0x2d, 0x2d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load grade
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 1
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L19
    lea rax, [rel .STR20]
section .data
.STR20: db 0x45, 0x78, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x6e, 0x74, 0x00
section .text
    ; emit value left in rax for cycle expression
    jmp .L18
.L19:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 2
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L21
    lea rax, [rel .STR22]
section .data
.STR22: db 0x47, 0x6f, 0x6f, 0x64, 0x00
section .text
    ; emit value left in rax for cycle expression
    jmp .L18
.L21:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 3
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L23
    lea rax, [rel .STR24]
section .data
.STR24: db 0x41, 0x76, 0x65, 0x72, 0x61, 0x67, 0x65, 0x00
section .text
    ; emit value left in rax for cycle expression
    jmp .L18
.L23:
    lea rax, [rel .STR25]
section .data
.STR25: db 0x50, 0x6f, 0x6f, 0x72, 0x00
section .text
    ; emit value left in rax for cycle expression
.L18:
    add rsp, 8          ; clean up cycle value
    push rax            ; var message
    lea rax, [rel .STR26]
section .data
.STR26: db 0x4d, 0x65, 0x73, 0x73, 0x61, 0x67, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L27:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L29
    cmp byte [rsi], 0
    je .L28
    inc rdx
    inc rsi
    jmp .L27
.L29:
    mov rdx, 0          ; truncate to 0 on overflow
.L28:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    mov rdi, 1
    mov rsi, $newline
    mov rdx, 1
    syscall
    mov rax, [rbp - 24]  ; load message
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L30:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L32
    cmp byte [rsi], 0
    je .L31
    inc rdx
    inc rsi
    jmp .L30
.L32:
    mov rdx, 0          ; truncate to 0 on overflow
.L31:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR33]
section .data
.STR33: db 0x2d, 0x2d, 0x2d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L34:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L36
    cmp byte [rsi], 0
    je .L35
    inc rdx
    inc rsi
    jmp .L34
.L36:
    mov rdx, 0          ; truncate to 0 on overflow
.L35:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 2
    push rax            ; var x
    mov rax, 3
    push rax            ; var y
    mov rax, [rbp - 32]  ; load x
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 1
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L38
    mov rax, [rbp - 40]  ; load y
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 2
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L40
    mov rax, 10
    ; emit value left in rax for cycle expression
    jmp .L39
.L40:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 3
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L41
    mov rax, 20
    ; emit value left in rax for cycle expression
    jmp .L39
.L41:
    mov rax, 0
    ; emit value left in rax for cycle expression
.L39:
    add rsp, 8          ; clean up cycle value
    push rax            ; var inner
    mov rax, [rbp - 48]  ; load inner
    push rax
    mov rax, 100
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_42       ; jump if overflow flag set
    jmp .overflow_done_43
.overflow_42:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_43:
    ; emit value left in rax for cycle expression
    add rsp, 8         ; pop 1 block-local variables
    jmp .L37
.L38:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 2
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L44
    mov rax, [rbp - 40]  ; load y
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 2
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L46
    mov rax, 10
    ; emit value left in rax for cycle expression
    jmp .L45
.L46:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 3
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L47
    mov rax, 20
    ; emit value left in rax for cycle expression
    jmp .L45
.L47:
    mov rax, 0
    ; emit value left in rax for cycle expression
.L45:
    add rsp, 8          ; clean up cycle value
    push rax            ; var inner
    mov rax, [rbp - 48]  ; load inner
    push rax
    mov rax, 200
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_48       ; jump if overflow flag set
    jmp .overflow_done_49
.overflow_48:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_49:
    ; emit value left in rax for cycle expression
    add rsp, 8         ; pop 1 block-local variables
    jmp .L37
.L44:
    mov rax, 999
    ; emit value left in rax for cycle expression
.L37:
    add rsp, 8          ; clean up cycle value
    push rax            ; var result
    lea rax, [rel .STR50]
section .data
.STR50: db 0x4e, 0x65, 0x73, 0x74, 0x65, 0x64, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L51:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L53
    cmp byte [rsi], 0
    je .L52
    inc rdx
    inc rsi
    jmp .L51
.L53:
    mov rdx, 0          ; truncate to 0 on overflow
.L52:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load result
    mov rdi, rax
    call print_int_no_newline
    mov rax, 1
    mov rdi, 1
    mov rsi, $newline
    mov rdx, 1
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 48         ; pop 6 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
