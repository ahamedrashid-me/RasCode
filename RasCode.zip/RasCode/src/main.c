#define _DEFAULT_SOURCE
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <libgen.h>
#include "../include/common.h"
#include "../include/lexer.h"
#include "../include/parser.h"
#include "../include/codegen.h"
#include "../include/assembler.h"
#include "../include/analyzer.h"
#include "../include/optimizer.h"
#include "../include/memory_safety.h"

// SECURITY: Safe process execution to prevent shell injection
// Replaces system() with fork() + execvp()
static int safe_exec(const char *program, const char *arg1, const char *arg2, const char *arg3) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }
    
    if (pid == 0) {
        // Child process
        const char *argv[] = {program, arg1, arg2, arg3, NULL};
        execvp(program, (char * const *)argv);
        // Only reached if execvp fails
        perror("execvp");
        exit(127);
    } else {
        // Parent process - wait for child
        int status;
        waitpid(pid, &status, 0);
        
        if (WIFEXITED(status)) {
            return WEXITSTATUS(status);
        } else if (WIFSIGNALED(status)) {
            fprintf(stderr, "Process terminated by signal %d\n", WTERMSIG(status));
            return 1;
        }
        return 1;
    }
}

// SECURITY: Safe process execution with up to 8 arguments
static int safe_exec_many(const char *program, const char *args[]) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        return 1;
    }
    
    if (pid == 0) {
        // Child process
        execvp(program, (char * const *)args);
        // Only reached if execvp fails
        perror("execvp");
        exit(127);
    } else {
        // Parent process - wait for child
        int status;
        waitpid(pid, &status, 0);
        
        if (WIFEXITED(status)) {
            return WEXITSTATUS(status);
        } else if (WIFSIGNALED(status)) {
            fprintf(stderr, "Process terminated by signal %d\n", WTERMSIG(status));
            return 1;
        }
        return 1;
    }
}

// Find bundled NASM executable in the tools directory
__attribute__((unused))
static char *find_bundled_nasm(const char *argv0) {
    (void)argv0;  // Unused - we rely on system NASM
    return NULL;  // Simplified: use system NASM only
}

// Find runtime/sync.o relative to the compiler executable location
static char *find_runtime_sync_o(const char *argv0) {
    (void)argv0;  // Mark parameter as intentionally unused
    static char sync_o_path[2048];
    char exe_path[2048];
    char dir[2048];
    ssize_t len;
    char *last_slash;
    
    // First, try to use /proc/self/exe to get executable path
    len = readlink("/proc/self/exe", exe_path, sizeof(exe_path) - 1);
    if (len > 0) {
        exe_path[len] = '\0';
        
        // Extract directory name manually (without dirname to avoid FORTIFY issues)
        last_slash = strrchr(exe_path, '/');
        if (last_slash) {
            strncpy(dir, exe_path, last_slash - exe_path);
            dir[last_slash - exe_path] = '\0';
            
            // Check if ./runtime/sync.o exists (same directory as binary)
            snprintf(sync_o_path, sizeof(sync_o_path), "%s/runtime/sync.o", dir);
            if (access(sync_o_path, F_OK) == 0) {
                return sync_o_path;
            }
        }
    }
    
    // Fallback: try relative to current directory
    if (access("runtime/sync.o", F_OK) == 0) {
        return "runtime/sync.o";
    }
    
    // Last resort: absolute path for system installation
    if (access("/usr/local/lib/RasCode/runtime/sync.o", F_OK) == 0) {
        return "/usr/local/lib/RasCode/runtime/sync.o";
    }
    if (access("/usr/lib/RasCode/runtime/sync.o", F_OK) == 0) {
        return "/usr/lib/RasCode/runtime/sync.o";
    }
    
    // If nothing found, return the default relative path and let linker fail with clear error
    return "runtime/sync.o";
}

// Find all runtime object files and build linker arguments
__attribute__((unused))
static void build_runtime_objects(const char *argv0, char *runtime_objs, size_t maxlen) {
    const char *sync_o = find_runtime_sync_o(argv0);
    
    // Build string with all runtime object files
    snprintf(runtime_objs, maxlen, "%s", sync_o);
    
    // Get directory for all runtime files
    char sync_copy[2048];
    strncpy(sync_copy, sync_o, sizeof(sync_copy) - 1);
    char *last_slash = strrchr(sync_copy, '/');
    char runtime_dir[2048] = "runtime";
    
    if (last_slash) {
        *last_slash = '\0';
        strncpy(runtime_dir, sync_copy, sizeof(runtime_dir) - 1);
    }
    
    // List of all runtime modules
    const char *modules[] = {
        "channels.o",
        "threadpool.o", 
        "network.o",
        "fileio.o",
        "memmap.o",
        "hardware.o",
        "advanced.o",
        "strings.o",
        "math.o",
        "errors.o",
        "process.o",
        "concurrency.o",
        "time.o",
        "sorting.o",
        NULL
    };
    
    // Add each module if it exists
    for (int i = 0; modules[i]; i++) {
        char module_path[2048];
        snprintf(module_path, sizeof(module_path), "%s/%s", runtime_dir, modules[i]);
        
        if (access(module_path, F_OK) == 0) {
            strncat(runtime_objs, " ", maxlen - strlen(runtime_objs) - 1);
            strncat(runtime_objs, module_path, maxlen - strlen(runtime_objs) - 1);
        }
    }
}

static char *read_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Failed to open file: %s\n", filename);
        return NULL;
    }
    
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    // SECURITY: Prevent reading extremely large files (DoS protection)
    // Maximum file size: 10MB
    const long MAX_FILE_SIZE = 10 * 1024 * 1024;
    
    if (size < 0) {
        fprintf(stderr, "Error: Could not determine file size: %s\n", filename);
        fclose(file);
        return NULL;
    }
    
    if (size > MAX_FILE_SIZE) {
        fprintf(stderr, "Error: File too large (%ld bytes). Maximum allowed size is %ld bytes.\n", 
                size, MAX_FILE_SIZE);
        fclose(file);
        return NULL;
    }
    
    if (size == 0) {
        fprintf(stderr, "Error: Input file is empty\n");
        fclose(file);
        return NULL;
    }
    
    char *buffer = xmalloc(size + 1);
    size_t bytes_read = fread(buffer, 1, size, file);
    
    // SECURITY: Verify that all bytes were read successfully
    if (bytes_read != (size_t)size) {
        fprintf(stderr, "Error: Failed to read file completely. Expected %ld bytes, got %zu bytes.\n", 
                size, bytes_read);
        free(buffer);
        fclose(file);
        return NULL;
    }
    
    buffer[size] = '\0';
    
    if (fclose(file) != 0) {
        fprintf(stderr, "Warning: Could not properly close file: %s\n", filename);
    }
    
    return buffer;
}

static void print_usage(const char *prog) {
    (void)prog;  // Mark parameter as intentionally unused
    fprintf(stderr, "RasCode Compiler (rascom) v%s\n", RASCODE_VERSION);
    fprintf(stderr, "Target: %s\n\n", RASCODE_TARGET);
    fprintf(stderr, "Usage: rascom <inputras> [-o <output>] [FLAGS]\n");
    fprintf(stderr, "\nQuick Start:\n");
    fprintf(stderr, "  rascom exampleras   # Compile a RasCode file\n");
    fprintf(stderr, "\nOptions:\n");
    fprintf(stderr, "  -o <file>    Specify output executable (default: a.out)\n");
    fprintf(stderr, "  -h, --help   Show this help message\n");
    fprintf(stderr, "  -v, --version Show version information\n");
    fprintf(stderr, "\nOptimization Flags:\n");
    fprintf(stderr, "  -O0          No optimization (default for debugging)\n");
    fprintf(stderr, "  -O1          Basic optimization (constant folding, dead code elimination)\n");
    fprintf(stderr, "  -O2          Medium optimization (loop optimizations, inlining)\n");
    fprintf(stderr, "  -O3          Aggressive optimization (register allocation, vectorization)\n");
    fprintf(stderr, "  -O           Alias for -O1 (default optimization level)\n");
    fprintf(stderr, "\nWarning Flags (PRIORITY 1.3):\n");
    fprintf(stderr, "  -Wall        Enable all common warnings\n");
    fprintf(stderr, "  -Wextra      Enable extra warnings (implies -Wall)\n");
    fprintf(stderr, "  -Werror      Treat warnings as errors\n");
    fprintf(stderr, "  -Wpedantic   Enable pedantic warnings\n");
    fprintf(stderr, "  -Wno-unused  Disable unused variable warnings\n");
    fprintf(stderr, "\nRuntime Safety Flags (PRIORITY 2):\n");
    fprintf(stderr, "  -foverflow-check  Detect signed integer overflow in add/sub/mul\n");
    fprintf(stderr, "  -fbounds-check    Enable array bounds checking (default: ON)\n");
    fprintf(stderr, "  -fno-bounds-check Disable array bounds checking (performance)\n");
    fprintf(stderr, "  -fstack-check     Enable recursion depth checking (default: ON)\n");
    fprintf(stderr, "  -fno-stack-check  Disable recursion limit warnings (risky)\n");
}

static void print_version(void) {
    fprintf(stderr, "RasCode Compiler (rascom) v%s\n", RASCODE_VERSION);
    fprintf(stderr, "Target: %s\n", RASCODE_TARGET);
    fprintf(stderr, "Assembler: NASM + GCC (system tools)\n");
    fprintf(stderr, "Fallback: Built-in RasCode Assembler\n");
    fprintf(stderr, "Developer: Developed by ahamedrashid.me@gmail.com\n");
    fprintf(stderr, "And & SOS ecosystem\n");
    
}


static int compile_asm_to_binary(const char *asm_file, const char *output_file, const char *argv0) {
    // ============================================================================
    // Assembly Pipeline: System NASM (1st) -> RasCode rasm (2nd)
    // ============================================================================
    // This function assembles x86-64 code using available tools
    // Priority: NASM -> Internal assembler -> rasm
    // ============================================================================
    
    (void)argv0;  // Not needed for system tools
    int ret;
    
    // PRIMARY: Try system NASM (standard assembler)
    if (access("/usr/bin/nasm", X_OK) == 0 || access("/bin/nasm", X_OK) == 0) {
        fprintf(stderr, "  [NASM] Using system NASM assembler\n");
        
        char obj_file[256];
        snprintf(obj_file, sizeof(obj_file), "%s.o", output_file);
        
        const char *nasm_args[] = {"nasm", "-f", "elf64", asm_file, "-o", obj_file, NULL};
        ret = safe_exec_many("nasm", nasm_args);
        
        if (ret == 0) {
            fprintf(stderr, "  [LD] Linking object file...\n");
            const char *gcc_args[] = {
                "gcc", "-nostartfiles", "-no-pie", "-o", output_file, obj_file, NULL
            };
            ret = safe_exec_many("gcc", gcc_args);
            unlink(obj_file);
            
            if (ret == 0) {
                fprintf(stderr, "  [NASM] SUCCESS: Generated %s\n", output_file);
                return 0;
            }
        }
        fprintf(stderr, "  [NASM] Failed, trying fallbacks...\n");
    }
    
    // SECONDARY: Use internal RasCode assembler
    fprintf(stderr, "  [RasCode Assembler] Fallback: Using built-in assembler\n");
    Assembler *rasm = asm_new();
    if (!rasm) {
        fprintf(stderr, "Error: Failed to create assembler\n");
        return 1;
    }
    
    ret = asm_assemble_file(rasm, asm_file, output_file);
    asm_print_stats(rasm);
    asm_free(rasm);
    
    if (ret == 0 && access(output_file, F_OK) == 0) {
        fprintf(stderr, "  [RasCode Assembler] SUCCESS: Generated %s (self-contained)\n", output_file);
        return 0;
    }
    
    fprintf(stderr, "  [RasCode Assembler] Failed, trying fallbacks...\n");
    
    // TERTIARY FALLBACK: RASM (if available)
    const char *rasm_paths[] = {
        "./SUASM_V2_COMPLETE.bin", "../build/SUASM_V2_COMPLETE.bin",
        "./build/SUASM_V2_COMPLETE.bin", "/usr/local/bin/RasCode_suasm",
        "/usr/bin/RasCode_suasm", "SUASM_V2_COMPLETE", "RasCode_suasm"
    };
    
    for (size_t i = 0; i < sizeof(rasm_paths) / sizeof(rasm_paths[0]); i++) {
        if (access(rasm_paths[i], X_OK) == 0) {
            fprintf(stderr, "  [RASM] Fallback: Using %s\n", rasm_paths[i]);
            ret = safe_exec(rasm_paths[i], asm_file, "-o", output_file);
            if (ret == 0 && access(output_file, F_OK) == 0) {
                fprintf(stderr, "  [RASM] SUCCESS: Generated %s\n", output_file);
                return 0;
            }
        }
    }
    
    // All methods failed
    fprintf(stderr, "Error: All assembly methods failed\n");
    fprintf(stderr, "Tried: NASM (system), RasCode assembler RASM (built-in)\n");
    fprintf(stderr, "\nPlease install NASM:\n");
    fprintf(stderr, "  apt install nasm          # Ubuntu/Debian\n");
    fprintf(stderr, "  dnf install nasm          # Fedora/RHEL\n");
    fprintf(stderr, "  brew install nasm         # macOS\n");
    fprintf(stderr, "  pacman -S nasm            # Arch Linux\n");
    return 1;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }
    
    // Parse command line arguments
    char *input_file = NULL;
    char *output_file = "a.out";
    int optimization_level = 1;  // Default: -O1 (basic optimization)
    
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            return 0;
        } else if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--version") == 0) {
            print_version();
            return 0;
        } else if (strcmp(argv[i], "-o") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: -o requires an argument\n");
                return 1;
            }
            output_file = argv[++i];
        } else if (strncmp(argv[i], "-W", 2) == 0) {
            // Warning flag - will be processed by analyzer
            // Just validate that it's a known flag
            const char *flag = argv[i];
            if (strcmp(flag, "-Wall") == 0 || strcmp(flag, "-Wextra") == 0 ||
                strcmp(flag, "-Werror") == 0 || strcmp(flag, "-Wpedantic") == 0 ||
                strcmp(flag, "-Wno-unused") == 0 || strcmp(flag, "-Wno-shadowing") == 0) {
                // Valid warning flag, will be processed after creating analyzer
                continue;
            } else {
                fprintf(stderr, "Warning: Unknown warning flag: %s\n", flag);
            }
        } else if (strcmp(argv[i], "-foverflow-check") == 0) {
            // Enable overflow detection (PRIORITY 2.1)
            g_overflow_check_enabled = 1;
            continue;
        } else if (strcmp(argv[i], "-fbounds-check") == 0) {
            // Enable bounds checking (PRIORITY 2.2, default behavior)
            g_bounds_check_enabled = 1;
            continue;
        } else if (strcmp(argv[i], "-fno-bounds-check") == 0) {
            // Disable bounds checking for performance (PRIORITY 2.2)
            g_bounds_check_enabled = 0;
            continue;
        } else if (strcmp(argv[i], "-fstack-check") == 0) {
            // Enable stack checking (PRIORITY 2.3, default behavior)
            g_stack_check_enabled = 1;
            continue;
        } else if (strcmp(argv[i], "-fno-stack-check") == 0) {
            // Disable stack checking (risky, for advanced users)
            g_stack_check_enabled = 0;
            continue;
        } else if (strncmp(argv[i], "-O", 2) == 0) {
            // Optimization level flag: -O0, -O1, -O2, -O3
            if (strlen(argv[i]) == 3 && argv[i][2] >= '0' && argv[i][2] <= '3') {
                optimization_level = argv[i][2] - '0';
                continue;
            } else if (strcmp(argv[i], "-O") == 0) {
                optimization_level = 1;  // -O defaults to -O1
                continue;
            } else {
                fprintf(stderr, "Warning: Unknown optimization flag: %s\n", argv[i]);
            }
        } else if (argv[i][0] != '-') {
            input_file = argv[i];
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 1;
        }
    }
    
    if (!input_file) {
        fprintf(stderr, "Error: No input file specified\n");
        print_usage(argv[0]);
        return 1;
    }
    
    // Validate .ras extension
    int filename_len = strlen(input_file);
    if (filename_len < 5 || strcmp(input_file + filename_len - 4, ".ras") != 0) {
        fprintf(stderr, "Error: Input file must have .ras extension\n");
        fprintf(stderr, "Usage: rascom <input.ras> [-o <output>]\n");
        return 1;
    }
    
    // SAFETY: Initialize mandatory memory safety layer
    // This must be done before any allocation occurs
    memory_safety_init(true);
    
    // Read source file
    char *source = read_file(input_file);
    if (!source) {
        return 1;
    }
    
    printf("Compiling %s...\n", input_file);
    
    // Lexical analysis
    printf("  [1/4] Lexical analysis...\n");
    Lexer *lexer = lexer_new(source);
    
    // Parsing
    printf("  [1.5/4] Parsing...\n");
    Parser *parser = parser_new(lexer);
    ASTNode *ast = parser_parse(parser);
    
    // Apply warning flags (Priority 1.3)
    analyzer_set_warning_flags(argc, argv);
    
    // Intelligent code analysis
    printf("  [2/4] Intelligent analysis...\n");
    analyzer_analyze_and_report(ast);
    
    // Optimization passes
    if (optimization_level > 0) {
        printf("  [2.5/4] Code optimization (-O%d)...\n", optimization_level);
        OptimizerContext *optimizer = optimizer_new(optimization_level);
        ast = optimize_ast(optimizer, ast);
        optimizer_print_stats(optimizer);
        optimizer_free(optimizer);
    }
    
    // Code generation
    printf("  [3/4] Code generation...\n");
    char asm_file[256];
    snprintf(asm_file, sizeof(asm_file), "%s.asm", input_file);
    
    CodeGen *codegen = codegen_new(asm_file);
    if (!codegen) {
        return 1;
    }
    
    codegen_generate(codegen, ast);
    codegen_free(codegen);
    
    // Assemble and link
    printf("  [3.5/4] Assembly and linking...\n");
    int ret = compile_asm_to_binary(asm_file, output_file, argv[0]);
    
    if (ret == 0) {
        printf("Compilation successful: %s\n", output_file);
        // Clean up assembly file
        // unlink(asm_file);  // Keep for debugging
    }
    
    // Cleanup
    ast_node_free(ast);
    parser_free(parser);
    lexer_free(lexer);
    free(source);
    
    return ret;
}
