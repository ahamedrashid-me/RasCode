#include "../include/packages.h"
#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>

/* SECURITY: Maximum path length to prevent stack overflow */
#define MAX_PACKAGE_PATH 4096

/* SECURITY: Validate package names to prevent directory traversal attacks */
static bool is_valid_package_name(const char *name) {
    if (!name || *name == '\0') {
        return false;
    }
    
    /* Reject directory traversal attempts */
    if (strstr(name, "..") != NULL) {
        return false;
    }
    
    /* Reject absolute paths */
    if (name[0] == '/') {
        return false;
    }
    
    /* Reject backslashes (Windows path separator) */
    if (strchr(name, '\\') != NULL) {
        return false;
    }
    
    /* Only allow alphanumeric, underscore, hyphen, and forward slash for subdirs */
    for (int i = 0; name[i]; i++) {
        if (!isalnum((unsigned char)name[i]) && 
            name[i] != '_' && 
            name[i] != '-' && 
            name[i] != '/') {
            return false;
        }
    }
    
    return true;
}

// Create a new package manager
PackageManager *pkg_manager_new(void) {
    PackageManager *mgr = xmalloc(sizeof(PackageManager));
    mgr->num_paths = 0;
    mgr->loaded_packages = NULL;
    mgr->num_loaded = 0;
    mgr->capacity = 0;
    
    // Add default search paths
    pkg_manager_add_search_path(mgr, ".");           // Current directory
    pkg_manager_add_search_path(mgr, "./lib");       // Local lib directory
    pkg_manager_add_search_path(mgr, "./packages");  // Local packages directory
    
    // Check for system-wide package directory
    char *home = getenv("HOME");
    if (home) {
        char path[512];
        snprintf(path, sizeof(path), "%s/.supercode/packages", home);
        pkg_manager_add_search_path(mgr, path);
    }
    
    // System-wide installation
    pkg_manager_add_search_path(mgr, "/usr/local/lib/supercode");
    pkg_manager_add_search_path(mgr, "/usr/lib/supercode");
    
    return mgr;
}

// Free package manager
void pkg_manager_free(PackageManager *mgr) {
    if (!mgr) return;
    
    // Free search paths
    for (int i = 0; i < mgr->num_paths; i++) {
        free(mgr->search_paths[i]);
    }
    
    // Free loaded packages
    for (int i = 0; i < mgr->num_loaded; i++) {
        package_free(mgr->loaded_packages[i]);
    }
    free(mgr->loaded_packages);
    
    free(mgr);
}

// Add a search path
void pkg_manager_add_search_path(PackageManager *mgr, const char *path) {
    if (mgr->num_paths >= PKG_MAX_PATHS) {
        fprintf(stderr, "Warning: Maximum package search paths reached\n");
        return;
    }
    
    mgr->search_paths[mgr->num_paths++] = xstrdup(path);
}

// Check if file exists
static bool file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

// Find package file in search paths
char *pkg_find_file(PackageManager *mgr, const char *package_name) {
    /* SECURITY: Validate package name to prevent path traversal */
    if (!is_valid_package_name(package_name)) {
        fprintf(stderr, "Error: Invalid package name '%s'. Names can only contain alphanumeric characters, underscores, hyphens, and forward slashes.\n", 
                package_name);
        return NULL;
    }
    
    /* Allocate path buffer dynamically instead of fixed-size stack buffer */
    char *path = xmalloc(MAX_PACKAGE_PATH);
    
    // Try each search path
    for (int i = 0; i < mgr->num_paths; i++) {
        // Try .ras file first
        int written = snprintf(path, MAX_PACKAGE_PATH, "%s/%s.ras", mgr->search_paths[i], package_name);
        if (written < 0 || written >= MAX_PACKAGE_PATH) {
            fprintf(stderr, "Error: Package path too long for '%s' in directory '%s'\n", 
                    package_name, mgr->search_paths[i]);
            free(path);
            return NULL;
        }
        if (file_exists(path)) {
            char *result = xstrdup(path);
            free(path);
            return result;
        }
        
        // Try .raslib file (compiled library)
        written = snprintf(path, MAX_PACKAGE_PATH, "%s/%s.raslib", mgr->search_paths[i], package_name);
        if (written < 0 || written >= MAX_PACKAGE_PATH) {
            fprintf(stderr, "Error: Package path too long for '%s' in directory '%s'\n", 
                    package_name, mgr->search_paths[i]);
            free(path);
            return NULL;
        }
        if (file_exists(path)) {
            char *result = xstrdup(path);
            free(path);
            return result;
        }
        
        // Try as subdirectory with main.ras
        written = snprintf(path, MAX_PACKAGE_PATH, "%s/%s/main.ras", mgr->search_paths[i], package_name);
        if (written < 0 || written >= MAX_PACKAGE_PATH) {
            fprintf(stderr, "Error: Package path too long for '%s' in directory '%s'\n", 
                    package_name, mgr->search_paths[i]);
            free(path);
            return NULL;
        }
        if (file_exists(path)) {
            char *result = xstrdup(path);
            free(path);
            return result;
        }
    }
    
    free(path);
    return NULL;
}

// Find already loaded package
Package *pkg_manager_find_loaded(PackageManager *mgr, const char *package_name) {
    for (int i = 0; i < mgr->num_loaded; i++) {
        if (strcmp(mgr->loaded_packages[i]->name, package_name) == 0) {
            return mgr->loaded_packages[i];
        }
    }
    return NULL;
}

// Load a package
Package *pkg_manager_load(PackageManager *mgr, const char *package_name) {
    // Check if already loaded
    Package *existing = pkg_manager_find_loaded(mgr, package_name);
    if (existing) {
        return existing;
    }
    
    // Find package file
    char *file_path = pkg_find_file(mgr, package_name);
    if (!file_path) {
        fprintf(stderr, "Error: Package '%s' not found in search paths:\n", package_name);
        for (int i = 0; i < mgr->num_paths; i++) {
            fprintf(stderr, "  - %s\n", mgr->search_paths[i]);
        }
        return NULL;
    }
    
    // Determine if compiled or source
    bool is_compiled = false;
    size_t len = strlen(file_path);
    if (len > 6 && strcmp(file_path + len - 6, ".sulib") == 0) {
        is_compiled = true;
    }
    
    // Create package object
    Package *pkg = package_new(package_name, file_path, is_compiled);
    free(file_path);
    
    // Add to loaded packages
    if (mgr->num_loaded >= mgr->capacity) {
        mgr->capacity = mgr->capacity == 0 ? 8 : mgr->capacity * 2;
        mgr->loaded_packages = xrealloc(mgr->loaded_packages, 
                                       sizeof(Package*) * mgr->capacity);
    }
    mgr->loaded_packages[mgr->num_loaded++] = pkg;
    
    return pkg;
}

// Create new package
Package *package_new(const char *name, const char *file_path, bool is_compiled) {
    Package *pkg = xmalloc(sizeof(Package));
    pkg->name = xstrdup(name);
    pkg->file_path = xstrdup(file_path);
    pkg->is_compiled = is_compiled;
    pkg->ast = NULL;
    return pkg;
}

// Free package
void package_free(Package *pkg) {
    if (!pkg) return;
    
    free(pkg->name);
    free(pkg->file_path);
    ast_node_free(pkg->ast);
    free(pkg);
}
