global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x4d, 0x45, 0x4d, 0x4f, 0x52, 0x59, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x5b, 0x36, 0x34, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 64
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_10
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_10
.alloc_fail_10:
    xor rax, rax        ; return 0 on failure
.alloc_done_10:
    push rax            ; var ptr1
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L11
    lea rax, [rel .STR13]
section .data
.STR13: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x41, 0x6c, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x65, 0x64, 0x20, 0x70, 0x6f, 0x69, 0x6e, 0x74, 0x65, 0x72, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L14:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L16
    cmp byte [rsi], 0
    je .L15
    inc rdx
    inc rsi
    jmp .L14
.L16:
    mov rdx, 0          ; truncate to 0 on overflow
.L15:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L12
.L11:
    lea rax, [rel .STR17]
section .data
.STR17: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L18:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L20
    cmp byte [rsi], 0
    je .L19
    inc rdx
    inc rsi
    jmp .L18
.L20:
    mov rdx, 0          ; truncate to 0 on overflow
.L19:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L12:
    lea rax, [rel .STR21]
section .data
.STR21: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x6f, 0x6b, 0x65, 0x20, 0x61, 0x6e, 0x64, 0x20, 0x40, 0x70, 0x65, 0x65, 0x6b, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L22:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L24
    cmp byte [rsi], 0
    je .L23
    inc rdx
    inc rsi
    jmp .L22
.L24:
    mov rdx, 0          ; truncate to 0 on overflow
.L23:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @poke
    mov rax, [rbp - 24]  ; load ptr1
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 42
    ; @poke is now a no-op for security
    ; Builtin function @peek
    mov rax, [rbp - 24]  ; load ptr1
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var readval
    mov rax, [rbp - 32]  ; load readval
    push rax
    mov rax, 42
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L25
    lea rax, [rel .STR27]
section .data
.STR27: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L28:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L30
    cmp byte [rsi], 0
    je .L29
    inc rdx
    inc rsi
    jmp .L28
.L30:
    mov rdx, 0          ; truncate to 0 on overflow
.L29:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR31]
section .data
.STR31: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x70, 0x6f, 0x6b, 0x65, 0x2f, 0x40, 0x70, 0x65, 0x65, 0x6b, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L26
.L25:
    lea rax, [rel .STR35]
section .data
.STR35: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x70, 0x6f, 0x6b, 0x65, 0x2f, 0x40, 0x70, 0x65, 0x65, 0x6b, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR39]
section .data
.STR39: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L40:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L42
    cmp byte [rsi], 0
    je .L41
    inc rdx
    inc rsi
    jmp .L40
.L42:
    mov rdx, 0          ; truncate to 0 on overflow
.L41:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L26:
    lea rax, [rel .STR43]
section .data
.STR43: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x6f, 0x6b, 0x65, 0x20, 0x61, 0x74, 0x20, 0x6f, 0x66, 0x66, 0x73, 0x65, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @poke
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 100
    ; @poke is now a no-op for security
    ; Builtin function @peek
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var readval2
    mov rax, [rbp - 40]  ; load readval2
    push rax
    mov rax, 100
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L47
    lea rax, [rel .STR49]
section .data
.STR49: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L50:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L52
    cmp byte [rsi], 0
    je .L51
    inc rdx
    inc rsi
    jmp .L50
.L52:
    mov rdx, 0          ; truncate to 0 on overflow
.L51:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR53]
section .data
.STR53: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x4f, 0x66, 0x66, 0x73, 0x65, 0x74, 0x20, 0x77, 0x72, 0x69, 0x74, 0x65, 0x2f, 0x72, 0x65, 0x61, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L54:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L56
    cmp byte [rsi], 0
    je .L55
    inc rdx
    inc rsi
    jmp .L54
.L56:
    mov rdx, 0          ; truncate to 0 on overflow
.L55:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L48
.L47:
    lea rax, [rel .STR57]
section .data
.STR57: db 0xe2, 0x9c, 0x97, 0x20, 0x4f, 0x66, 0x66, 0x73, 0x65, 0x74, 0x20, 0x77, 0x72, 0x69, 0x74, 0x65, 0x2f, 0x72, 0x65, 0x61, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L58:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L60
    cmp byte [rsi], 0
    je .L59
    inc rdx
    inc rsi
    jmp .L58
.L60:
    mov rdx, 0          ; truncate to 0 on overflow
.L59:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L48:
    lea rax, [rel .STR61]
section .data
.STR61: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x73, 0x65, 0x74, 0x5b, 0x70, 0x74, 0x72, 0x2c, 0x20, 0x30, 0x2c, 0x20, 0x31, 0x36, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L62:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L64
    cmp byte [rsi], 0
    je .L63
    inc rdx
    inc rsi
    jmp .L62
.L64:
    mov rdx, 0          ; truncate to 0 on overflow
.L63:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @memset
    mov rax, [rbp - 24]  ; load ptr1
    push rax            ; save ptr
    mov rax, 0
    push rax            ; save value
    mov rax, 16
    mov rcx, rax        ; count
    pop rax             ; restore value
    pop rdi             ; restore ptr
    rep stosb           ; fill memory
    ; Builtin function @peek
    mov rax, [rbp - 24]  ; load ptr1
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var check1
    ; Builtin function @peek
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var check2
    mov rax, [rbp - 48]  ; load check1
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L65
    lea rax, [rel .STR67]
section .data
.STR67: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x63, 0x6c, 0x65, 0x61, 0x72, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x73, 0x65, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L68:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L70
    cmp byte [rsi], 0
    je .L69
    inc rdx
    inc rsi
    jmp .L68
.L70:
    mov rdx, 0          ; truncate to 0 on overflow
.L69:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L66
.L65:
    lea rax, [rel .STR71]
section .data
.STR71: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x73, 0x65, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L72:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L74
    cmp byte [rsi], 0
    je .L73
    inc rdx
    inc rsi
    jmp .L72
.L74:
    mov rdx, 0          ; truncate to 0 on overflow
.L73:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L66:
    lea rax, [rel .STR75]
section .data
.STR75: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x70, 0x79, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L76:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L78
    cmp byte [rsi], 0
    je .L77
    inc rdx
    inc rsi
    jmp .L76
.L78:
    mov rdx, 0          ; truncate to 0 on overflow
.L77:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 64
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_79
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_79
.alloc_fail_79:
    xor rax, rax        ; return 0 on failure
.alloc_done_79:
    push rax            ; var ptr2
    ; Builtin function @poke
    mov rax, [rbp - 24]  ; load ptr1
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 55
    ; @poke is now a no-op for security
    ; Builtin function @poke
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 66
    ; @poke is now a no-op for security
    ; Builtin function @memcpy
    mov rax, [rbp - 64]  ; load ptr2
    push rax
    mov rax, [rbp - 24]  ; load ptr1
    push rax
    mov rax, 16
    mov rcx, rax
    pop rsi
    pop rdi
    rep movsb
    ; Builtin function @peek
    mov rax, [rbp - 64]  ; load ptr2
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var check3
    ; Builtin function @peek
    mov rax, [rbp - 64]  ; load ptr2
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var check4
    mov rax, [rbp - 72]  ; load check3
    push rax
    mov rax, 55
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L80
    lea rax, [rel .STR82]
section .data
.STR82: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x63, 0x6f, 0x70, 0x69, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x70, 0x79, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L81
.L80:
    lea rax, [rel .STR86]
section .data
.STR86: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x70, 0x79, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L81:
    lea rax, [rel .STR90]
section .data
.STR90: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x64, 0x64, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L91:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L93
    cmp byte [rsi], 0
    je .L92
    inc rdx
    inc rsi
    jmp .L91
.L93:
    mov rdx, 0          ; truncate to 0 on overflow
.L92:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 123
    push rax            ; var x
    ; Builtin function @addr
    lea rax, [rbp - 88]    ; @addr(x)
    push rax            ; var xaddr
    mov rax, [rbp - 96]  ; load xaddr
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L94
    lea rax, [rel .STR96]
section .data
.STR96: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x47, 0x6f, 0x74, 0x20, 0x61, 0x64, 0x64, 0x72, 0x65, 0x73, 0x73, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x61, 0x64, 0x64, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L97:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L99
    cmp byte [rsi], 0
    je .L98
    inc rdx
    inc rsi
    jmp .L97
.L99:
    mov rdx, 0          ; truncate to 0 on overflow
.L98:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L95
.L94:
    lea rax, [rel .STR100]
section .data
.STR100: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x61, 0x64, 0x64, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L101:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L103
    cmp byte [rsi], 0
    je .L102
    inc rdx
    inc rsi
    jmp .L101
.L103:
    mov rdx, 0          ; truncate to 0 on overflow
.L102:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L95:
    lea rax, [rel .STR104]
section .data
.STR104: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x72, 0x65, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @free
    mov rax, [rbp - 24]  ; load ptr1
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    ; Builtin function @free
    mov rax, [rbp - 64]  ; load ptr2
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    lea rax, [rel .STR108]
section .data
.STR108: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x46, 0x72, 0x65, 0x65, 0x64, 0x20, 0x6d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x66, 0x72, 0x65, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L109:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L111
    cmp byte [rsi], 0
    je .L110
    inc rdx
    inc rsi
    jmp .L109
.L111:
    mov rdx, 0          ; truncate to 0 on overflow
.L110:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR112]
section .data
.STR112: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x4d, 0x45, 0x4d, 0x4f, 0x52, 0x59, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L113:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L115
    cmp byte [rsi], 0
    je .L114
    inc rdx
    inc rsi
    jmp .L113
.L115:
    mov rdx, 0          ; truncate to 0 on overflow
.L114:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR116]
section .data
.STR116: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L117:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L119
    cmp byte [rsi], 0
    je .L118
    inc rdx
    inc rsi
    jmp .L117
.L119:
    mov rdx, 0          ; truncate to 0 on overflow
.L118:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR120]
section .data
.STR120: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L121:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L123
    cmp byte [rsi], 0
    je .L122
    inc rdx
    inc rsi
    jmp .L121
.L123:
    mov rdx, 0          ; truncate to 0 on overflow
.L122:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR124]
section .data
.STR124: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L125:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L127
    cmp byte [rsi], 0
    je .L126
    inc rdx
    inc rsi
    jmp .L125
.L127:
    mov rdx, 0          ; truncate to 0 on overflow
.L126:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR128]
section .data
.STR128: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L129:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L131
    cmp byte [rsi], 0
    je .L130
    inc rdx
    inc rsi
    jmp .L129
.L131:
    mov rdx, 0          ; truncate to 0 on overflow
.L130:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L132
    lea rax, [rel .STR134]
section .data
.STR134: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x4d, 0x45, 0x4d, 0x4f, 0x52, 0x59, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L135:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L137
    cmp byte [rsi], 0
    je .L136
    inc rdx
    inc rsi
    jmp .L135
.L137:
    mov rdx, 0          ; truncate to 0 on overflow
.L136:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L133
.L132:
    lea rax, [rel .STR138]
section .data
.STR138: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L139:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L141
    cmp byte [rsi], 0
    je .L140
    inc rdx
    inc rsi
    jmp .L139
.L141:
    mov rdx, 0          ; truncate to 0 on overflow
.L140:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L133:
    add rsp, 96         ; pop 12 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
