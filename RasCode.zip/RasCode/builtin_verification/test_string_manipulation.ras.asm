global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x53, 0x54, 0x52, 0x49, 0x4e, 0x47, 0x20, 0x4d, 0x41, 0x4e, 0x49, 0x50, 0x55, 0x4c, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x74, 0x72, 0x6c, 0x65, 0x6e, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var len1
    mov rax, [rbp - 24]  ; load len1
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L10
    lea rax, [rel .STR12]
section .data
.STR12: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L13:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L15
    cmp byte [rsi], 0
    je .L14
    inc rdx
    inc rsi
    jmp .L13
.L15:
    mov rdx, 0          ; truncate to 0 on overflow
.L14:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR16]
section .data
.STR16: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x74, 0x72, 0x6c, 0x65, 0x6e, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L17:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L19
    cmp byte [rsi], 0
    je .L18
    inc rdx
    inc rsi
    jmp .L17
.L19:
    mov rdx, 0          ; truncate to 0 on overflow
.L18:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L11
.L10:
    lea rax, [rel .STR20]
section .data
.STR20: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x74, 0x72, 0x6c, 0x65, 0x6e, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L21:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L23
    cmp byte [rsi], 0
    je .L22
    inc rdx
    inc rsi
    jmp .L21
.L23:
    mov rdx, 0          ; truncate to 0 on overflow
.L22:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR24]
section .data
.STR24: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L25:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L27
    cmp byte [rsi], 0
    je .L26
    inc rdx
    inc rsi
    jmp .L25
.L27:
    mov rdx, 0          ; truncate to 0 on overflow
.L26:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L11:
    lea rax, [rel .STR28]
section .data
.STR28: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x5b, 0x22, 0x74, 0x65, 0x73, 0x74, 0x22, 0x2c, 0x20, 0x22, 0x74, 0x65, 0x73, 0x74, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @strcmp
    lea rax, [rel .STR32]
section .data
.STR32: db 0x74, 0x65, 0x73, 0x74, 0x00
section .text
    mov rdi, rax        ; str1
    lea rax, [rel .STR33]
section .data
.STR33: db 0x74, 0x65, 0x73, 0x74, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax            ; var cmp1
    mov rax, [rbp - 32]  ; load cmp1
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L34
    lea rax, [rel .STR36]
section .data
.STR36: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x30, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L35
.L34:
    lea rax, [rel .STR40]
section .data
.STR40: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L41:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L43
    cmp byte [rsi], 0
    je .L42
    inc rdx
    inc rsi
    jmp .L41
.L43:
    mov rdx, 0          ; truncate to 0 on overflow
.L42:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR44]
section .data
.STR44: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L45:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L47
    cmp byte [rsi], 0
    je .L46
    inc rdx
    inc rsi
    jmp .L45
.L47:
    mov rdx, 0          ; truncate to 0 on overflow
.L46:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L35:
    lea rax, [rel .STR48]
section .data
.STR48: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x5b, 0x22, 0x61, 0x70, 0x70, 0x6c, 0x65, 0x22, 0x2c, 0x20, 0x22, 0x62, 0x61, 0x6e, 0x61, 0x6e, 0x61, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L49:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L51
    cmp byte [rsi], 0
    je .L50
    inc rdx
    inc rsi
    jmp .L49
.L51:
    mov rdx, 0          ; truncate to 0 on overflow
.L50:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @strcmp
    lea rax, [rel .STR52]
section .data
.STR52: db 0x61, 0x70, 0x70, 0x6c, 0x65, 0x00
section .text
    mov rdi, rax        ; str1
    lea rax, [rel .STR53]
section .data
.STR53: db 0x62, 0x61, 0x6e, 0x61, 0x6e, 0x61, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax            ; var cmp2
    mov rax, [rbp - 40]  ; load cmp2
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L54
    lea rax, [rel .STR56]
section .data
.STR56: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x6e, 0x6f, 0x6e, 0x2d, 0x7a, 0x65, 0x72, 0x6f, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x65, 0x6e, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L55
.L54:
    lea rax, [rel .STR60]
section .data
.STR60: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x74, 0x72, 0x63, 0x6d, 0x70, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x65, 0x6e, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L55:
    lea rax, [rel .STR64]
section .data
.STR64: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x2c, 0x20, 0x22, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @concat
    lea rax, [rel .STR68]
section .data
.STR68: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    mov r12, rax        ; r12 = str1
    lea rax, [rel .STR69]
section .data
.STR69: db 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    mov r13, rax        ; r13 = str2
    mov rdi, r12
    call strlen
    mov r14, rax        ; r14 = len1
    mov rdi, r13
    call strlen
    mov r15, rax        ; r15 = len2
    lea rdi, [r14 + r15 + 1]  ; total size
    call malloc
    mov rbx, rax        ; rbx = result buffer
    mov rdi, rbx
    mov rsi, r12
    mov rcx, r14
    rep movsb
    mov rsi, r13
    mov rcx, r15
    rep movsb
    mov byte [rdi], 0
    mov rax, rbx        ; return result
    push rax            ; var concat1
    mov rax, [rbp - 48]  ; load concat1
    push rax
    lea rax, [rel .STR72]
section .data
.STR72: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L70
    lea rax, [rel .STR73]
section .data
.STR73: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L74:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L76
    cmp byte [rsi], 0
    je .L75
    inc rdx
    inc rsi
    jmp .L74
.L76:
    mov rdx, 0          ; truncate to 0 on overflow
.L75:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load concat1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR80]
section .data
.STR80: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L81:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L83
    cmp byte [rsi], 0
    je .L82
    inc rdx
    inc rsi
    jmp .L81
.L83:
    mov rdx, 0          ; truncate to 0 on overflow
.L82:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L71
.L70:
    lea rax, [rel .STR84]
section .data
.STR84: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L85:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L87
    cmp byte [rsi], 0
    je .L86
    inc rdx
    inc rsi
    jmp .L85
.L87:
    mov rdx, 0          ; truncate to 0 on overflow
.L86:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load concat1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L88:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L90
    cmp byte [rsi], 0
    je .L89
    inc rdx
    inc rsi
    jmp .L88
.L90:
    mov rdx, 0          ; truncate to 0 on overflow
.L89:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR91]
section .data
.STR91: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L92:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L94
    cmp byte [rsi], 0
    je .L93
    inc rdx
    inc rsi
    jmp .L92
.L94:
    mov rdx, 0          ; truncate to 0 on overflow
.L93:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L71:
    lea rax, [rel .STR95]
section .data
.STR95: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x75, 0x70, 0x70, 0x65, 0x72, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L96:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L98
    cmp byte [rsi], 0
    je .L97
    inc rdx
    inc rsi
    jmp .L96
.L98:
    mov rdx, 0          ; truncate to 0 on overflow
.L97:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @upper
    lea rax, [rel .STR99]
section .data
.STR99: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    push rax        ; arg 0
    mov rax, 153             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var upper1
    mov rax, [rbp - 56]  ; load upper1
    push rax
    lea rax, [rel .STR102]
section .data
.STR102: db 0x48, 0x45, 0x4c, 0x4c, 0x4f, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L100
    lea rax, [rel .STR103]
section .data
.STR103: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L104:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L106
    cmp byte [rsi], 0
    je .L105
    inc rdx
    inc rsi
    jmp .L104
.L106:
    mov rdx, 0          ; truncate to 0 on overflow
.L105:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 56]  ; load upper1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L107:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L109
    cmp byte [rsi], 0
    je .L108
    inc rdx
    inc rsi
    jmp .L107
.L109:
    mov rdx, 0          ; truncate to 0 on overflow
.L108:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR110]
section .data
.STR110: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x75, 0x70, 0x70, 0x65, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L111:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L113
    cmp byte [rsi], 0
    je .L112
    inc rdx
    inc rsi
    jmp .L111
.L113:
    mov rdx, 0          ; truncate to 0 on overflow
.L112:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L101
.L100:
    lea rax, [rel .STR114]
section .data
.STR114: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x75, 0x70, 0x70, 0x65, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L115:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L117
    cmp byte [rsi], 0
    je .L116
    inc rdx
    inc rsi
    jmp .L115
.L117:
    mov rdx, 0          ; truncate to 0 on overflow
.L116:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 56]  ; load upper1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L118:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L120
    cmp byte [rsi], 0
    je .L119
    inc rdx
    inc rsi
    jmp .L118
.L120:
    mov rdx, 0          ; truncate to 0 on overflow
.L119:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR121]
section .data
.STR121: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L122:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L124
    cmp byte [rsi], 0
    je .L123
    inc rdx
    inc rsi
    jmp .L122
.L124:
    mov rdx, 0          ; truncate to 0 on overflow
.L123:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L101:
    lea rax, [rel .STR125]
section .data
.STR125: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6c, 0x6f, 0x77, 0x65, 0x72, 0x5b, 0x22, 0x57, 0x4f, 0x52, 0x4c, 0x44, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L126:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L128
    cmp byte [rsi], 0
    je .L127
    inc rdx
    inc rsi
    jmp .L126
.L128:
    mov rdx, 0          ; truncate to 0 on overflow
.L127:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @lower
    lea rax, [rel .STR129]
section .data
.STR129: db 0x57, 0x4f, 0x52, 0x4c, 0x44, 0x00
section .text
    push rax        ; arg 0
    mov rax, 154             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var lower1
    mov rax, [rbp - 64]  ; load lower1
    push rax
    lea rax, [rel .STR132]
section .data
.STR132: db 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L130
    lea rax, [rel .STR133]
section .data
.STR133: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L134:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L136
    cmp byte [rsi], 0
    je .L135
    inc rdx
    inc rsi
    jmp .L134
.L136:
    mov rdx, 0          ; truncate to 0 on overflow
.L135:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load lower1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L137:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L139
    cmp byte [rsi], 0
    je .L138
    inc rdx
    inc rsi
    jmp .L137
.L139:
    mov rdx, 0          ; truncate to 0 on overflow
.L138:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR140]
section .data
.STR140: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6c, 0x6f, 0x77, 0x65, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L141:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L143
    cmp byte [rsi], 0
    je .L142
    inc rdx
    inc rsi
    jmp .L141
.L143:
    mov rdx, 0          ; truncate to 0 on overflow
.L142:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L131
.L130:
    lea rax, [rel .STR144]
section .data
.STR144: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6c, 0x6f, 0x77, 0x65, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L145:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L147
    cmp byte [rsi], 0
    je .L146
    inc rdx
    inc rsi
    jmp .L145
.L147:
    mov rdx, 0          ; truncate to 0 on overflow
.L146:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load lower1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L148:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L150
    cmp byte [rsi], 0
    je .L149
    inc rdx
    inc rsi
    jmp .L148
.L150:
    mov rdx, 0          ; truncate to 0 on overflow
.L149:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR151]
section .data
.STR151: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L152:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L154
    cmp byte [rsi], 0
    je .L153
    inc rdx
    inc rsi
    jmp .L152
.L154:
    mov rdx, 0          ; truncate to 0 on overflow
.L153:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L131:
    lea rax, [rel .STR155]
section .data
.STR155: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x4f, 0x66, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x2c, 0x20, 0x22, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L156:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L158
    cmp byte [rsi], 0
    je .L157
    inc rdx
    inc rsi
    jmp .L156
.L158:
    mov rdx, 0          ; truncate to 0 on overflow
.L157:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @indexOf
    lea rax, [rel .STR159]
section .data
.STR159: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax        ; arg 0
    lea rax, [rel .STR160]
section .data
.STR160: db 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax        ; arg 1
    mov rax, 155             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var idx1
    mov rax, [rbp - 72]  ; load idx1
    push rax
    mov rax, 6
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L161
    lea rax, [rel .STR163]
section .data
.STR163: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L164:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L166
    cmp byte [rsi], 0
    je .L165
    inc rdx
    inc rsi
    jmp .L164
.L166:
    mov rdx, 0          ; truncate to 0 on overflow
.L165:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR167]
section .data
.STR167: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x4f, 0x66, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L168:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L170
    cmp byte [rsi], 0
    je .L169
    inc rdx
    inc rsi
    jmp .L168
.L170:
    mov rdx, 0          ; truncate to 0 on overflow
.L169:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L162
.L161:
    lea rax, [rel .STR171]
section .data
.STR171: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x4f, 0x66, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L172:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L174
    cmp byte [rsi], 0
    je .L173
    inc rdx
    inc rsi
    jmp .L172
.L174:
    mov rdx, 0          ; truncate to 0 on overflow
.L173:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR175]
section .data
.STR175: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L176:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L178
    cmp byte [rsi], 0
    je .L177
    inc rdx
    inc rsi
    jmp .L176
.L178:
    mov rdx, 0          ; truncate to 0 on overflow
.L177:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L162:
    lea rax, [rel .STR179]
section .data
.STR179: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x72, 0x65, 0x70, 0x6c, 0x61, 0x63, 0x65, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x2c, 0x20, 0x22, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x2c, 0x20, 0x22, 0x52, 0x41, 0x53, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L180:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L182
    cmp byte [rsi], 0
    je .L181
    inc rdx
    inc rsi
    jmp .L180
.L182:
    mov rdx, 0          ; truncate to 0 on overflow
.L181:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @replace
    lea rax, [rel .STR183]
section .data
.STR183: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax        ; arg 0
    lea rax, [rel .STR184]
section .data
.STR184: db 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax        ; arg 1
    lea rax, [rel .STR185]
section .data
.STR185: db 0x52, 0x41, 0x53, 0x00
section .text
    mov r12, rax    ; arg 2
    mov rax, 156             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var rep1
    mov rax, [rbp - 80]  ; load rep1
    push rax
    lea rax, [rel .STR188]
section .data
.STR188: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x52, 0x41, 0x53, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L186
    lea rax, [rel .STR189]
section .data
.STR189: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L190:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L192
    cmp byte [rsi], 0
    je .L191
    inc rdx
    inc rsi
    jmp .L190
.L192:
    mov rdx, 0          ; truncate to 0 on overflow
.L191:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 80]  ; load rep1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L193:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L195
    cmp byte [rsi], 0
    je .L194
    inc rdx
    inc rsi
    jmp .L193
.L195:
    mov rdx, 0          ; truncate to 0 on overflow
.L194:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR196]
section .data
.STR196: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x72, 0x65, 0x70, 0x6c, 0x61, 0x63, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L197:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L199
    cmp byte [rsi], 0
    je .L198
    inc rdx
    inc rsi
    jmp .L197
.L199:
    mov rdx, 0          ; truncate to 0 on overflow
.L198:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L187
.L186:
    lea rax, [rel .STR200]
section .data
.STR200: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x72, 0x65, 0x70, 0x6c, 0x61, 0x63, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L201:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L203
    cmp byte [rsi], 0
    je .L202
    inc rdx
    inc rsi
    jmp .L201
.L203:
    mov rdx, 0          ; truncate to 0 on overflow
.L202:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 80]  ; load rep1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L204:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L206
    cmp byte [rsi], 0
    je .L205
    inc rdx
    inc rsi
    jmp .L204
.L206:
    mov rdx, 0          ; truncate to 0 on overflow
.L205:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR207]
section .data
.STR207: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L208:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L210
    cmp byte [rsi], 0
    je .L209
    inc rdx
    inc rsi
    jmp .L208
.L210:
    mov rdx, 0          ; truncate to 0 on overflow
.L209:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L187:
    lea rax, [rel .STR211]
section .data
.STR211: db 0x0a, 0x5b, 0x39, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x72, 0x69, 0x6d, 0x5b, 0x22, 0x20, 0x20, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x20, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L212:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L214
    cmp byte [rsi], 0
    je .L213
    inc rdx
    inc rsi
    jmp .L212
.L214:
    mov rdx, 0          ; truncate to 0 on overflow
.L213:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @trim
    lea rax, [rel .STR215]
section .data
.STR215: db 0x20, 0x20, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x20, 0x00
section .text
    push rax        ; arg 0
    mov rax, 152             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var trim1
    mov rax, [rbp - 88]  ; load trim1
    push rax
    lea rax, [rel .STR218]
section .data
.STR218: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L216
    lea rax, [rel .STR219]
section .data
.STR219: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L220:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L222
    cmp byte [rsi], 0
    je .L221
    inc rdx
    inc rsi
    jmp .L220
.L222:
    mov rdx, 0          ; truncate to 0 on overflow
.L221:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 88]  ; load trim1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L223:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L225
    cmp byte [rsi], 0
    je .L224
    inc rdx
    inc rsi
    jmp .L223
.L225:
    mov rdx, 0          ; truncate to 0 on overflow
.L224:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR226]
section .data
.STR226: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x72, 0x69, 0x6d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L227:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L229
    cmp byte [rsi], 0
    je .L228
    inc rdx
    inc rsi
    jmp .L227
.L229:
    mov rdx, 0          ; truncate to 0 on overflow
.L228:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L217
.L216:
    lea rax, [rel .STR230]
section .data
.STR230: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x72, 0x69, 0x6d, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L231:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L233
    cmp byte [rsi], 0
    je .L232
    inc rdx
    inc rsi
    jmp .L231
.L233:
    mov rdx, 0          ; truncate to 0 on overflow
.L232:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 88]  ; load trim1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L234:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L236
    cmp byte [rsi], 0
    je .L235
    inc rdx
    inc rsi
    jmp .L234
.L236:
    mov rdx, 0          ; truncate to 0 on overflow
.L235:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR237]
section .data
.STR237: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L238:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L240
    cmp byte [rsi], 0
    je .L239
    inc rdx
    inc rsi
    jmp .L238
.L240:
    mov rdx, 0          ; truncate to 0 on overflow
.L239:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L217:
    lea rax, [rel .STR241]
section .data
.STR241: db 0x0a, 0x5b, 0x31, 0x30, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x72, 0x65, 0x70, 0x65, 0x61, 0x74, 0x5b, 0x22, 0x61, 0x62, 0x22, 0x2c, 0x20, 0x33, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L242:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L244
    cmp byte [rsi], 0
    je .L243
    inc rdx
    inc rsi
    jmp .L242
.L244:
    mov rdx, 0          ; truncate to 0 on overflow
.L243:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @repeat
    lea rax, [rel .STR245]
section .data
.STR245: db 0x61, 0x62, 0x00
section .text
    push rax        ; arg 0
    mov rax, 3
    push rax        ; arg 1
    mov rax, 160             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var rep2
    mov rax, [rbp - 96]  ; load rep2
    push rax
    lea rax, [rel .STR248]
section .data
.STR248: db 0x61, 0x62, 0x61, 0x62, 0x61, 0x62, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L246
    lea rax, [rel .STR249]
section .data
.STR249: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L250:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L252
    cmp byte [rsi], 0
    je .L251
    inc rdx
    inc rsi
    jmp .L250
.L252:
    mov rdx, 0          ; truncate to 0 on overflow
.L251:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 96]  ; load rep2
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L253:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L255
    cmp byte [rsi], 0
    je .L254
    inc rdx
    inc rsi
    jmp .L253
.L255:
    mov rdx, 0          ; truncate to 0 on overflow
.L254:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR256]
section .data
.STR256: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x72, 0x65, 0x70, 0x65, 0x61, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L257:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L259
    cmp byte [rsi], 0
    je .L258
    inc rdx
    inc rsi
    jmp .L257
.L259:
    mov rdx, 0          ; truncate to 0 on overflow
.L258:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L247
.L246:
    lea rax, [rel .STR260]
section .data
.STR260: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x72, 0x65, 0x70, 0x65, 0x61, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L261:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L263
    cmp byte [rsi], 0
    je .L262
    inc rdx
    inc rsi
    jmp .L261
.L263:
    mov rdx, 0          ; truncate to 0 on overflow
.L262:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 96]  ; load rep2
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L264:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L266
    cmp byte [rsi], 0
    je .L265
    inc rdx
    inc rsi
    jmp .L264
.L266:
    mov rdx, 0          ; truncate to 0 on overflow
.L265:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR267]
section .data
.STR267: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L268:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L270
    cmp byte [rsi], 0
    je .L269
    inc rdx
    inc rsi
    jmp .L268
.L270:
    mov rdx, 0          ; truncate to 0 on overflow
.L269:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L247:
    lea rax, [rel .STR271]
section .data
.STR271: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x53, 0x54, 0x52, 0x49, 0x4e, 0x47, 0x20, 0x4d, 0x41, 0x4e, 0x49, 0x50, 0x55, 0x4c, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L272:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L274
    cmp byte [rsi], 0
    je .L273
    inc rdx
    inc rsi
    jmp .L272
.L274:
    mov rdx, 0          ; truncate to 0 on overflow
.L273:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR275]
section .data
.STR275: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L276:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L278
    cmp byte [rsi], 0
    je .L277
    inc rdx
    inc rsi
    jmp .L276
.L278:
    mov rdx, 0          ; truncate to 0 on overflow
.L277:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR279]
section .data
.STR279: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L280:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L282
    cmp byte [rsi], 0
    je .L281
    inc rdx
    inc rsi
    jmp .L280
.L282:
    mov rdx, 0          ; truncate to 0 on overflow
.L281:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR283]
section .data
.STR283: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L284:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L286
    cmp byte [rsi], 0
    je .L285
    inc rdx
    inc rsi
    jmp .L284
.L286:
    mov rdx, 0          ; truncate to 0 on overflow
.L285:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR287]
section .data
.STR287: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L288:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L290
    cmp byte [rsi], 0
    je .L289
    inc rdx
    inc rsi
    jmp .L288
.L290:
    mov rdx, 0          ; truncate to 0 on overflow
.L289:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L291
    lea rax, [rel .STR293]
section .data
.STR293: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x53, 0x54, 0x52, 0x49, 0x4e, 0x47, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L294:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L296
    cmp byte [rsi], 0
    je .L295
    inc rdx
    inc rsi
    jmp .L294
.L296:
    mov rdx, 0          ; truncate to 0 on overflow
.L295:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L292
.L291:
    lea rax, [rel .STR297]
section .data
.STR297: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L298:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L300
    cmp byte [rsi], 0
    je .L299
    inc rdx
    inc rsi
    jmp .L298
.L300:
    mov rdx, 0          ; truncate to 0 on overflow
.L299:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L292:
    add rsp, 96         ; pop 12 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
