#!/bin/bash
# RASCODE BUILTIN FUNCTIONS COMPREHENSIVE TEST SUITE
# This script runs all builtin verification tests one by one

TESTS_DIR="/home/void/Desktop/RASIDE/RasCode/builtin_verification"
COMPILER="/home/void/Desktop/RASIDE/RasCode/rascom"  # RasCode compiler

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "========================================="
echo "RASCODE BUILTIN FUNCTIONS TEST SUITE"
echo "========================================="
echo ""

# Array of all test files
TEST_FILES=(
    "test_system_control.ras"
    "test_math.ras"
    "test_type_conversion.ras"
    "test_string_manipulation.ras"
    "test_memory_operations.ras"
    "test_array_operations.ras"
    "test_time_date.ras"
    "test_error_handling.ras"
    "test_file_io.ras"
    "test_security.ras"
    "test_concurrency.ras"
    "test_process_management.ras"
    "test_channel_communication.ras"
    "test_advanced_concurrency.ras"
    "test_additional_builtins.ras"
)

total_tests=${#TEST_FILES[@]}
passed_tests=0
failed_tests=0

# Function to run a single test
run_test() {
    local test_file=$1
    local test_name=${test_file%.ras}
    
    echo -e "${YELLOW}[TEST] Running: $test_file${NC}"
    echo "========================================="
    
    if [ -f "$TESTS_DIR/$test_file" ]; then
        # Try to compile and run
        if [ -f "$COMPILER" ]; then
            cd "$TESTS_DIR"
            "$COMPILER" "$test_file" 2>&1
            if [ $? -eq 0 ]; then
                echo -e "${GREEN}✓ Test passed${NC}"
                ((passed_tests++))
            else
                echo -e "${RED}✗ Test failed${NC}"
                ((failed_tests++))
            fi
        else
            echo -e "${YELLOW}⊘ Compiler not found at: $COMPILER${NC}"
            echo "Please update the COMPILER path in this script"
        fi
    else
        echo -e "${RED}✗ Test file not found: $TESTS_DIR/$test_file${NC}"
        ((failed_tests++))
    fi
    
    echo ""
}

# Run all tests
for test_file in "${TEST_FILES[@]}"; do
    run_test "$test_file"
done

# Summary
echo "========================================="
echo "TEST SUMMARY"
echo "========================================="
echo "Total Tests: $total_tests"
echo -e "${GREEN}Passed: $passed_tests${NC}"
echo -e "${RED}Failed: $failed_tests${NC}"
echo ""

if [ $failed_tests -eq 0 ]; then
    echo -e "${GREEN}✓ ALL TESTS PASSED!${NC}"
    exit 0
else
    echo -e "${RED}✗ SOME TESTS FAILED${NC}"
    exit 1
fi
