global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x53, 0x59, 0x53, 0x54, 0x45, 0x4d, 0x20, 0x43, 0x4f, 0x4e, 0x54, 0x52, 0x4f, 0x4c, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x6c, 0x6f, 0x63, 0x6b, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @clock
    sub rsp, 16
    mov rdi, 1          ; CLOCK_MONOTONIC
    lea rsi, [rsp]
    mov rax, 228        ; sys_clock_gettime
    syscall
    mov rax, [rsp]      ; rax = tv_sec
    imul rax, 1000      ; rax = tv_sec * 1000 ms
    mov rcx, [rsp+8]    ; rcx = tv_nsec
    mov rbx, 1000000
    mov rax, rcx
    xor rdx, rdx
    div rbx             ; rax = tv_nsec / 1000000 ms
    mov rcx, [rsp]      ; rcx = tv_sec
    imul rcx, 1000      ; rcx = tv_sec * 1000 ms
    add rax, rcx        ; rax = total ms
    add rsp, 16
    push rax            ; var t1
    lea rax, [rel .STR10]
section .data
.STR10: db 0x43, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L11:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L13
    cmp byte [rsi], 0
    je .L12
    inc rdx
    inc rsi
    jmp .L11
.L13:
    mov rdx, 0          ; truncate to 0 on overflow
.L12:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR14]
section .data
.STR14: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load t1
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L18
    lea rax, [rel .STR20]
section .data
.STR20: db 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L21:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L23
    cmp byte [rsi], 0
    je .L22
    inc rdx
    inc rsi
    jmp .L21
.L23:
    mov rdx, 0          ; truncate to 0 on overflow
.L22:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L19
.L18:
    lea rax, [rel .STR24]
section .data
.STR24: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L25:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L27
    cmp byte [rsi], 0
    je .L26
    inc rdx
    inc rsi
    jmp .L25
.L27:
    mov rdx, 0          ; truncate to 0 on overflow
.L26:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L19:
    lea rax, [rel .STR28]
section .data
.STR28: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x6c, 0x65, 0x65, 0x70, 0x5b, 0x31, 0x30, 0x30, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @clock
    sub rsp, 16
    mov rdi, 1          ; CLOCK_MONOTONIC
    lea rsi, [rsp]
    mov rax, 228        ; sys_clock_gettime
    syscall
    mov rax, [rsp]      ; rax = tv_sec
    imul rax, 1000      ; rax = tv_sec * 1000 ms
    mov rcx, [rsp+8]    ; rcx = tv_nsec
    mov rbx, 1000000
    mov rax, rcx
    xor rdx, rdx
    div rbx             ; rax = tv_nsec / 1000000 ms
    mov rcx, [rsp]      ; rcx = tv_sec
    imul rcx, 1000      ; rcx = tv_sec * 1000 ms
    add rax, rcx        ; rax = total ms
    add rsp, 16
    push rax            ; var before
    ; Builtin function @sleep
    mov rax, 100
    ; Convert milliseconds to nanoseconds
    mov rbx, 1000000
    imul rax, rbx       ; rax = ms * 1000000 = nanoseconds
    ; Create timespec struct on stack: tv_sec=0, tv_nsec=nanoseconds
    sub rsp, 32         ; Allocate space for two timespec structs
    mov qword [rsp], 0  ; tv_sec = 0
    mov qword [rsp+8], rax ; tv_nsec = nanoseconds
    lea rdi, [rsp]      ; rdi = ptr to req timespec
    lea rsi, [rsp+16]   ; rsi = ptr to rem timespec
    mov rax, 35         ; sys_nanosleep
    syscall
    add rsp, 32         ; Clean up stack
    ; Builtin function @clock
    sub rsp, 16
    mov rdi, 1          ; CLOCK_MONOTONIC
    lea rsi, [rsp]
    mov rax, 228        ; sys_clock_gettime
    syscall
    mov rax, [rsp]      ; rax = tv_sec
    imul rax, 1000      ; rax = tv_sec * 1000 ms
    mov rcx, [rsp+8]    ; rcx = tv_nsec
    mov rbx, 1000000
    mov rax, rcx
    xor rdx, rdx
    div rbx             ; rax = tv_nsec / 1000000 ms
    mov rcx, [rsp]      ; rcx = tv_sec
    imul rcx, 1000      ; rcx = tv_sec * 1000 ms
    add rax, rcx        ; rax = total ms
    add rsp, 16
    push rax            ; var after
    mov rax, [rbp - 40]  ; load after
    push rax
    mov rax, [rbp - 32]  ; load before
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var elapsed
    lea rax, [rel .STR32]
section .data
.STR32: db 0x45, 0x6c, 0x61, 0x70, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L33:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L35
    cmp byte [rsi], 0
    je .L34
    inc rdx
    inc rsi
    jmp .L33
.L35:
    mov rdx, 0          ; truncate to 0 on overflow
.L34:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR36]
section .data
.STR36: db 0x6d, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load elapsed
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    cmp rax, 0
    je .L40
    lea rax, [rel .STR42]
section .data
.STR42: db 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x6c, 0x65, 0x65, 0x70, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L43:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L45
    cmp byte [rsi], 0
    je .L44
    inc rdx
    inc rsi
    jmp .L43
.L45:
    mov rdx, 0          ; truncate to 0 on overflow
.L44:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L41
.L40:
    lea rax, [rel .STR46]
section .data
.STR46: db 0xe2, 0x8a, 0x98, 0x20, 0x40, 0x73, 0x6c, 0x65, 0x65, 0x70, 0x20, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x75, 0x6e, 0x63, 0x6c, 0x65, 0x61, 0x72, 0x20, 0x28, 0x73, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x2d, 0x64, 0x65, 0x70, 0x65, 0x6e, 0x64, 0x65, 0x6e, 0x74, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L47:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L49
    cmp byte [rsi], 0
    je .L48
    inc rdx
    inc rsi
    jmp .L47
.L49:
    mov rdx, 0          ; truncate to 0 on overflow
.L48:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
.L41:
    lea rax, [rel .STR50]
section .data
.STR50: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L51:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L53
    cmp byte [rsi], 0
    je .L52
    inc rdx
    inc rsi
    jmp .L51
.L53:
    mov rdx, 0          ; truncate to 0 on overflow
.L52:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var timestamp
    mov rax, [rbp - 56]  ; load timestamp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L54
    lea rax, [rel .STR56]
section .data
.STR56: db 0x54, 0x69, 0x6d, 0x65, 0x73, 0x74, 0x61, 0x6d, 0x70, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR60]
section .data
.STR60: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L55
.L54:
    lea rax, [rel .STR64]
section .data
.STR64: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L55:
    lea rax, [rel .STR68]
section .data
.STR68: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x6d, 0x73, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time_ms
    xor rax, rax        ; unsupported
    push rax            ; var timems
    mov rax, [rbp - 64]  ; load timems
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L72
    lea rax, [rel .STR74]
section .data
.STR74: db 0x54, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6d, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L75:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L77
    cmp byte [rsi], 0
    je .L76
    inc rdx
    inc rsi
    jmp .L75
.L77:
    mov rdx, 0          ; truncate to 0 on overflow
.L76:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR78]
section .data
.STR78: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x6d, 0x73, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L73
.L72:
    lea rax, [rel .STR82]
section .data
.STR82: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x6d, 0x73, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L73:
    lea rax, [rel .STR86]
section .data
.STR86: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x75, 0x73, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time_us
    xor rax, rax        ; unsupported
    push rax            ; var timeus
    mov rax, [rbp - 72]  ; load timeus
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L90
    lea rax, [rel .STR92]
section .data
.STR92: db 0x54, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x75, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L93:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L95
    cmp byte [rsi], 0
    je .L94
    inc rdx
    inc rsi
    jmp .L93
.L95:
    mov rdx, 0          ; truncate to 0 on overflow
.L94:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR96]
section .data
.STR96: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x75, 0x73, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L97:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L99
    cmp byte [rsi], 0
    je .L98
    inc rdx
    inc rsi
    jmp .L97
.L99:
    mov rdx, 0          ; truncate to 0 on overflow
.L98:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L91
.L90:
    lea rax, [rel .STR100]
section .data
.STR100: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5f, 0x75, 0x73, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L101:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L103
    cmp byte [rsi], 0
    je .L102
    inc rdx
    inc rsi
    jmp .L101
.L103:
    mov rdx, 0          ; truncate to 0 on overflow
.L102:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L91:
    lea rax, [rel .STR104]
section .data
.STR104: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x69, 0x64, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @pid
    mov rax, 39         ; sys_getpid
    syscall
    push rax            ; var processid
    mov rax, [rbp - 80]  ; load processid
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L108
    lea rax, [rel .STR110]
section .data
.STR110: db 0x50, 0x72, 0x6f, 0x63, 0x65, 0x73, 0x73, 0x20, 0x49, 0x44, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L111:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L113
    cmp byte [rsi], 0
    je .L112
    inc rdx
    inc rsi
    jmp .L111
.L113:
    mov rdx, 0          ; truncate to 0 on overflow
.L112:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR114]
section .data
.STR114: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x70, 0x69, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L115:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L117
    cmp byte [rsi], 0
    je .L116
    inc rdx
    inc rsi
    jmp .L115
.L117:
    mov rdx, 0          ; truncate to 0 on overflow
.L116:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L109
.L108:
    lea rax, [rel .STR118]
section .data
.STR118: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x70, 0x69, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L119:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L121
    cmp byte [rsi], 0
    je .L120
    inc rdx
    inc rsi
    jmp .L119
.L121:
    mov rdx, 0          ; truncate to 0 on overflow
.L120:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L109:
    lea rax, [rel .STR122]
section .data
.STR122: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x67, 0x65, 0x74, 0x70, 0x69, 0x64, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L123:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L125
    cmp byte [rsi], 0
    je .L124
    inc rdx
    inc rsi
    jmp .L123
.L125:
    mov rdx, 0          ; truncate to 0 on overflow
.L124:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @getpid
    xor rax, rax        ; unsupported process function
    push rax            ; var pid
    mov rax, [rbp - 88]  ; load pid
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L126
    lea rax, [rel .STR128]
section .data
.STR128: db 0x50, 0x72, 0x6f, 0x63, 0x65, 0x73, 0x73, 0x20, 0x49, 0x44, 0x20, 0x28, 0x67, 0x65, 0x74, 0x70, 0x69, 0x64, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L129:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L131
    cmp byte [rsi], 0
    je .L130
    inc rdx
    inc rsi
    jmp .L129
.L131:
    mov rdx, 0          ; truncate to 0 on overflow
.L130:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR132]
section .data
.STR132: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x67, 0x65, 0x74, 0x70, 0x69, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L133:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L135
    cmp byte [rsi], 0
    je .L134
    inc rdx
    inc rsi
    jmp .L133
.L135:
    mov rdx, 0          ; truncate to 0 on overflow
.L134:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L127
.L126:
    lea rax, [rel .STR136]
section .data
.STR136: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x67, 0x65, 0x74, 0x70, 0x69, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L137:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L139
    cmp byte [rsi], 0
    je .L138
    inc rdx
    inc rsi
    jmp .L137
.L139:
    mov rdx, 0          ; truncate to 0 on overflow
.L138:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L127:
    lea rax, [rel .STR140]
section .data
.STR140: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x67, 0x65, 0x74, 0x63, 0x77, 0x64, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L141:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L143
    cmp byte [rsi], 0
    je .L142
    inc rdx
    inc rsi
    jmp .L141
.L143:
    mov rdx, 0          ; truncate to 0 on overflow
.L142:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @getcwd
    xor rax, rax        ; unsupported process function
    push rax            ; var cwd
    mov rax, [rbp - 96]  ; load cwd
    push rax
    lea rax, [rel .STR146]
section .data
.STR146: db 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L144
    lea rax, [rel .STR147]
section .data
.STR147: db 0x43, 0x75, 0x72, 0x72, 0x65, 0x6e, 0x74, 0x20, 0x44, 0x69, 0x72, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L148:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L150
    cmp byte [rsi], 0
    je .L149
    inc rdx
    inc rsi
    jmp .L148
.L150:
    mov rdx, 0          ; truncate to 0 on overflow
.L149:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 96]  ; load cwd
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L151:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L153
    cmp byte [rsi], 0
    je .L152
    inc rdx
    inc rsi
    jmp .L151
.L153:
    mov rdx, 0          ; truncate to 0 on overflow
.L152:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR154]
section .data
.STR154: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x67, 0x65, 0x74, 0x63, 0x77, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L155:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L157
    cmp byte [rsi], 0
    je .L156
    inc rdx
    inc rsi
    jmp .L155
.L157:
    mov rdx, 0          ; truncate to 0 on overflow
.L156:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L145
.L144:
    lea rax, [rel .STR158]
section .data
.STR158: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x67, 0x65, 0x74, 0x63, 0x77, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L159:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L161
    cmp byte [rsi], 0
    je .L160
    inc rdx
    inc rsi
    jmp .L159
.L161:
    mov rdx, 0          ; truncate to 0 on overflow
.L160:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L145:
    lea rax, [rel .STR162]
section .data
.STR162: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x53, 0x59, 0x53, 0x54, 0x45, 0x4d, 0x20, 0x43, 0x4f, 0x4e, 0x54, 0x52, 0x4f, 0x4c, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L163:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L165
    cmp byte [rsi], 0
    je .L164
    inc rdx
    inc rsi
    jmp .L163
.L165:
    mov rdx, 0          ; truncate to 0 on overflow
.L164:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR166]
section .data
.STR166: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L167:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L169
    cmp byte [rsi], 0
    je .L168
    inc rdx
    inc rsi
    jmp .L167
.L169:
    mov rdx, 0          ; truncate to 0 on overflow
.L168:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR170]
section .data
.STR170: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L171:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L173
    cmp byte [rsi], 0
    je .L172
    inc rdx
    inc rsi
    jmp .L171
.L173:
    mov rdx, 0          ; truncate to 0 on overflow
.L172:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR174]
section .data
.STR174: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L175:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L177
    cmp byte [rsi], 0
    je .L176
    inc rdx
    inc rsi
    jmp .L175
.L177:
    mov rdx, 0          ; truncate to 0 on overflow
.L176:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR178]
section .data
.STR178: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L179:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L181
    cmp byte [rsi], 0
    je .L180
    inc rdx
    inc rsi
    jmp .L179
.L181:
    mov rdx, 0          ; truncate to 0 on overflow
.L180:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L182
    lea rax, [rel .STR184]
section .data
.STR184: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L185:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L187
    cmp byte [rsi], 0
    je .L186
    inc rdx
    inc rsi
    jmp .L185
.L187:
    mov rdx, 0          ; truncate to 0 on overflow
.L186:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L183
.L182:
    lea rax, [rel .STR188]
section .data
.STR188: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L189:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L191
    cmp byte [rsi], 0
    je .L190
    inc rdx
    inc rsi
    jmp .L189
.L191:
    mov rdx, 0          ; truncate to 0 on overflow
.L190:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L183:
    add rsp, 96         ; pop 12 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
