global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x41, 0x52, 0x52, 0x41, 0x59, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x43, 0x72, 0x65, 0x61, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x65, 0x73, 0x74, 0x20, 0x61, 0x72, 0x72, 0x61, 0x79, 0x3a, 0x20, 0x5b, 0x35, 0x2c, 0x20, 0x31, 0x30, 0x2c, 0x20, 0x31, 0x35, 0x2c, 0x20, 0x32, 0x30, 0x2c, 0x20, 0x32, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; array declaration: testarray{int, 5} (element_size=4 bytes)
    sub rsp, 20         ; allocate array space
    mov rax, 5
    mov dword [rbp - 36], eax ; init testarray{0}
    mov rax, 10
    mov dword [rbp - 32], eax ; init testarray{1}
    mov rax, 15
    mov dword [rbp - 28], eax ; init testarray{2}
    mov rax, 20
    mov dword [rbp - 24], eax ; init testarray{3}
    mov rax, 25
    mov dword [rbp - 20], eax ; init testarray{4}
    lea rax, [rel .STR10]
section .data
.STR10: db 0x41, 0x72, 0x72, 0x61, 0x79, 0x20, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L11:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L13
    cmp byte [rsi], 0
    je .L12
    inc rdx
    inc rsi
    jmp .L11
.L13:
    mov rdx, 0          ; truncate to 0 on overflow
.L12:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR14]
section .data
.STR14: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @find_min
    xor rax, rax        ; unsupported
    push rax            ; var minval
    mov rax, [rbp - 44]  ; load minval
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L18
    lea rax, [rel .STR20]
section .data
.STR20: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L21:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L23
    cmp byte [rsi], 0
    je .L22
    inc rdx
    inc rsi
    jmp .L21
.L23:
    mov rdx, 0          ; truncate to 0 on overflow
.L22:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR24]
section .data
.STR24: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L25:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L27
    cmp byte [rsi], 0
    je .L26
    inc rdx
    inc rsi
    jmp .L25
.L27:
    mov rdx, 0          ; truncate to 0 on overflow
.L26:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L19
.L18:
    lea rax, [rel .STR28]
section .data
.STR28: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR32]
section .data
.STR32: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L33:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L35
    cmp byte [rsi], 0
    je .L34
    inc rdx
    inc rsi
    jmp .L33
.L35:
    mov rdx, 0          ; truncate to 0 on overflow
.L34:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L19:
    lea rax, [rel .STR36]
section .data
.STR36: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @find_max
    xor rax, rax        ; unsupported
    push rax            ; var maxval
    mov rax, [rbp - 52]  ; load maxval
    push rax
    mov rax, 25
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L40
    lea rax, [rel .STR42]
section .data
.STR42: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L43:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L45
    cmp byte [rsi], 0
    je .L44
    inc rdx
    inc rsi
    jmp .L43
.L45:
    mov rdx, 0          ; truncate to 0 on overflow
.L44:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR46]
section .data
.STR46: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L47:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L49
    cmp byte [rsi], 0
    je .L48
    inc rdx
    inc rsi
    jmp .L47
.L49:
    mov rdx, 0          ; truncate to 0 on overflow
.L48:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L41
.L40:
    lea rax, [rel .STR50]
section .data
.STR50: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L51:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L53
    cmp byte [rsi], 0
    je .L52
    inc rdx
    inc rsi
    jmp .L51
.L53:
    mov rdx, 0          ; truncate to 0 on overflow
.L52:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR54]
section .data
.STR54: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L55:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L57
    cmp byte [rsi], 0
    je .L56
    inc rdx
    inc rsi
    jmp .L55
.L57:
    mov rdx, 0          ; truncate to 0 on overflow
.L56:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L41:
    lea rax, [rel .STR58]
section .data
.STR58: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x5f, 0x69, 0x64, 0x78, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L59:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L61
    cmp byte [rsi], 0
    je .L60
    inc rdx
    inc rsi
    jmp .L59
.L61:
    mov rdx, 0          ; truncate to 0 on overflow
.L60:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @find_min_idx
    xor rax, rax        ; unsupported
    push rax            ; var minidx
    mov rax, [rbp - 60]  ; load minidx
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L62
    lea rax, [rel .STR64]
section .data
.STR64: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR68]
section .data
.STR68: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x5f, 0x69, 0x64, 0x78, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L63
.L62:
    lea rax, [rel .STR72]
section .data
.STR72: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x69, 0x6e, 0x5f, 0x69, 0x64, 0x78, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR76]
section .data
.STR76: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L63:
    lea rax, [rel .STR80]
section .data
.STR80: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x5f, 0x69, 0x64, 0x78, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L81:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L83
    cmp byte [rsi], 0
    je .L82
    inc rdx
    inc rsi
    jmp .L81
.L83:
    mov rdx, 0          ; truncate to 0 on overflow
.L82:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @find_max_idx
    xor rax, rax        ; unsupported
    push rax            ; var maxidx
    mov rax, [rbp - 68]  ; load maxidx
    push rax
    mov rax, 4
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L84
    lea rax, [rel .STR86]
section .data
.STR86: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR90]
section .data
.STR90: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x5f, 0x69, 0x64, 0x78, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L91:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L93
    cmp byte [rsi], 0
    je .L92
    inc rdx
    inc rsi
    jmp .L91
.L93:
    mov rdx, 0          ; truncate to 0 on overflow
.L92:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L85
.L84:
    lea rax, [rel .STR94]
section .data
.STR94: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x66, 0x69, 0x6e, 0x64, 0x5f, 0x6d, 0x61, 0x78, 0x5f, 0x69, 0x64, 0x78, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L95:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L97
    cmp byte [rsi], 0
    je .L96
    inc rdx
    inc rsi
    jmp .L95
.L97:
    mov rdx, 0          ; truncate to 0 on overflow
.L96:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR98]
section .data
.STR98: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L99:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L101
    cmp byte [rsi], 0
    je .L100
    inc rdx
    inc rsi
    jmp .L99
.L101:
    mov rdx, 0          ; truncate to 0 on overflow
.L100:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L85:
    lea rax, [rel .STR102]
section .data
.STR102: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x75, 0x6d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L103:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L105
    cmp byte [rsi], 0
    je .L104
    inc rdx
    inc rsi
    jmp .L103
.L105:
    mov rdx, 0          ; truncate to 0 on overflow
.L104:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @sum
    xor rax, rax        ; unsupported
    push rax            ; var sumval
    mov rax, [rbp - 76]  ; load sumval
    push rax
    mov rax, 75
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L106
    lea rax, [rel .STR108]
section .data
.STR108: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L109:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L111
    cmp byte [rsi], 0
    je .L110
    inc rdx
    inc rsi
    jmp .L109
.L111:
    mov rdx, 0          ; truncate to 0 on overflow
.L110:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR112]
section .data
.STR112: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x75, 0x6d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L113:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L115
    cmp byte [rsi], 0
    je .L114
    inc rdx
    inc rsi
    jmp .L113
.L115:
    mov rdx, 0          ; truncate to 0 on overflow
.L114:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L107
.L106:
    lea rax, [rel .STR116]
section .data
.STR116: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x75, 0x6d, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L117:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L119
    cmp byte [rsi], 0
    je .L118
    inc rdx
    inc rsi
    jmp .L117
.L119:
    mov rdx, 0          ; truncate to 0 on overflow
.L118:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR120]
section .data
.STR120: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L121:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L123
    cmp byte [rsi], 0
    je .L122
    inc rdx
    inc rsi
    jmp .L121
.L123:
    mov rdx, 0          ; truncate to 0 on overflow
.L122:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L107:
    lea rax, [rel .STR124]
section .data
.STR124: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x5f, 0x76, 0x61, 0x6c, 0x5b, 0x61, 0x72, 0x72, 0x61, 0x79, 0x2c, 0x20, 0x31, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L125:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L127
    cmp byte [rsi], 0
    je .L126
    inc rdx
    inc rsi
    jmp .L125
.L127:
    mov rdx, 0          ; truncate to 0 on overflow
.L126:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @count_val
    xor rax, rax        ; unsupported
    push rax            ; var count1
    mov rax, [rbp - 84]  ; load count1
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L128
    lea rax, [rel .STR130]
section .data
.STR130: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L131:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L133
    cmp byte [rsi], 0
    je .L132
    inc rdx
    inc rsi
    jmp .L131
.L133:
    mov rdx, 0          ; truncate to 0 on overflow
.L132:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR134]
section .data
.STR134: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x5f, 0x76, 0x61, 0x6c, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L135:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L137
    cmp byte [rsi], 0
    je .L136
    inc rdx
    inc rsi
    jmp .L135
.L137:
    mov rdx, 0          ; truncate to 0 on overflow
.L136:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L129
.L128:
    lea rax, [rel .STR138]
section .data
.STR138: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x5f, 0x76, 0x61, 0x6c, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L139:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L141
    cmp byte [rsi], 0
    je .L140
    inc rdx
    inc rsi
    jmp .L139
.L141:
    mov rdx, 0          ; truncate to 0 on overflow
.L140:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR142]
section .data
.STR142: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L143:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L145
    cmp byte [rsi], 0
    je .L144
    inc rdx
    inc rsi
    jmp .L143
.L145:
    mov rdx, 0          ; truncate to 0 on overflow
.L144:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L129:
    lea rax, [rel .STR146]
section .data
.STR146: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L147:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L149
    cmp byte [rsi], 0
    je .L148
    inc rdx
    inc rsi
    jmp .L147
.L149:
    mov rdx, 0          ; truncate to 0 on overflow
.L148:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @search
    xor rax, rax        ; unsupported
    push rax            ; var searchidx
    mov rax, [rbp - 92]  ; load searchidx
    push rax
    mov rax, 3
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L150
    lea rax, [rel .STR152]
section .data
.STR152: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L153:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L155
    cmp byte [rsi], 0
    je .L154
    inc rdx
    inc rsi
    jmp .L153
.L155:
    mov rdx, 0          ; truncate to 0 on overflow
.L154:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR156]
section .data
.STR156: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L157:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L159
    cmp byte [rsi], 0
    je .L158
    inc rdx
    inc rsi
    jmp .L157
.L159:
    mov rdx, 0          ; truncate to 0 on overflow
.L158:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L151
.L150:
    lea rax, [rel .STR160]
section .data
.STR160: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L161:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L163
    cmp byte [rsi], 0
    je .L162
    inc rdx
    inc rsi
    jmp .L161
.L163:
    mov rdx, 0          ; truncate to 0 on overflow
.L162:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR164]
section .data
.STR164: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L165:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L167
    cmp byte [rsi], 0
    je .L166
    inc rdx
    inc rsi
    jmp .L165
.L167:
    mov rdx, 0          ; truncate to 0 on overflow
.L166:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L151:
    lea rax, [rel .STR168]
section .data
.STR168: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x41, 0x52, 0x52, 0x41, 0x59, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L169:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L171
    cmp byte [rsi], 0
    je .L170
    inc rdx
    inc rsi
    jmp .L169
.L171:
    mov rdx, 0          ; truncate to 0 on overflow
.L170:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR172]
section .data
.STR172: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L173:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L175
    cmp byte [rsi], 0
    je .L174
    inc rdx
    inc rsi
    jmp .L173
.L175:
    mov rdx, 0          ; truncate to 0 on overflow
.L174:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR176]
section .data
.STR176: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L177:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L179
    cmp byte [rsi], 0
    je .L178
    inc rdx
    inc rsi
    jmp .L177
.L179:
    mov rdx, 0          ; truncate to 0 on overflow
.L178:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR180]
section .data
.STR180: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L181:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L183
    cmp byte [rsi], 0
    je .L182
    inc rdx
    inc rsi
    jmp .L181
.L183:
    mov rdx, 0          ; truncate to 0 on overflow
.L182:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR184]
section .data
.STR184: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L185:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L187
    cmp byte [rsi], 0
    je .L186
    inc rdx
    inc rsi
    jmp .L185
.L187:
    mov rdx, 0          ; truncate to 0 on overflow
.L186:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L188
    lea rax, [rel .STR190]
section .data
.STR190: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x41, 0x52, 0x52, 0x41, 0x59, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L191:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L193
    cmp byte [rsi], 0
    je .L192
    inc rdx
    inc rsi
    jmp .L191
.L193:
    mov rdx, 0          ; truncate to 0 on overflow
.L192:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L189
.L188:
    lea rax, [rel .STR194]
section .data
.STR194: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L195:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L197
    cmp byte [rsi], 0
    je .L196
    inc rdx
    inc rsi
    jmp .L195
.L197:
    mov rdx, 0          ; truncate to 0 on overflow
.L196:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L189:
    add rsp, 88         ; pop 11 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
