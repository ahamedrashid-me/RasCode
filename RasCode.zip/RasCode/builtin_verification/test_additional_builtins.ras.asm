global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x41, 0x44, 0x44, 0x49, 0x54, 0x49, 0x4f, 0x4e, 0x41, 0x4c, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x2c, 0x20, 0x31, 0x2c, 0x20, 0x33, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @substr
    lea rax, [rel .STR10]
section .data
.STR10: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    push rax            ; save str
    mov rax, 3
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, 1
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var sub1
    mov rax, [rbp - 24]  ; load sub1
    push rax
    lea rax, [rel .STR13]
section .data
.STR13: db 0x65, 0x6c, 0x6c, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L11
    lea rax, [rel .STR14]
section .data
.STR14: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load sub1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L18:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L20
    cmp byte [rsi], 0
    je .L19
    inc rdx
    inc rsi
    jmp .L18
.L20:
    mov rdx, 0          ; truncate to 0 on overflow
.L19:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR21]
section .data
.STR21: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L22:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L24
    cmp byte [rsi], 0
    je .L23
    inc rdx
    inc rsi
    jmp .L22
.L24:
    mov rdx, 0          ; truncate to 0 on overflow
.L23:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L12
.L11:
    lea rax, [rel .STR25]
section .data
.STR25: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L26:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L28
    cmp byte [rsi], 0
    je .L27
    inc rdx
    inc rsi
    jmp .L26
.L28:
    mov rdx, 0          ; truncate to 0 on overflow
.L27:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load sub1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR32]
section .data
.STR32: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L33:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L35
    cmp byte [rsi], 0
    je .L34
    inc rdx
    inc rsi
    jmp .L33
.L35:
    mov rdx, 0          ; truncate to 0 on overflow
.L34:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L12:
    lea rax, [rel .STR36]
section .data
.STR36: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x72, 0x65, 0x76, 0x65, 0x72, 0x73, 0x65, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @reverse
    lea rax, [rel .STR40]
section .data
.STR40: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    push rax        ; arg 0
    mov rax, 159             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var rev1
    mov rax, [rbp - 32]  ; load rev1
    push rax
    lea rax, [rel .STR43]
section .data
.STR43: db 0x6f, 0x6c, 0x6c, 0x65, 0x68, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L41
    lea rax, [rel .STR44]
section .data
.STR44: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L45:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L47
    cmp byte [rsi], 0
    je .L46
    inc rdx
    inc rsi
    jmp .L45
.L47:
    mov rdx, 0          ; truncate to 0 on overflow
.L46:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load rev1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR51]
section .data
.STR51: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x72, 0x65, 0x76, 0x65, 0x72, 0x73, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L52:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L54
    cmp byte [rsi], 0
    je .L53
    inc rdx
    inc rsi
    jmp .L52
.L54:
    mov rdx, 0          ; truncate to 0 on overflow
.L53:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L42
.L41:
    lea rax, [rel .STR55]
section .data
.STR55: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x72, 0x65, 0x76, 0x65, 0x72, 0x73, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L56:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L58
    cmp byte [rsi], 0
    je .L57
    inc rdx
    inc rsi
    jmp .L56
.L58:
    mov rdx, 0          ; truncate to 0 on overflow
.L57:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load rev1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L59:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L61
    cmp byte [rsi], 0
    je .L60
    inc rdx
    inc rsi
    jmp .L59
.L61:
    mov rdx, 0          ; truncate to 0 on overflow
.L60:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR62]
section .data
.STR62: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L63:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L65
    cmp byte [rsi], 0
    je .L64
    inc rdx
    inc rsi
    jmp .L63
.L65:
    mov rdx, 0          ; truncate to 0 on overflow
.L64:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L42:
    lea rax, [rel .STR66]
section .data
.STR66: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x68, 0x72, 0x5b, 0x36, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L67:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L69
    cmp byte [rsi], 0
    je .L68
    inc rdx
    inc rsi
    jmp .L67
.L69:
    mov rdx, 0          ; truncate to 0 on overflow
.L68:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @chr
    mov rax, 65
    and rax, 0xFF       ; keep only byte
    push rax            ; var chr1
    mov rax, [rbp - 40]  ; load chr1
    push rax
    lea rax, [rel .STR72]
section .data
.STR72: db 0x41, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L70
    lea rax, [rel .STR73]
section .data
.STR73: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L74:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L76
    cmp byte [rsi], 0
    je .L75
    inc rdx
    inc rsi
    jmp .L74
.L76:
    mov rdx, 0          ; truncate to 0 on overflow
.L75:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load chr1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR80]
section .data
.STR80: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x68, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L81:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L83
    cmp byte [rsi], 0
    je .L82
    inc rdx
    inc rsi
    jmp .L81
.L83:
    mov rdx, 0          ; truncate to 0 on overflow
.L82:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L71
.L70:
    lea rax, [rel .STR84]
section .data
.STR84: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x68, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L85:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L87
    cmp byte [rsi], 0
    je .L86
    inc rdx
    inc rsi
    jmp .L85
.L87:
    mov rdx, 0          ; truncate to 0 on overflow
.L86:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load chr1
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L88:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L90
    cmp byte [rsi], 0
    je .L89
    inc rdx
    inc rsi
    jmp .L88
.L90:
    mov rdx, 0          ; truncate to 0 on overflow
.L89:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR91]
section .data
.STR91: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L92:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L94
    cmp byte [rsi], 0
    je .L93
    inc rdx
    inc rsi
    jmp .L92
.L94:
    mov rdx, 0          ; truncate to 0 on overflow
.L93:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L71:
    lea rax, [rel .STR95]
section .data
.STR95: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6f, 0x72, 0x64, 0x5b, 0x22, 0x41, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L96:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L98
    cmp byte [rsi], 0
    je .L97
    inc rdx
    inc rsi
    jmp .L96
.L98:
    mov rdx, 0          ; truncate to 0 on overflow
.L97:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @ord
    lea rax, [rel .STR99]
section .data
.STR99: db 0x41, 0x00
section .text
    movzx rax, al       ; zero extend byte
    push rax            ; var ord1
    mov rax, [rbp - 48]  ; load ord1
    push rax
    mov rax, 65
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L100
    lea rax, [rel .STR102]
section .data
.STR102: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L103:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L105
    cmp byte [rsi], 0
    je .L104
    inc rdx
    inc rsi
    jmp .L103
.L105:
    mov rdx, 0          ; truncate to 0 on overflow
.L104:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR106]
section .data
.STR106: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6f, 0x72, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L107:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L109
    cmp byte [rsi], 0
    je .L108
    inc rdx
    inc rsi
    jmp .L107
.L109:
    mov rdx, 0          ; truncate to 0 on overflow
.L108:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L101
.L100:
    lea rax, [rel .STR110]
section .data
.STR110: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6f, 0x72, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L111:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L113
    cmp byte [rsi], 0
    je .L112
    inc rdx
    inc rsi
    jmp .L111
.L113:
    mov rdx, 0          ; truncate to 0 on overflow
.L112:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR114]
section .data
.STR114: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L115:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L117
    cmp byte [rsi], 0
    je .L116
    inc rdx
    inc rsi
    jmp .L115
.L117:
    mov rdx, 0          ; truncate to 0 on overflow
.L116:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L101:
    lea rax, [rel .STR118]
section .data
.STR118: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x74, 0x61, 0x72, 0x74, 0x73, 0x77, 0x69, 0x74, 0x68, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x2c, 0x20, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L119:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L121
    cmp byte [rsi], 0
    je .L120
    inc rdx
    inc rsi
    jmp .L119
.L121:
    mov rdx, 0          ; truncate to 0 on overflow
.L120:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var starts1
    mov rax, [rbp - 56]  ; load starts1
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L122
    lea rax, [rel .STR124]
section .data
.STR124: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x79, 0x65, 0x73, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x74, 0x61, 0x72, 0x74, 0x73, 0x77, 0x69, 0x74, 0x68, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L125:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L127
    cmp byte [rsi], 0
    je .L126
    inc rdx
    inc rsi
    jmp .L125
.L127:
    mov rdx, 0          ; truncate to 0 on overflow
.L126:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L123
.L122:
    lea rax, [rel .STR128]
section .data
.STR128: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x74, 0x61, 0x72, 0x74, 0x73, 0x77, 0x69, 0x74, 0x68, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L129:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L131
    cmp byte [rsi], 0
    je .L130
    inc rdx
    inc rsi
    jmp .L129
.L131:
    mov rdx, 0          ; truncate to 0 on overflow
.L130:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L123:
    lea rax, [rel .STR132]
section .data
.STR132: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x65, 0x6e, 0x64, 0x73, 0x77, 0x69, 0x74, 0x68, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x2c, 0x20, 0x22, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L133:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L135
    cmp byte [rsi], 0
    je .L134
    inc rdx
    inc rsi
    jmp .L133
.L135:
    mov rdx, 0          ; truncate to 0 on overflow
.L134:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var ends1
    mov rax, [rbp - 64]  ; load ends1
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L136
    lea rax, [rel .STR138]
section .data
.STR138: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x79, 0x65, 0x73, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x65, 0x6e, 0x64, 0x73, 0x77, 0x69, 0x74, 0x68, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L139:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L141
    cmp byte [rsi], 0
    je .L140
    inc rdx
    inc rsi
    jmp .L139
.L141:
    mov rdx, 0          ; truncate to 0 on overflow
.L140:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L137
.L136:
    lea rax, [rel .STR142]
section .data
.STR142: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x65, 0x6e, 0x64, 0x73, 0x77, 0x69, 0x74, 0x68, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L143:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L145
    cmp byte [rsi], 0
    je .L144
    inc rdx
    inc rsi
    jmp .L143
.L145:
    mov rdx, 0          ; truncate to 0 on overflow
.L144:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L137:
    lea rax, [rel .STR146]
section .data
.STR146: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x61, 0x64, 0x5b, 0x22, 0x74, 0x65, 0x73, 0x74, 0x22, 0x2c, 0x20, 0x38, 0x2c, 0x20, 0x27, 0x20, 0x27, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L147:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L149
    cmp byte [rsi], 0
    je .L148
    inc rdx
    inc rsi
    jmp .L147
.L149:
    mov rdx, 0          ; truncate to 0 on overflow
.L148:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @pad
    lea rax, [rel .STR150]
section .data
.STR150: db 0x74, 0x65, 0x73, 0x74, 0x00
section .text
    push rax        ; arg 0
    mov rax, 8
    push rax        ; arg 1
    mov rax, 32
    mov r12, rax    ; arg 2
    mov rax, 161             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var pad1
    xor rax, rax        ; unknown builtin - return 0
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L151
    lea rax, [rel .STR153]
section .data
.STR153: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x50, 0x61, 0x64, 0x64, 0x65, 0x64, 0x20, 0x74, 0x6f, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L154:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L156
    cmp byte [rsi], 0
    je .L155
    inc rdx
    inc rsi
    jmp .L154
.L156:
    mov rdx, 0          ; truncate to 0 on overflow
.L155:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR157]
section .data
.STR157: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x70, 0x61, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L158:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L160
    cmp byte [rsi], 0
    je .L159
    inc rdx
    inc rsi
    jmp .L158
.L160:
    mov rdx, 0          ; truncate to 0 on overflow
.L159:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L152
.L151:
    lea rax, [rel .STR161]
section .data
.STR161: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x70, 0x61, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L162:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L164
    cmp byte [rsi], 0
    je .L163
    inc rdx
    inc rsi
    jmp .L162
.L164:
    mov rdx, 0          ; truncate to 0 on overflow
.L163:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L152:
    lea rax, [rel .STR165]
section .data
.STR165: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x72, 0x65, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L166:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L168
    cmp byte [rsi], 0
    je .L167
    inc rdx
    inc rsi
    jmp .L166
.L168:
    mov rdx, 0          ; truncate to 0 on overflow
.L167:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 100
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_169
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_169
.alloc_fail_169:
    xor rax, rax        ; return 0 on failure
.alloc_done_169:
    push rax            ; var ptr1
    ; Builtin function @realloc
    mov rax, [rbp - 80]  ; load ptr1
    mov rbx, rax        ; old_ptr in rbx
    mov rax, 200
    mov rcx, rax        ; new_size in rcx
    mov rax, [rbx - 8]  ; read old size from metadata
    sub rax, 8          ; adjust for metadata size
    mov r9, rax         ; old_size in r9
    push rbx            ; save old_ptr
    push rcx            ; save new_size
    push r9             ; save old_size
    mov rdi, rcx        ; new_size
    add rdi, 8          ; add metadata overhead
    xor rax, 0          ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov r8, rax         ; new_ptr (metadata location) in r8
    pop r9              ; restore old_size
    pop rcx             ; restore new_size
    add rax, rcx        ; new brk = current + new_size + 8
    add rax, 8
    mov rdi, rax
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check success
    jne .realloc_fail_170
    mov rax, rcx        ; new_size
    add rax, 8          ; with metadata
    mov [r8], rax       ; store total size in metadata
    add r8, 8           ; adjust to user ptr
    pop rbx             ; old_ptr
    mov rdi, r8         ; dest = new_ptr
    mov rsi, rbx        ; src = old_ptr
    mov rcx, r9         ; old_size
    cmp rcx, [rsp]      ; compare old_size with new_size
    jle .realloc_copy_170
    mov rcx, [rsp]      ; use new_size if smaller
.realloc_copy_170:
    rep movsb           ; copy data
    add rsp, 8          ; clean stack
    mov rax, r8         ; return new_ptr
    jmp .realloc_done_170
.realloc_fail_170:
    add rsp, 16         ; clean up stack
    xor rax, rax        ; return 0 on failure
.realloc_done_170:
    push rax            ; var ptr2
    mov rax, [rbp - 88]  ; load ptr2
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L171
    lea rax, [rel .STR173]
section .data
.STR173: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x52, 0x65, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x72, 0x65, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L174:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L176
    cmp byte [rsi], 0
    je .L175
    inc rdx
    inc rsi
    jmp .L174
.L176:
    mov rdx, 0          ; truncate to 0 on overflow
.L175:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    ; Builtin function @free
    mov rax, [rbp - 88]  ; load ptr2
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    jmp .L172
.L171:
    lea rax, [rel .STR177]
section .data
.STR177: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x72, 0x65, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L178:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L180
    cmp byte [rsi], 0
    je .L179
    inc rdx
    inc rsi
    jmp .L178
.L180:
    mov rdx, 0          ; truncate to 0 on overflow
.L179:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
    ; Builtin function @free
    mov rax, [rbp - 80]  ; load ptr1
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
.L172:
    lea rax, [rel .STR181]
section .data
.STR181: db 0x0a, 0x5b, 0x39, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6d, 0x70, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L182:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L184
    cmp byte [rsi], 0
    je .L183
    inc rdx
    inc rsi
    jmp .L182
.L184:
    mov rdx, 0          ; truncate to 0 on overflow
.L183:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 16
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_185
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_185
.alloc_fail_185:
    xor rax, rax        ; return 0 on failure
.alloc_done_185:
    push rax            ; var ptr3
    ; Builtin function @alloc
    mov rax, 16
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_186
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_186
.alloc_fail_186:
    xor rax, rax        ; return 0 on failure
.alloc_done_186:
    push rax            ; var ptr4
    ; Builtin function @poke
    mov rax, [rbp - 96]  ; load ptr3
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 100
    ; @poke is now a no-op for security
    ; Builtin function @poke
    mov rax, [rbp - 104]  ; load ptr4
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 100
    ; @poke is now a no-op for security
    ; Builtin function @memcmp
    mov rax, [rbp - 96]  ; load ptr3
    push rax
    mov rax, [rbp - 104]  ; load ptr4
    push rax
    mov rax, 8
    mov rcx, rax
    pop rsi
    pop rdi
    repe cmpsb          ; compare bytes
    setz al             ; 1 if equal, 0 if not
    movzx rax, al
    push rax            ; var cmp1
    mov rax, [rbp - 112]  ; load cmp1
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L187
    lea rax, [rel .STR189]
section .data
.STR189: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x72, 0x65, 0x67, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x65, 0x71, 0x75, 0x61, 0x6c, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6d, 0x70, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L190:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L192
    cmp byte [rsi], 0
    je .L191
    inc rdx
    inc rsi
    jmp .L190
.L192:
    mov rdx, 0          ; truncate to 0 on overflow
.L191:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L188
.L187:
    lea rax, [rel .STR193]
section .data
.STR193: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6d, 0x70, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L194:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L196
    cmp byte [rsi], 0
    je .L195
    inc rdx
    inc rsi
    jmp .L194
.L196:
    mov rdx, 0          ; truncate to 0 on overflow
.L195:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L188:
    ; Builtin function @free
    mov rax, [rbp - 96]  ; load ptr3
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    ; Builtin function @free
    mov rax, [rbp - 104]  ; load ptr4
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    lea rax, [rel .STR197]
section .data
.STR197: db 0x0a, 0x5b, 0x31, 0x30, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6c, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L198:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L200
    cmp byte [rsi], 0
    je .L199
    inc rdx
    inc rsi
    jmp .L198
.L200:
    mov rdx, 0          ; truncate to 0 on overflow
.L199:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 64
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_201
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_201
.alloc_fail_201:
    xor rax, rax        ; return 0 on failure
.alloc_done_201:
    push rax            ; var ptr5
    ; Builtin function @poke
    mov rax, [rbp - 120]  ; load ptr5
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 999
    ; @poke is now a no-op for security
    ; Builtin function @memclr
    mov rax, [rbp - 120]  ; load ptr5
    push rax
    mov rax, 64
    mov rcx, rax
    pop rdi
    xor al, al
    rep stosb
    ; Builtin function @peek
    mov rax, [rbp - 120]  ; load ptr5
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var cleared
    mov rax, [rbp - 128]  ; load cleared
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L202
    lea rax, [rel .STR204]
section .data
.STR204: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x63, 0x6c, 0x65, 0x61, 0x72, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6c, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L205:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L207
    cmp byte [rsi], 0
    je .L206
    inc rdx
    inc rsi
    jmp .L205
.L207:
    mov rdx, 0          ; truncate to 0 on overflow
.L206:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L203
.L202:
    lea rax, [rel .STR208]
section .data
.STR208: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x65, 0x6d, 0x63, 0x6c, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L209:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L211
    cmp byte [rsi], 0
    je .L210
    inc rdx
    inc rsi
    jmp .L209
.L211:
    mov rdx, 0          ; truncate to 0 on overflow
.L210:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L203:
    ; Builtin function @free
    mov rax, [rbp - 120]  ; load ptr5
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    lea rax, [rel .STR212]
section .data
.STR212: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x41, 0x44, 0x44, 0x49, 0x54, 0x49, 0x4f, 0x4e, 0x41, 0x4c, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L213:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L215
    cmp byte [rsi], 0
    je .L214
    inc rdx
    inc rsi
    jmp .L213
.L215:
    mov rdx, 0          ; truncate to 0 on overflow
.L214:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR216]
section .data
.STR216: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L217:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L219
    cmp byte [rsi], 0
    je .L218
    inc rdx
    inc rsi
    jmp .L217
.L219:
    mov rdx, 0          ; truncate to 0 on overflow
.L218:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR220]
section .data
.STR220: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L221:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L223
    cmp byte [rsi], 0
    je .L222
    inc rdx
    inc rsi
    jmp .L221
.L223:
    mov rdx, 0          ; truncate to 0 on overflow
.L222:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR224]
section .data
.STR224: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L225:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L227
    cmp byte [rsi], 0
    je .L226
    inc rdx
    inc rsi
    jmp .L225
.L227:
    mov rdx, 0          ; truncate to 0 on overflow
.L226:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR228]
section .data
.STR228: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L229:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L231
    cmp byte [rsi], 0
    je .L230
    inc rdx
    inc rsi
    jmp .L229
.L231:
    mov rdx, 0          ; truncate to 0 on overflow
.L230:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L232
    lea rax, [rel .STR234]
section .data
.STR234: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x41, 0x44, 0x44, 0x49, 0x54, 0x49, 0x4f, 0x4e, 0x41, 0x4c, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L235:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L237
    cmp byte [rsi], 0
    je .L236
    inc rdx
    inc rsi
    jmp .L235
.L237:
    mov rdx, 0          ; truncate to 0 on overflow
.L236:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L233
.L232:
    lea rax, [rel .STR238]
section .data
.STR238: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L239:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L241
    cmp byte [rsi], 0
    je .L240
    inc rdx
    inc rsi
    jmp .L239
.L241:
    mov rdx, 0          ; truncate to 0 on overflow
.L240:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L233:
    add rsp, 128         ; pop 16 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
