# Builtin Verification Test Suite

Comprehensive test suite to verify which builtin functions are actually implemented and working correctly in RasCode compiler.

## Test Structure

Each test file focuses on a specific builtin category:

- **test_system_control.ras** - System functions (@clock, @sleep, @exit, @halt, @panic)
- **test_memory_ops.ras** - Memory operations (@alloc, @free, @peek, @poke, @addr, @memcpy, @memset, etc.)
- **test_strings.ras** - String operations (@strlen, @strcmp, @concat, @substr, @upper, @lower, @chr, @ord)
- **test_math.ras** - Math operations (@abs, @min, @max, @pow, @gcd, @isqrt, @isprime, @clz, @popcount)
- **test_conversions.ras** - Type conversions (@type, @to_int, @to_str, @to_deci, @len, @sizeof)
- **test_file_io.ras** - File I/O (@fopen, @fclose, @fread, @fwrite, @fseek, @fdelete)
- **test_synchronization.ras** - Threading/sync (@spawn, @join, @pid, @mutex_*, @semaphore_*, @atomic_*)
- **test_time.ras** - Time functions (@time, @time_ms, @time_us, @srand, @rand_range, etc.)
- **test_sorting.ras** - Sorting/searching (@qsort, @bsearch, @shuffle, @search, @find_min, @find_max, @sum, @average)
- **test_error_handling.ras** - Error handling (@error, @assert, @get_error_code, @get_error_msg, @try_fopen)

## Running Tests

### Individual Test
```bash
cd /home/void/Desktop/RASIDE/RasCode/builtin_verification
../rascom test_system_control.ras -o test_system_control
./test_system_control
```

### All Tests
```bash
chmod +x run_tests.sh
./run_tests.sh
```

## Test Output Format

Each test displays:
- ✓ **Function works** - Builtin is implemented and working correctly
- ✗ **Function failed** - Error during execution
- ⊘ **Function skipped** - Test couldn't run (depends on another builtin)

Example:
```
=== STRING OPERATIONS BUILTINS TEST ===

[1] Testing @strlen[]
Length of 'hello': 5
✓ @strlen WORKS

[2] Testing @strcmp[]
strcmp('hello', 'hello'): 0
✓ @strcmp WORKS (equal strings)
```

## Results File

All test results are logged to `VERIFICATION_RESULTS.txt` for detailed analysis.

## Builtin Status Categories

### Confirmed Working
Tests pass - builtin is properly implemented

### Likely Working but Untested
Some platforms may differ; recommend individual testing

### Known Issues
- Builtin calls without error
- Returns unexpected values
- Platform-specific behavior

### Not Implemented
- Compilation fails
- Runtime error
- Returns error code

## Quick Reference

**Total Built-ins to Test: 199**

Categories:
1. System Control (5)
2. Memory Operations (20)
3. Type Conversion (8)
4. File I/O (6)
5. Network (8)
6. Security (5)
7. String Manipulation (12)
8. Math Operations (15)
9. Hardware & I/O (6)
10. Process Management (17)
11. Synchronization (15)
12. Channels (6)
13. Thread Pool (4)
14. Time & Date (18)
15. Sorting & Arrays (14)
16. Advanced Concurrency (11)
17. Error Handling (10)
18. Meta/Build (4)

## Adding New Tests

Create a new `.ras` file in this directory following the pattern:

```ras
fnc main[]::int {
    show["=== MY BUILTIN CATEGORY TEST ===\n"];
    
    int passed = 0;
    int failed = 0;
    
    // TEST 1: @my_builtin
    show["\n[1] Testing @my_builtin[]\n"];
    try {
        // Call builtin
        int result = @my_builtin[arg];
        
        // Verify result
        if[result == expected] {
            show["✓ @my_builtin WORKS\n"];
            passed = passed + 1;
        } else {
            show["✗ @my_builtin returned wrong value\n"];
            failed = failed + 1;
        }
    } catch {
        show["✗ @my_builtin FAILED (error)\n"];
        failed = failed + 1;
    }
    
    // ... more tests ...
    
    // SUMMARY
    show["\n=== RESULTS ===\n"];
    show["Passed: "];
    show[@itoa[passed]];
    show["\nFailed: "];
    show[@itoa[failed]];
    show["\n"];
    
    if[failed == 0] {
        get[0];
    } else {
        get[1];
    }
}
```

## Expected Outcomes

Each test should:
1. **Compile successfully** - Builtin syntax is recognized
2. **Execute without crash** - No segfaults
3. **Return correct values** - Logic matches documentation
4. **Handle edge cases** - Null pointers, empty strings, etc.

## Known Compilation Gotchas

- Some builtins may not be implemented yet (returns unsupported error)
- Try-catch blocks help identify runtime issues
- Use @itoa to convert integers to strings for display
- String literals use double quotes
- Arrays use curly braces {}

## Next Steps After Testing

1. Document which builtins are working
2. Report bugs for non-working builtins
3. Create integration tests for working builtins
4. Update documentation with real status
5. Prioritize missing implementations

