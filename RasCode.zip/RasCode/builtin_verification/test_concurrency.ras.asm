global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



test_increment:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_2
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_2:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_3
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_3:
    lea rax, [rel .STR4]
section .data
.STR4: db 0x3d, 0x3d, 0x3d, 0x20, 0x43, 0x4f, 0x4e, 0x43, 0x55, 0x52, 0x52, 0x45, 0x4e, 0x43, 0x59, 0x20, 0x26, 0x20, 0x53, 0x59, 0x4e, 0x43, 0x48, 0x52, 0x4f, 0x4e, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L5:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L7
    cmp byte [rsi], 0
    je .L6
    inc rdx
    inc rsi
    jmp .L5
.L7:
    mov rdx, 0          ; truncate to 0 on overflow
.L6:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR8]
section .data
.STR8: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L9:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L11
    cmp byte [rsi], 0
    je .L10
    inc rdx
    inc rsi
    jmp .L9
.L11:
    mov rdx, 0          ; truncate to 0 on overflow
.L10:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @mutex_create
    call sc_mutex_create
    push rax            ; var mutex
    mov rax, [rbp - 24]  ; load mutex
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    cmp rax, 0
    je .L12
    lea rax, [rel .STR14]
section .data
.STR14: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x75, 0x74, 0x65, 0x78, 0x20, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x64, 0x20, 0x28, 0x69, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR18]
section .data
.STR18: db 0x29, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L19:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L21
    cmp byte [rsi], 0
    je .L20
    inc rdx
    inc rsi
    jmp .L19
.L21:
    mov rdx, 0          ; truncate to 0 on overflow
.L20:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L13
.L12:
    lea rax, [rel .STR22]
section .data
.STR22: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L23:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L25
    cmp byte [rsi], 0
    je .L24
    inc rdx
    inc rsi
    jmp .L23
.L25:
    mov rdx, 0          ; truncate to 0 on overflow
.L24:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L13:
    lea rax, [rel .STR26]
section .data
.STR26: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x6c, 0x6f, 0x63, 0x6b, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L27:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L29
    cmp byte [rsi], 0
    je .L28
    inc rdx
    inc rsi
    jmp .L27
.L29:
    mov rdx, 0          ; truncate to 0 on overflow
.L28:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @mutex_lock
    mov rax, [rbp - 24]  ; load mutex
    mov rdi, rax
    call sc_mutex_lock
    push rax            ; var lockres
    mov rax, [rbp - 32]  ; load lockres
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L30
    lea rax, [rel .STR32]
section .data
.STR32: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x75, 0x74, 0x65, 0x78, 0x20, 0x6c, 0x6f, 0x63, 0x6b, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L33:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L35
    cmp byte [rsi], 0
    je .L34
    inc rdx
    inc rsi
    jmp .L33
.L35:
    mov rdx, 0          ; truncate to 0 on overflow
.L34:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L31
.L30:
    lea rax, [rel .STR36]
section .data
.STR36: db 0xe2, 0x8a, 0x98, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x72, 0x65, 0x74, 0x75, 0x72, 0x6e, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR40]
section .data
.STR40: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L41:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L43
    cmp byte [rsi], 0
    je .L42
    inc rdx
    inc rsi
    jmp .L41
.L43:
    mov rdx, 0          ; truncate to 0 on overflow
.L42:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
.L31:
    lea rax, [rel .STR44]
section .data
.STR44: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x75, 0x6e, 0x6c, 0x6f, 0x63, 0x6b, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L45:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L47
    cmp byte [rsi], 0
    je .L46
    inc rdx
    inc rsi
    jmp .L45
.L47:
    mov rdx, 0          ; truncate to 0 on overflow
.L46:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @mutex_unlock
    mov rax, [rbp - 24]  ; load mutex
    mov rdi, rax
    call sc_mutex_unlock
    push rax            ; var unlockres
    lea rax, [rel .STR48]
section .data
.STR48: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x75, 0x74, 0x65, 0x78, 0x20, 0x75, 0x6e, 0x6c, 0x6f, 0x63, 0x6b, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x75, 0x6e, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L49:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L51
    cmp byte [rsi], 0
    je .L50
    inc rdx
    inc rsi
    jmp .L49
.L51:
    mov rdx, 0          ; truncate to 0 on overflow
.L50:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR52]
section .data
.STR52: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x64, 0x65, 0x73, 0x74, 0x72, 0x6f, 0x79, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L53:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L55
    cmp byte [rsi], 0
    je .L54
    inc rdx
    inc rsi
    jmp .L53
.L55:
    mov rdx, 0          ; truncate to 0 on overflow
.L54:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @mutex_destroy
    mov rax, [rbp - 24]  ; load mutex
    mov rdi, rax
    call sc_mutex_destroy
    push rax            ; var destroyres
    lea rax, [rel .STR56]
section .data
.STR56: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x4d, 0x75, 0x74, 0x65, 0x78, 0x20, 0x64, 0x65, 0x73, 0x74, 0x72, 0x6f, 0x79, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x75, 0x74, 0x65, 0x78, 0x5f, 0x64, 0x65, 0x73, 0x74, 0x72, 0x6f, 0x79, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR60]
section .data
.STR60: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x5b, 0x32, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @semaphore_create
    mov rax, 2
    mov rdi, rax
    call sc_semaphore_create
    push rax            ; var sem
    mov rax, [rbp - 56]  ; load sem
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    cmp rax, 0
    je .L64
    lea rax, [rel .STR66]
section .data
.STR66: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x53, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x20, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x64, 0x20, 0x28, 0x69, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L67:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L69
    cmp byte [rsi], 0
    je .L68
    inc rdx
    inc rsi
    jmp .L67
.L69:
    mov rdx, 0          ; truncate to 0 on overflow
.L68:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR70]
section .data
.STR70: db 0x29, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L71:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L73
    cmp byte [rsi], 0
    je .L72
    inc rdx
    inc rsi
    jmp .L71
.L73:
    mov rdx, 0          ; truncate to 0 on overflow
.L72:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L65
.L64:
    lea rax, [rel .STR74]
section .data
.STR74: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L75:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L77
    cmp byte [rsi], 0
    je .L76
    inc rdx
    inc rsi
    jmp .L75
.L77:
    mov rdx, 0          ; truncate to 0 on overflow
.L76:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L65:
    lea rax, [rel .STR78]
section .data
.STR78: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x77, 0x61, 0x69, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @semaphore_wait
    mov rax, [rbp - 56]  ; load sem
    mov rdi, rax
    call sc_semaphore_wait
    push rax            ; var waitres
    lea rax, [rel .STR82]
section .data
.STR82: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x53, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x20, 0x77, 0x61, 0x69, 0x74, 0x20, 0x65, 0x78, 0x65, 0x63, 0x75, 0x74, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x77, 0x61, 0x69, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR86]
section .data
.STR86: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @semaphore_signal
    mov rax, [rbp - 56]  ; load sem
    mov rdi, rax
    call sc_semaphore_signal
    push rax            ; var signalres
    lea rax, [rel .STR90]
section .data
.STR90: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x53, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x6c, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x65, 0x6d, 0x61, 0x70, 0x68, 0x6f, 0x72, 0x65, 0x5f, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x6c, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L91:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L93
    cmp byte [rsi], 0
    je .L92
    inc rdx
    inc rsi
    jmp .L91
.L93:
    mov rdx, 0          ; truncate to 0 on overflow
.L92:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR94]
section .data
.STR94: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x74, 0x6f, 0x6d, 0x69, 0x63, 0x5f, 0x69, 0x6e, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L95:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L97
    cmp byte [rsi], 0
    je .L96
    inc rdx
    inc rsi
    jmp .L95
.L97:
    mov rdx, 0          ; truncate to 0 on overflow
.L96:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 8
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_98
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_98
.alloc_fail_98:
    xor rax, rax        ; return 0 on failure
.alloc_done_98:
    push rax            ; var counter
    ; Builtin function @poke
    mov rax, [rbp - 80]  ; load counter
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 10
    ; @poke is now a no-op for security
    ; Builtin function @atomic_increment
    mov rax, [rbp - 80]  ; load counter
    mov rdi, rax
    call sc_atomic_increment
    push rax            ; var newval
    mov rax, [rbp - 88]  ; load newval
    push rax
    mov rax, 10
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L99
    lea rax, [rel .STR101]
section .data
.STR101: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x49, 0x6e, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x65, 0x64, 0x20, 0x74, 0x6f, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L102:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L104
    cmp byte [rsi], 0
    je .L103
    inc rdx
    inc rsi
    jmp .L102
.L104:
    mov rdx, 0          ; truncate to 0 on overflow
.L103:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR105]
section .data
.STR105: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x61, 0x74, 0x6f, 0x6d, 0x69, 0x63, 0x5f, 0x69, 0x6e, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L106:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L108
    cmp byte [rsi], 0
    je .L107
    inc rdx
    inc rsi
    jmp .L106
.L108:
    mov rdx, 0          ; truncate to 0 on overflow
.L107:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L100
.L99:
    lea rax, [rel .STR109]
section .data
.STR109: db 0xe2, 0x8a, 0x98, 0x20, 0x49, 0x6e, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L110:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L112
    cmp byte [rsi], 0
    je .L111
    inc rdx
    inc rsi
    jmp .L110
.L112:
    mov rdx, 0          ; truncate to 0 on overflow
.L111:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR113]
section .data
.STR113: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L114:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L116
    cmp byte [rsi], 0
    je .L115
    inc rdx
    inc rsi
    jmp .L114
.L116:
    mov rdx, 0          ; truncate to 0 on overflow
.L115:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
.L100:
    lea rax, [rel .STR117]
section .data
.STR117: db 0x0a, 0x5b, 0x39, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x74, 0x6f, 0x6d, 0x69, 0x63, 0x5f, 0x64, 0x65, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L118:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L120
    cmp byte [rsi], 0
    je .L119
    inc rdx
    inc rsi
    jmp .L118
.L120:
    mov rdx, 0          ; truncate to 0 on overflow
.L119:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @atomic_decrement
    mov rax, [rbp - 80]  ; load counter
    mov rdi, rax
    call sc_atomic_decrement
    push rax            ; var decval
    lea rax, [rel .STR121]
section .data
.STR121: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x44, 0x65, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x65, 0x64, 0x20, 0x74, 0x6f, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L122:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L124
    cmp byte [rsi], 0
    je .L123
    inc rdx
    inc rsi
    jmp .L122
.L124:
    mov rdx, 0          ; truncate to 0 on overflow
.L123:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR125]
section .data
.STR125: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x61, 0x74, 0x6f, 0x6d, 0x69, 0x63, 0x5f, 0x64, 0x65, 0x63, 0x72, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L126:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L128
    cmp byte [rsi], 0
    je .L127
    inc rdx
    inc rsi
    jmp .L126
.L128:
    mov rdx, 0          ; truncate to 0 on overflow
.L127:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    ; Builtin function @free
    mov rax, [rbp - 80]  ; load counter
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    lea rax, [rel .STR129]
section .data
.STR129: db 0x0a, 0x5b, 0x31, 0x30, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x68, 0x72, 0x65, 0x61, 0x64, 0x20, 0x63, 0x72, 0x65, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x6f, 0x6e, 0x63, 0x65, 0x70, 0x74, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L130:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L132
    cmp byte [rsi], 0
    je .L131
    inc rdx
    inc rsi
    jmp .L130
.L132:
    mov rdx, 0          ; truncate to 0 on overflow
.L131:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR133]
section .data
.STR133: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x54, 0x68, 0x72, 0x65, 0x61, 0x64, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0xe2, 0x9c, 0x93, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L134:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L136
    cmp byte [rsi], 0
    je .L135
    inc rdx
    inc rsi
    jmp .L134
.L136:
    mov rdx, 0          ; truncate to 0 on overflow
.L135:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    lea rax, [rel .STR137]
section .data
.STR137: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x43, 0x4f, 0x4e, 0x43, 0x55, 0x52, 0x52, 0x45, 0x4e, 0x43, 0x59, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L138:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L140
    cmp byte [rsi], 0
    je .L139
    inc rdx
    inc rsi
    jmp .L138
.L140:
    mov rdx, 0          ; truncate to 0 on overflow
.L139:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR141]
section .data
.STR141: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L142:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L144
    cmp byte [rsi], 0
    je .L143
    inc rdx
    inc rsi
    jmp .L142
.L144:
    mov rdx, 0          ; truncate to 0 on overflow
.L143:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR145]
section .data
.STR145: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L146:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L148
    cmp byte [rsi], 0
    je .L147
    inc rdx
    inc rsi
    jmp .L146
.L148:
    mov rdx, 0          ; truncate to 0 on overflow
.L147:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR149]
section .data
.STR149: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L150:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L152
    cmp byte [rsi], 0
    je .L151
    inc rdx
    inc rsi
    jmp .L150
.L152:
    mov rdx, 0          ; truncate to 0 on overflow
.L151:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR153]
section .data
.STR153: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L154:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L156
    cmp byte [rsi], 0
    je .L155
    inc rdx
    inc rsi
    jmp .L154
.L156:
    mov rdx, 0          ; truncate to 0 on overflow
.L155:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L157
    lea rax, [rel .STR159]
section .data
.STR159: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x43, 0x4f, 0x4e, 0x43, 0x55, 0x52, 0x52, 0x45, 0x4e, 0x43, 0x59, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L160:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L162
    cmp byte [rsi], 0
    je .L161
    inc rdx
    inc rsi
    jmp .L160
.L162:
    mov rdx, 0          ; truncate to 0 on overflow
.L161:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L158
.L157:
    lea rax, [rel .STR163]
section .data
.STR163: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L164:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L166
    cmp byte [rsi], 0
    je .L165
    inc rdx
    inc rsi
    jmp .L164
.L166:
    mov rdx, 0          ; truncate to 0 on overflow
.L165:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L158:
    add rsp, 96         ; pop 12 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
