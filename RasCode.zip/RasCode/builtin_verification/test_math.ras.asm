global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x4d, 0x41, 0x54, 0x48, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x62, 0x73, 0x5b, 0x2d, 0x34, 0x32, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @abs
    mov rax, 42
    neg rax             ; unary minus
    push rax        ; arg 0
    mov rax, 162             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var absval
    mov rax, [rbp - 24]  ; load absval
    push rax
    mov rax, 42
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L10
    lea rax, [rel .STR12]
section .data
.STR12: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L13:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L15
    cmp byte [rsi], 0
    je .L14
    inc rdx
    inc rsi
    jmp .L13
.L15:
    mov rdx, 0          ; truncate to 0 on overflow
.L14:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR16]
section .data
.STR16: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x61, 0x62, 0x73, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L17:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L19
    cmp byte [rsi], 0
    je .L18
    inc rdx
    inc rsi
    jmp .L17
.L19:
    mov rdx, 0          ; truncate to 0 on overflow
.L18:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_20       ; jump if overflow flag set
    jmp .overflow_done_21
.overflow_20:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_21:
    mov [rbp - 8], rax  ; assign passed
    jmp .L11
.L10:
    lea rax, [rel .STR22]
section .data
.STR22: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x61, 0x62, 0x73, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L23:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L25
    cmp byte [rsi], 0
    je .L24
    inc rdx
    inc rsi
    jmp .L23
.L25:
    mov rdx, 0          ; truncate to 0 on overflow
.L24:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_26       ; jump if overflow flag set
    jmp .overflow_done_27
.overflow_26:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_27:
    mov [rbp - 16], rax  ; assign failed
.L11:
    lea rax, [rel .STR28]
section .data
.STR28: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x69, 0x6e, 0x5b, 0x31, 0x30, 0x2c, 0x20, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @min
    mov rax, 10
    push rax        ; arg 0
    mov rax, 5
    push rax        ; arg 1
    mov rax, 163             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var minval
    mov rax, [rbp - 32]  ; load minval
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L32
    lea rax, [rel .STR34]
section .data
.STR34: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L35:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L37
    cmp byte [rsi], 0
    je .L36
    inc rdx
    inc rsi
    jmp .L35
.L37:
    mov rdx, 0          ; truncate to 0 on overflow
.L36:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR38]
section .data
.STR38: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x69, 0x6e, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L39:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L41
    cmp byte [rsi], 0
    je .L40
    inc rdx
    inc rsi
    jmp .L39
.L41:
    mov rdx, 0          ; truncate to 0 on overflow
.L40:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_42       ; jump if overflow flag set
    jmp .overflow_done_43
.overflow_42:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_43:
    mov [rbp - 8], rax  ; assign passed
    jmp .L33
.L32:
    lea rax, [rel .STR44]
section .data
.STR44: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x69, 0x6e, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L45:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L47
    cmp byte [rsi], 0
    je .L46
    inc rdx
    inc rsi
    jmp .L45
.L47:
    mov rdx, 0          ; truncate to 0 on overflow
.L46:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_48       ; jump if overflow flag set
    jmp .overflow_done_49
.overflow_48:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_49:
    mov [rbp - 16], rax  ; assign failed
.L33:
    lea rax, [rel .STR50]
section .data
.STR50: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x61, 0x78, 0x5b, 0x31, 0x30, 0x2c, 0x20, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L51:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L53
    cmp byte [rsi], 0
    je .L52
    inc rdx
    inc rsi
    jmp .L51
.L53:
    mov rdx, 0          ; truncate to 0 on overflow
.L52:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @max
    mov rax, 10
    push rax        ; arg 0
    mov rax, 5
    push rax        ; arg 1
    mov rax, 164             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var maxval
    mov rax, [rbp - 40]  ; load maxval
    push rax
    mov rax, 10
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L54
    lea rax, [rel .STR56]
section .data
.STR56: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR60]
section .data
.STR60: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x61, 0x78, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_64       ; jump if overflow flag set
    jmp .overflow_done_65
.overflow_64:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_65:
    mov [rbp - 8], rax  ; assign passed
    jmp .L55
.L54:
    lea rax, [rel .STR66]
section .data
.STR66: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x61, 0x78, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L67:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L69
    cmp byte [rsi], 0
    je .L68
    inc rdx
    inc rsi
    jmp .L67
.L69:
    mov rdx, 0          ; truncate to 0 on overflow
.L68:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_70       ; jump if overflow flag set
    jmp .overflow_done_71
.overflow_70:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_71:
    mov [rbp - 16], rax  ; assign failed
.L55:
    lea rax, [rel .STR72]
section .data
.STR72: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x67, 0x63, 0x64, 0x5b, 0x32, 0x34, 0x2c, 0x20, 0x33, 0x36, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @gcd
    mov rax, 24
    push rax        ; arg 0
    mov rax, 36
    push rax        ; arg 1
    mov rax, 168             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var gcdval
    mov rax, [rbp - 48]  ; load gcdval
    push rax
    mov rax, 12
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L76
    lea rax, [rel .STR78]
section .data
.STR78: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR82]
section .data
.STR82: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x67, 0x63, 0x64, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_86       ; jump if overflow flag set
    jmp .overflow_done_87
.overflow_86:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_87:
    mov [rbp - 8], rax  ; assign passed
    jmp .L77
.L76:
    lea rax, [rel .STR88]
section .data
.STR88: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x67, 0x63, 0x64, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L89:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L91
    cmp byte [rsi], 0
    je .L90
    inc rdx
    inc rsi
    jmp .L89
.L91:
    mov rdx, 0          ; truncate to 0 on overflow
.L90:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR92]
section .data
.STR92: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L93:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L95
    cmp byte [rsi], 0
    je .L94
    inc rdx
    inc rsi
    jmp .L93
.L95:
    mov rdx, 0          ; truncate to 0 on overflow
.L94:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_96       ; jump if overflow flag set
    jmp .overflow_done_97
.overflow_96:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_97:
    mov [rbp - 16], rax  ; assign failed
.L77:
    lea rax, [rel .STR98]
section .data
.STR98: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6c, 0x63, 0x6d, 0x5b, 0x31, 0x32, 0x2c, 0x20, 0x31, 0x38, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L99:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L101
    cmp byte [rsi], 0
    je .L100
    inc rdx
    inc rsi
    jmp .L99
.L101:
    mov rdx, 0          ; truncate to 0 on overflow
.L100:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @lcm
    mov rax, 12
    push rax        ; arg 0
    mov rax, 18
    push rax        ; arg 1
    mov rax, 169             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var lcmval
    mov rax, [rbp - 56]  ; load lcmval
    push rax
    mov rax, 36
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L102
    lea rax, [rel .STR104]
section .data
.STR104: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR108]
section .data
.STR108: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6c, 0x63, 0x6d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L109:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L111
    cmp byte [rsi], 0
    je .L110
    inc rdx
    inc rsi
    jmp .L109
.L111:
    mov rdx, 0          ; truncate to 0 on overflow
.L110:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_112       ; jump if overflow flag set
    jmp .overflow_done_113
.overflow_112:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_113:
    mov [rbp - 8], rax  ; assign passed
    jmp .L103
.L102:
    lea rax, [rel .STR114]
section .data
.STR114: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6c, 0x63, 0x6d, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L115:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L117
    cmp byte [rsi], 0
    je .L116
    inc rdx
    inc rsi
    jmp .L115
.L117:
    mov rdx, 0          ; truncate to 0 on overflow
.L116:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR118]
section .data
.STR118: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L119:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L121
    cmp byte [rsi], 0
    je .L120
    inc rdx
    inc rsi
    jmp .L119
.L121:
    mov rdx, 0          ; truncate to 0 on overflow
.L120:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_122       ; jump if overflow flag set
    jmp .overflow_done_123
.overflow_122:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_123:
    mov [rbp - 16], rax  ; assign failed
.L103:
    lea rax, [rel .STR124]
section .data
.STR124: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x69, 0x73, 0x71, 0x72, 0x74, 0x5b, 0x32, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L125:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L127
    cmp byte [rsi], 0
    je .L126
    inc rdx
    inc rsi
    jmp .L125
.L127:
    mov rdx, 0          ; truncate to 0 on overflow
.L126:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @isqrt
    mov rax, 25
    push rax        ; arg 0
    mov rax, 160             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var sqrtval
    mov rax, [rbp - 64]  ; load sqrtval
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L128
    lea rax, [rel .STR130]
section .data
.STR130: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L131:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L133
    cmp byte [rsi], 0
    je .L132
    inc rdx
    inc rsi
    jmp .L131
.L133:
    mov rdx, 0          ; truncate to 0 on overflow
.L132:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR134]
section .data
.STR134: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x69, 0x73, 0x71, 0x72, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L135:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L137
    cmp byte [rsi], 0
    je .L136
    inc rdx
    inc rsi
    jmp .L135
.L137:
    mov rdx, 0          ; truncate to 0 on overflow
.L136:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_138       ; jump if overflow flag set
    jmp .overflow_done_139
.overflow_138:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_139:
    mov [rbp - 8], rax  ; assign passed
    jmp .L129
.L128:
    lea rax, [rel .STR140]
section .data
.STR140: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x69, 0x73, 0x71, 0x72, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L141:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L143
    cmp byte [rsi], 0
    je .L142
    inc rdx
    inc rsi
    jmp .L141
.L143:
    mov rdx, 0          ; truncate to 0 on overflow
.L142:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_144       ; jump if overflow flag set
    jmp .overflow_done_145
.overflow_144:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_145:
    mov [rbp - 16], rax  ; assign failed
.L129:
    lea rax, [rel .STR146]
section .data
.STR146: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x69, 0x73, 0x70, 0x72, 0x69, 0x6d, 0x65, 0x5b, 0x37, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L147:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L149
    cmp byte [rsi], 0
    je .L148
    inc rdx
    inc rsi
    jmp .L147
.L149:
    mov rdx, 0          ; truncate to 0 on overflow
.L148:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @isprime
    mov rax, 7
    push rax        ; arg 0
    mov rax, 170             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var isprime
    mov rax, [rbp - 72]  ; load isprime
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L150
    lea rax, [rel .STR152]
section .data
.STR152: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L153:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L155
    cmp byte [rsi], 0
    je .L154
    inc rdx
    inc rsi
    jmp .L153
.L155:
    mov rdx, 0          ; truncate to 0 on overflow
.L154:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR156]
section .data
.STR156: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x69, 0x73, 0x70, 0x72, 0x69, 0x6d, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L157:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L159
    cmp byte [rsi], 0
    je .L158
    inc rdx
    inc rsi
    jmp .L157
.L159:
    mov rdx, 0          ; truncate to 0 on overflow
.L158:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_160       ; jump if overflow flag set
    jmp .overflow_done_161
.overflow_160:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_161:
    mov [rbp - 8], rax  ; assign passed
    jmp .L151
.L150:
    lea rax, [rel .STR162]
section .data
.STR162: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x69, 0x73, 0x70, 0x72, 0x69, 0x6d, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L163:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L165
    cmp byte [rsi], 0
    je .L164
    inc rdx
    inc rsi
    jmp .L163
.L165:
    mov rdx, 0          ; truncate to 0 on overflow
.L164:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_166       ; jump if overflow flag set
    jmp .overflow_done_167
.overflow_166:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_167:
    mov [rbp - 16], rax  ; assign failed
.L151:
    lea rax, [rel .STR168]
section .data
.STR168: db 0x0a, 0x5b, 0x38, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x6f, 0x77, 0x5b, 0x32, 0x2c, 0x20, 0x38, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L169:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L171
    cmp byte [rsi], 0
    je .L170
    inc rdx
    inc rsi
    jmp .L169
.L171:
    mov rdx, 0          ; truncate to 0 on overflow
.L170:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @pow
    mov rax, 2
    push rax        ; arg 0
    mov rax, 8
    push rax        ; arg 1
    mov rax, 161             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var powval
    mov rax, [rbp - 80]  ; load powval
    push rax
    mov rax, 256
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L172
    lea rax, [rel .STR174]
section .data
.STR174: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L175:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L177
    cmp byte [rsi], 0
    je .L176
    inc rdx
    inc rsi
    jmp .L175
.L177:
    mov rdx, 0          ; truncate to 0 on overflow
.L176:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR178]
section .data
.STR178: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x70, 0x6f, 0x77, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L179:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L181
    cmp byte [rsi], 0
    je .L180
    inc rdx
    inc rsi
    jmp .L179
.L181:
    mov rdx, 0          ; truncate to 0 on overflow
.L180:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_182       ; jump if overflow flag set
    jmp .overflow_done_183
.overflow_182:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_183:
    mov [rbp - 8], rax  ; assign passed
    jmp .L173
.L172:
    lea rax, [rel .STR184]
section .data
.STR184: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x70, 0x6f, 0x77, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L185:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L187
    cmp byte [rsi], 0
    je .L186
    inc rdx
    inc rsi
    jmp .L185
.L187:
    mov rdx, 0          ; truncate to 0 on overflow
.L186:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_188       ; jump if overflow flag set
    jmp .overflow_done_189
.overflow_188:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_189:
    mov [rbp - 16], rax  ; assign failed
.L173:
    lea rax, [rel .STR190]
section .data
.STR190: db 0x0a, 0x5b, 0x39, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6d, 0x6f, 0x64, 0x70, 0x6f, 0x77, 0x5b, 0x32, 0x2c, 0x20, 0x38, 0x2c, 0x20, 0x31, 0x30, 0x30, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L191:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L193
    cmp byte [rsi], 0
    je .L192
    inc rdx
    inc rsi
    jmp .L191
.L193:
    mov rdx, 0          ; truncate to 0 on overflow
.L192:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @modpow
    mov rax, 2
    push rax        ; arg 0
    mov rax, 8
    push rax        ; arg 1
    mov rax, 100
    mov r12, rax    ; arg 2
    mov rax, 171             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var modpowval
    mov rax, [rbp - 88]  ; load modpowval
    push rax
    mov rax, 56
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L194
    lea rax, [rel .STR196]
section .data
.STR196: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L197:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L199
    cmp byte [rsi], 0
    je .L198
    inc rdx
    inc rsi
    jmp .L197
.L199:
    mov rdx, 0          ; truncate to 0 on overflow
.L198:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR200]
section .data
.STR200: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6d, 0x6f, 0x64, 0x70, 0x6f, 0x77, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L201:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L203
    cmp byte [rsi], 0
    je .L202
    inc rdx
    inc rsi
    jmp .L201
.L203:
    mov rdx, 0          ; truncate to 0 on overflow
.L202:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_204       ; jump if overflow flag set
    jmp .overflow_done_205
.overflow_204:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_205:
    mov [rbp - 8], rax  ; assign passed
    jmp .L195
.L194:
    lea rax, [rel .STR206]
section .data
.STR206: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6d, 0x6f, 0x64, 0x70, 0x6f, 0x77, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L207:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L209
    cmp byte [rsi], 0
    je .L208
    inc rdx
    inc rsi
    jmp .L207
.L209:
    mov rdx, 0          ; truncate to 0 on overflow
.L208:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR210]
section .data
.STR210: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L211:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L213
    cmp byte [rsi], 0
    je .L212
    inc rdx
    inc rsi
    jmp .L211
.L213:
    mov rdx, 0          ; truncate to 0 on overflow
.L212:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_214       ; jump if overflow flag set
    jmp .overflow_done_215
.overflow_214:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_215:
    mov [rbp - 16], rax  ; assign failed
.L195:
    lea rax, [rel .STR216]
section .data
.STR216: db 0x0a, 0x5b, 0x31, 0x30, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x70, 0x6f, 0x70, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x5b, 0x31, 0x35, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L217:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L219
    cmp byte [rsi], 0
    je .L218
    inc rdx
    inc rsi
    jmp .L217
.L219:
    mov rdx, 0          ; truncate to 0 on overflow
.L218:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @popcount
    mov rax, 15
    push rax        ; arg 0
    mov rax, 167             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var popcount
    mov rax, [rbp - 96]  ; load popcount
    push rax
    mov rax, 4
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L220
    lea rax, [rel .STR222]
section .data
.STR222: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L223:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L225
    cmp byte [rsi], 0
    je .L224
    inc rdx
    inc rsi
    jmp .L223
.L225:
    mov rdx, 0          ; truncate to 0 on overflow
.L224:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR226]
section .data
.STR226: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x70, 0x6f, 0x70, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L227:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L229
    cmp byte [rsi], 0
    je .L228
    inc rdx
    inc rsi
    jmp .L227
.L229:
    mov rdx, 0          ; truncate to 0 on overflow
.L228:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_230       ; jump if overflow flag set
    jmp .overflow_done_231
.overflow_230:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_231:
    mov [rbp - 8], rax  ; assign passed
    jmp .L221
.L220:
    lea rax, [rel .STR232]
section .data
.STR232: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x70, 0x6f, 0x70, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L233:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L235
    cmp byte [rsi], 0
    je .L234
    inc rdx
    inc rsi
    jmp .L233
.L235:
    mov rdx, 0          ; truncate to 0 on overflow
.L234:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_236       ; jump if overflow flag set
    jmp .overflow_done_237
.overflow_236:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_237:
    mov [rbp - 16], rax  ; assign failed
.L221:
    lea rax, [rel .STR238]
section .data
.STR238: db 0x0a, 0x5b, 0x31, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x6c, 0x7a, 0x5b, 0x31, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L239:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L241
    cmp byte [rsi], 0
    je .L240
    inc rdx
    inc rsi
    jmp .L239
.L241:
    mov rdx, 0          ; truncate to 0 on overflow
.L240:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @clz
    mov rax, 1
    push rax        ; arg 0
    mov rax, 165             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var clzval
    mov rax, [rbp - 104]  ; load clzval
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    cmp rax, 0
    je .L242
    lea rax, [rel .STR244]
section .data
.STR244: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L245:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L247
    cmp byte [rsi], 0
    je .L246
    inc rdx
    inc rsi
    jmp .L245
.L247:
    mov rdx, 0          ; truncate to 0 on overflow
.L246:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR248]
section .data
.STR248: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x6c, 0x7a, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L249:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L251
    cmp byte [rsi], 0
    je .L250
    inc rdx
    inc rsi
    jmp .L249
.L251:
    mov rdx, 0          ; truncate to 0 on overflow
.L250:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_252       ; jump if overflow flag set
    jmp .overflow_done_253
.overflow_252:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_253:
    mov [rbp - 8], rax  ; assign passed
    jmp .L243
.L242:
    lea rax, [rel .STR254]
section .data
.STR254: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x6c, 0x7a, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L255:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L257
    cmp byte [rsi], 0
    je .L256
    inc rdx
    inc rsi
    jmp .L255
.L257:
    mov rdx, 0          ; truncate to 0 on overflow
.L256:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_258       ; jump if overflow flag set
    jmp .overflow_done_259
.overflow_258:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_259:
    mov [rbp - 16], rax  ; assign failed
.L243:
    lea rax, [rel .STR260]
section .data
.STR260: db 0x0a, 0x5b, 0x31, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x74, 0x7a, 0x5b, 0x38, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L261:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L263
    cmp byte [rsi], 0
    je .L262
    inc rdx
    inc rsi
    jmp .L261
.L263:
    mov rdx, 0          ; truncate to 0 on overflow
.L262:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @ctz
    mov rax, 8
    push rax        ; arg 0
    mov rax, 166             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var ctzval
    mov rax, [rbp - 112]  ; load ctzval
    push rax
    mov rax, 3
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L264
    lea rax, [rel .STR266]
section .data
.STR266: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L267:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L269
    cmp byte [rsi], 0
    je .L268
    inc rdx
    inc rsi
    jmp .L267
.L269:
    mov rdx, 0          ; truncate to 0 on overflow
.L268:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR270]
section .data
.STR270: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x74, 0x7a, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L271:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L273
    cmp byte [rsi], 0
    je .L272
    inc rdx
    inc rsi
    jmp .L271
.L273:
    mov rdx, 0          ; truncate to 0 on overflow
.L272:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_274       ; jump if overflow flag set
    jmp .overflow_done_275
.overflow_274:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_275:
    mov [rbp - 8], rax  ; assign passed
    jmp .L265
.L264:
    lea rax, [rel .STR276]
section .data
.STR276: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x63, 0x74, 0x7a, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L277:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L279
    cmp byte [rsi], 0
    je .L278
    inc rdx
    inc rsi
    jmp .L277
.L279:
    mov rdx, 0          ; truncate to 0 on overflow
.L278:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR280]
section .data
.STR280: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L281:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L283
    cmp byte [rsi], 0
    je .L282
    inc rdx
    inc rsi
    jmp .L281
.L283:
    mov rdx, 0          ; truncate to 0 on overflow
.L282:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_284       ; jump if overflow flag set
    jmp .overflow_done_285
.overflow_284:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_285:
    mov [rbp - 16], rax  ; assign failed
.L265:
    lea rax, [rel .STR286]
section .data
.STR286: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x4d, 0x41, 0x54, 0x48, 0x20, 0x4f, 0x50, 0x45, 0x52, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x53, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L287:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L289
    cmp byte [rsi], 0
    je .L288
    inc rdx
    inc rsi
    jmp .L287
.L289:
    mov rdx, 0          ; truncate to 0 on overflow
.L288:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR290]
section .data
.STR290: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L291:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L293
    cmp byte [rsi], 0
    je .L292
    inc rdx
    inc rsi
    jmp .L291
.L293:
    mov rdx, 0          ; truncate to 0 on overflow
.L292:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR294]
section .data
.STR294: db 0x0a, 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L295:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L297
    cmp byte [rsi], 0
    je .L296
    inc rdx
    inc rsi
    jmp .L295
.L297:
    mov rdx, 0          ; truncate to 0 on overflow
.L296:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR298]
section .data
.STR298: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L299:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L301
    cmp byte [rsi], 0
    je .L300
    inc rdx
    inc rsi
    jmp .L299
.L301:
    mov rdx, 0          ; truncate to 0 on overflow
.L300:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L302
    lea rax, [rel .STR304]
section .data
.STR304: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L305:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L307
    cmp byte [rsi], 0
    je .L306
    inc rdx
    inc rsi
    jmp .L305
.L307:
    mov rdx, 0          ; truncate to 0 on overflow
.L306:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L303
.L302:
    lea rax, [rel .STR308]
section .data
.STR308: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L309:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L311
    cmp byte [rsi], 0
    je .L310
    inc rdx
    inc rsi
    jmp .L309
.L311:
    mov rdx, 0          ; truncate to 0 on overflow
.L310:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L303:
    add rsp, 112         ; pop 14 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
