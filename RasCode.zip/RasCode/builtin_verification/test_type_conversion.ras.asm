global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x54, 0x59, 0x50, 0x45, 0x20, 0x43, 0x4f, 0x4e, 0x56, 0x45, 0x52, 0x53, 0x49, 0x4f, 0x4e, 0x20, 0x42, 0x55, 0x49, 0x4c, 0x54, 0x49, 0x4e, 0x53, 0x20, 0x54, 0x45, 0x53, 0x54, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var passed
    mov rax, 0
    push rax            ; var failed
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x5b, 0x31, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x69, 0x6e, 0x74, 0x5b, 0x22, 0x34, 0x32, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_int
    lea rax, [rel .STR10]
section .data
.STR10: db 0x34, 0x32, 0x00
section .text
    push rax            ; var val1
    mov rax, [rbp - 24]  ; load val1
    push rax
    mov rax, 42
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L11
    lea rax, [rel .STR13]
section .data
.STR13: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L14:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L16
    cmp byte [rsi], 0
    je .L15
    inc rdx
    inc rsi
    jmp .L14
.L16:
    mov rdx, 0          ; truncate to 0 on overflow
.L15:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR17]
section .data
.STR17: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x69, 0x6e, 0x74, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L18:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L20
    cmp byte [rsi], 0
    je .L19
    inc rdx
    inc rsi
    jmp .L18
.L20:
    mov rdx, 0          ; truncate to 0 on overflow
.L19:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L12
.L11:
    lea rax, [rel .STR21]
section .data
.STR21: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x69, 0x6e, 0x74, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L22:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L24
    cmp byte [rsi], 0
    je .L23
    inc rdx
    inc rsi
    jmp .L22
.L24:
    mov rdx, 0          ; truncate to 0 on overflow
.L23:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR25]
section .data
.STR25: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L26:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L28
    cmp byte [rsi], 0
    je .L27
    inc rdx
    inc rsi
    jmp .L26
.L28:
    mov rdx, 0          ; truncate to 0 on overflow
.L27:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L12:
    lea rax, [rel .STR29]
section .data
.STR29: db 0x0a, 0x5b, 0x32, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x73, 0x74, 0x72, 0x5b, 0x31, 0x30, 0x30, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L30:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L32
    cmp byte [rsi], 0
    je .L31
    inc rdx
    inc rsi
    jmp .L30
.L32:
    mov rdx, 0          ; truncate to 0 on overflow
.L31:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    push rax            ; var strval
    mov rax, [rbp - 32]  ; load strval
    push rax
    lea rax, [rel .STR35]
section .data
.STR35: db 0x31, 0x30, 0x30, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L33
    lea rax, [rel .STR36]
section .data
.STR36: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load strval
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L40:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L42
    cmp byte [rsi], 0
    je .L41
    inc rdx
    inc rsi
    jmp .L40
.L42:
    mov rdx, 0          ; truncate to 0 on overflow
.L41:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR43]
section .data
.STR43: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x73, 0x74, 0x72, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L34
.L33:
    lea rax, [rel .STR47]
section .data
.STR47: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x73, 0x74, 0x72, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load strval
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L51:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L53
    cmp byte [rsi], 0
    je .L52
    inc rdx
    inc rsi
    jmp .L51
.L53:
    mov rdx, 0          ; truncate to 0 on overflow
.L52:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR54]
section .data
.STR54: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L55:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L57
    cmp byte [rsi], 0
    je .L56
    inc rdx
    inc rsi
    jmp .L55
.L57:
    mov rdx, 0          ; truncate to 0 on overflow
.L56:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L34:
    lea rax, [rel .STR58]
section .data
.STR58: db 0x0a, 0x5b, 0x33, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x5b, 0x31, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L59:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L61
    cmp byte [rsi], 0
    je .L60
    inc rdx
    inc rsi
    jmp .L59
.L61:
    mov rdx, 0          ; truncate to 0 on overflow
.L60:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_bool
    mov rax, 1
    test rax, rax       ; check if zero
    setnz al            ; set if not zero
    movzx rax, al       ; zero extend to 64-bit
    push rax            ; var boolval
    mov rax, [rbp - 40]  ; load boolval
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L62
    lea rax, [rel .STR64]
section .data
.STR64: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x74, 0x72, 0x75, 0x65, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L63
.L62:
    lea rax, [rel .STR68]
section .data
.STR68: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L63:
    lea rax, [rel .STR72]
section .data
.STR72: db 0x0a, 0x5b, 0x34, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x5b, 0x30, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_bool
    mov rax, 0
    test rax, rax       ; check if zero
    setnz al            ; set if not zero
    movzx rax, al       ; zero extend to 64-bit
    push rax            ; var boolval2
    mov rax, [rbp - 48]  ; load boolval2
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L76
    lea rax, [rel .STR78]
section .data
.STR78: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x66, 0x61, 0x6c, 0x73, 0x65, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x5b, 0x30, 0x5d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L77
.L76:
    lea rax, [rel .STR82]
section .data
.STR82: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x62, 0x6f, 0x6f, 0x6c, 0x5b, 0x30, 0x5d, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L77:
    lea rax, [rel .STR86]
section .data
.STR86: db 0x0a, 0x5b, 0x35, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x5b, 0x22, 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @len
    lea rax, [rel .STR90]
section .data
.STR90: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    mov rdi, rax
    xor rcx, rcx
.len_loop_91:
    cmp byte [rdi+rcx], 0
    je .len_done_91
    inc rcx
    jmp .len_loop_91
.len_done_91:
    mov rax, rcx
    push rax            ; var len1
    mov rax, [rbp - 56]  ; load len1
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L92
    lea rax, [rel .STR94]
section .data
.STR94: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L95:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L97
    cmp byte [rsi], 0
    je .L96
    inc rdx
    inc rsi
    jmp .L95
.L97:
    mov rdx, 0          ; truncate to 0 on overflow
.L96:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR98]
section .data
.STR98: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L99:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L101
    cmp byte [rsi], 0
    je .L100
    inc rdx
    inc rsi
    jmp .L99
.L101:
    mov rdx, 0          ; truncate to 0 on overflow
.L100:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L93
.L92:
    lea rax, [rel .STR102]
section .data
.STR102: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L103:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L105
    cmp byte [rsi], 0
    je .L104
    inc rdx
    inc rsi
    jmp .L103
.L105:
    mov rdx, 0          ; truncate to 0 on overflow
.L104:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR106]
section .data
.STR106: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L107:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L109
    cmp byte [rsi], 0
    je .L108
    inc rdx
    inc rsi
    jmp .L107
.L109:
    mov rdx, 0          ; truncate to 0 on overflow
.L108:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L93:
    lea rax, [rel .STR110]
section .data
.STR110: db 0x0a, 0x5b, 0x36, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x5b, 0x34, 0x32, 0x5d, 0x3a, 0x3a, 0x73, 0x74, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L111:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L113
    cmp byte [rsi], 0
    je .L112
    inc rdx
    inc rsi
    jmp .L111
.L113:
    mov rdx, 0          ; truncate to 0 on overflow
.L112:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @type
    mov rax, 42
    lea rax, [rel .TODO_STR]
    push rax            ; var str_from_int
    mov rax, [rbp - 64]  ; load str_from_int
    push rax
    lea rax, [rel .STR116]
section .data
.STR116: db 0x34, 0x32, 0x00
section .text
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L114
    lea rax, [rel .STR117]
section .data
.STR117: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L118:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L120
    cmp byte [rsi], 0
    je .L119
    inc rdx
    inc rsi
    jmp .L118
.L120:
    mov rdx, 0          ; truncate to 0 on overflow
.L119:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load str_from_int
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L121:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L123
    cmp byte [rsi], 0
    je .L122
    inc rdx
    inc rsi
    jmp .L121
.L123:
    mov rdx, 0          ; truncate to 0 on overflow
.L122:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR124]
section .data
.STR124: db 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L125:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L127
    cmp byte [rsi], 0
    je .L126
    inc rdx
    inc rsi
    jmp .L125
.L127:
    mov rdx, 0          ; truncate to 0 on overflow
.L126:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L115
.L114:
    lea rax, [rel .STR128]
section .data
.STR128: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x20, 0x28, 0x67, 0x6f, 0x74, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L129:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L131
    cmp byte [rsi], 0
    je .L130
    inc rdx
    inc rsi
    jmp .L129
.L131:
    mov rdx, 0          ; truncate to 0 on overflow
.L130:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load str_from_int
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L132:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L134
    cmp byte [rsi], 0
    je .L133
    inc rdx
    inc rsi
    jmp .L132
.L134:
    mov rdx, 0          ; truncate to 0 on overflow
.L133:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR135]
section .data
.STR135: db 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L136:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L138
    cmp byte [rsi], 0
    je .L137
    inc rdx
    inc rsi
    jmp .L136
.L138:
    mov rdx, 0          ; truncate to 0 on overflow
.L137:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L115:
    lea rax, [rel .STR139]
section .data
.STR139: db 0x0a, 0x5b, 0x37, 0x5d, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x5b, 0x31, 0x5d, 0x3a, 0x3a, 0x62, 0x6f, 0x6f, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L140:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L142
    cmp byte [rsi], 0
    je .L141
    inc rdx
    inc rsi
    jmp .L140
.L142:
    mov rdx, 0          ; truncate to 0 on overflow
.L141:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @type
    mov rax, 1
    test rax, rax
    setnz al
    movzx rax, al
    push rax            ; var bool_from_int
    mov rax, [rbp - 72]  ; load bool_from_int
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L143
    lea rax, [rel .STR145]
section .data
.STR145: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x74, 0x72, 0x75, 0x65, 0x20, 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x3a, 0x3a, 0x62, 0x6f, 0x6f, 0x6c, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L146:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L148
    cmp byte [rsi], 0
    je .L147
    inc rdx
    inc rsi
    jmp .L146
.L148:
    mov rdx, 0          ; truncate to 0 on overflow
.L147:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load passed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 8], rax  ; assign passed
    jmp .L144
.L143:
    lea rax, [rel .STR149]
section .data
.STR149: db 0xe2, 0x9c, 0x97, 0x20, 0x40, 0x74, 0x79, 0x70, 0x65, 0x3a, 0x3a, 0x62, 0x6f, 0x6f, 0x6c, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L150:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L152
    cmp byte [rsi], 0
    je .L151
    inc rdx
    inc rsi
    jmp .L150
.L152:
    mov rdx, 0          ; truncate to 0 on overflow
.L151:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign failed
.L144:
    lea rax, [rel .STR153]
section .data
.STR153: db 0x0a, 0x3d, 0x3d, 0x3d, 0x20, 0x54, 0x59, 0x50, 0x45, 0x20, 0x43, 0x4f, 0x4e, 0x56, 0x45, 0x52, 0x53, 0x49, 0x4f, 0x4e, 0x20, 0x52, 0x45, 0x53, 0x55, 0x4c, 0x54, 0x53, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L154:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L156
    cmp byte [rsi], 0
    je .L155
    inc rdx
    inc rsi
    jmp .L154
.L156:
    mov rdx, 0          ; truncate to 0 on overflow
.L155:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR157]
section .data
.STR157: db 0x50, 0x61, 0x73, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L158:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L160
    cmp byte [rsi], 0
    je .L159
    inc rdx
    inc rsi
    jmp .L158
.L160:
    mov rdx, 0          ; truncate to 0 on overflow
.L159:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR161]
section .data
.STR161: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L162:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L164
    cmp byte [rsi], 0
    je .L163
    inc rdx
    inc rsi
    jmp .L162
.L164:
    mov rdx, 0          ; truncate to 0 on overflow
.L163:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR165]
section .data
.STR165: db 0x46, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L166:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L168
    cmp byte [rsi], 0
    je .L167
    inc rdx
    inc rsi
    jmp .L166
.L168:
    mov rdx, 0          ; truncate to 0 on overflow
.L167:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR169]
section .data
.STR169: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L170:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L172
    cmp byte [rsi], 0
    je .L171
    inc rdx
    inc rsi
    jmp .L170
.L172:
    mov rdx, 0          ; truncate to 0 on overflow
.L171:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load failed
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L173
    lea rax, [rel .STR175]
section .data
.STR175: db 0xe2, 0x9c, 0x93, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x54, 0x59, 0x50, 0x45, 0x20, 0x43, 0x4f, 0x4e, 0x56, 0x45, 0x52, 0x53, 0x49, 0x4f, 0x4e, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x50, 0x41, 0x53, 0x53, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L176:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L178
    cmp byte [rsi], 0
    je .L177
    inc rdx
    inc rsi
    jmp .L176
.L178:
    mov rdx, 0          ; truncate to 0 on overflow
.L177:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L174
.L173:
    lea rax, [rel .STR179]
section .data
.STR179: db 0xe2, 0x9c, 0x97, 0x20, 0x53, 0x4f, 0x4d, 0x45, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L180:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L182
    cmp byte [rsi], 0
    je .L181
    inc rdx
    inc rsi
    jmp .L180
.L182:
    mov rdx, 0          ; truncate to 0 on overflow
.L181:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L174:
    add rsp, 72         ; pop 9 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
