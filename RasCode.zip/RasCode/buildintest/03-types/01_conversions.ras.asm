global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x54, 0x79, 0x70, 0x65, 0x20, 0x43, 0x6f, 0x6e, 0x76, 0x65, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x42, 0x75, 0x69, 0x6c, 0x74, 0x69, 0x6e, 0x73, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR6]
section .data
.STR6: db 0x0a, 0x31, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x69, 0x74, 0x6f, 0x61, 0x5b, 0x34, 0x32, 0x5d, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L7:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L9
    cmp byte [rsi], 0
    je .L8
    inc rdx
    inc rsi
    jmp .L7
.L9:
    mov rdx, 0          ; truncate to 0 on overflow
.L8:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var s42
    lea rax, [rel .STR10]
section .data
.STR10: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L11:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L13
    cmp byte [rsi], 0
    je .L12
    inc rdx
    inc rsi
    jmp .L11
.L13:
    mov rdx, 0          ; truncate to 0 on overflow
.L12:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load s42
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L14:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L16
    cmp byte [rsi], 0
    je .L15
    inc rdx
    inc rsi
    jmp .L14
.L16:
    mov rdx, 0          ; truncate to 0 on overflow
.L15:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR17]
section .data
.STR17: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L18:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L20
    cmp byte [rsi], 0
    je .L19
    inc rdx
    inc rsi
    jmp .L18
.L20:
    mov rdx, 0          ; truncate to 0 on overflow
.L19:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR21]
section .data
.STR21: db 0x0a, 0x32, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x61, 0x74, 0x6f, 0x69, 0x5b, 0x22, 0x31, 0x32, 0x33, 0x22, 0x5d, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L22:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L24
    cmp byte [rsi], 0
    je .L23
    inc rdx
    inc rsi
    jmp .L22
.L24:
    mov rdx, 0          ; truncate to 0 on overflow
.L23:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var i123
    lea rax, [rel .STR25]
section .data
.STR25: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L26:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L28
    cmp byte [rsi], 0
    je .L27
    inc rdx
    inc rsi
    jmp .L26
.L28:
    mov rdx, 0          ; truncate to 0 on overflow
.L27:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load i123
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR29]
section .data
.STR29: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L30:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L32
    cmp byte [rsi], 0
    je .L31
    inc rdx
    inc rsi
    jmp .L30
.L32:
    mov rdx, 0          ; truncate to 0 on overflow
.L31:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR33]
section .data
.STR33: db 0x0a, 0x33, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x63, 0x68, 0x72, 0x5b, 0x36, 0x35, 0x5d, 0x20, 0x28, 0x41, 0x53, 0x43, 0x49, 0x49, 0x20, 0x36, 0x35, 0x20, 0x3d, 0x20, 0x27, 0x41, 0x27, 0x29, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L34:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L36
    cmp byte [rsi], 0
    je .L35
    inc rdx
    inc rsi
    jmp .L34
.L36:
    mov rdx, 0          ; truncate to 0 on overflow
.L35:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @chr
    mov rax, 65
    and rax, 0xFF       ; keep only byte
    push rax            ; var c65
    lea rax, [rel .STR37]
section .data
.STR37: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L38:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L40
    cmp byte [rsi], 0
    je .L39
    inc rdx
    inc rsi
    jmp .L38
.L40:
    mov rdx, 0          ; truncate to 0 on overflow
.L39:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load c65
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR41]
section .data
.STR41: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L42:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L44
    cmp byte [rsi], 0
    je .L43
    inc rdx
    inc rsi
    jmp .L42
.L44:
    mov rdx, 0          ; truncate to 0 on overflow
.L43:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR45]
section .data
.STR45: db 0x0a, 0x34, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6f, 0x72, 0x64, 0x5b, 0x27, 0x41, 0x27, 0x5d, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L46:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L48
    cmp byte [rsi], 0
    je .L47
    inc rdx
    inc rsi
    jmp .L46
.L48:
    mov rdx, 0          ; truncate to 0 on overflow
.L47:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @ord
    mov rax, 65
    movzx rax, al       ; zero extend byte
    push rax            ; var ord_a
    lea rax, [rel .STR49]
section .data
.STR49: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L50:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L52
    cmp byte [rsi], 0
    je .L51
    inc rdx
    inc rsi
    jmp .L50
.L52:
    mov rdx, 0          ; truncate to 0 on overflow
.L51:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load ord_a
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR53]
section .data
.STR53: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L54:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L56
    cmp byte [rsi], 0
    je .L55
    inc rdx
    inc rsi
    jmp .L54
.L56:
    mov rdx, 0          ; truncate to 0 on overflow
.L55:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load i123
    push rax
    mov rax, 123
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L59             ; if false, skip right
    mov rax, [rbp - 32]  ; load ord_a
    push rax
    mov rax, 65
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L59             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L60
.L59:
    xor rax, rax        ; result is 0
.L60:
    cmp rax, 0
    je .L57
    lea rax, [rel .STR61]
section .data
.STR61: db 0x0a, 0xe2, 0x9c, 0x93, 0x20, 0x54, 0x79, 0x70, 0x65, 0x20, 0x63, 0x6f, 0x6e, 0x76, 0x65, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x62, 0x75, 0x69, 0x6c, 0x74, 0x69, 0x6e, 0x73, 0x20, 0x77, 0x6f, 0x72, 0x6b, 0x69, 0x6e, 0x67, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L62:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L64
    cmp byte [rsi], 0
    je .L63
    inc rdx
    inc rsi
    jmp .L62
.L64:
    mov rdx, 0          ; truncate to 0 on overflow
.L63:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L58
.L57:
.L58:
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 32         ; pop 4 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
