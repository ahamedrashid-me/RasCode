# RasCode Builtin Testing Framework - Quick Guide

## Overview
This testing framework comprehensively verifies the RasCode builtin functions across 13 categories.

**Current Status: 92% Pass Rate (24/26 tests)**

## Quick Start

```bash
# Run all tests
cd /home/void/Desktop/RASIDE/RasCode
./run_buildin_tests.sh

# Test a specific category
./rascom buildintest/01-system/01_exit.ras -o test_bin
```

## Test Categories

### [01-system/](01-system/) - System Control Functions
Tests for program flow control, timing, and system operations.
- `@exit` - Exit with code
- `@halt` - Immediate halt
- `@sleep` - Sleep milliseconds
- `@clock` - Get current time
- `@panic` - Panic with message

**Status:** ✅ 5/5 PASS (100%)

### [02-memory/](02-memory/) - Memory Operations
Tests for heap allocation, memory access, and dereferencing.
- `@alloc`, `@free` - Memory allocation
- `@peek`, `@poke` - Memory access
- `@addr` - Get variable address

**Status:** ✅ 3/3 PASS (100%)

### [03-types/](03-types/) - Type Conversion
Tests for converting between different RasCode types.
- `@itoa`, `@atoi` - Integer/string conversion
- `@chr`, `@ord` - Character conversion  
- `@itod`, `@dtoi` - Decimal conversion

**Status:** ✅ 2/2 PASS (100%)

### [04-strings/](04-strings/) - String Operations
Tests for string manipulation and analysis.
- `@strlen` - String length
- `@strlowcase`, `@strupcase` - Case conversion
- `@strcat`, `@strcmp` - String operations

**Status:** ✅ 2/2 PASS (100%)

### [05-fileio/](05-fileio/) - File I/O
Tests for file reading/writing and positioning.
- `@fopen`, `@fclose` - File operations
- `@fwrite`, `@fread` - File data transfer
- `@fseek`, `@ftell`, `@feof` - File positioning

**Status:** ✅ 2/2 PASS (100%)

### [06-network/](06-network/) - Network Operations
Tests for socket operations and network communication.
- `@socket` - Create socket
- `@close` - Close socket
- `@send`, `@recv` - Data transfer
- `@bind`, `@listen`, `@accept`, `@connect` - Connection management

**Status:** ✅ 2/2 PASS (100%)

### [07-security/](07-security/) - Security & Cryptography
Tests for random number generation and hashing.
- `@rand` - Random number ✅
- `@getrandom` - Random bytes ✅
- `@md5` - MD5 hash ❌ NOT IMPLEMENTED
- `@sha1` - SHA1 hash ❌ NOT IMPLEMENTED
- `@sha256` - SHA256 hash ❌ NOT IMPLEMENTED

**Status:** ⚠️ 1/2 PASS (50%)

### [08-hardware/](08-hardware/) - Hardware I/O
Tests for direct port I/O operations.
- `@inb`, `@outb` - Byte port I/O
- `@inw`, `@outw` - Word port I/O
- `@inl`, `@outl` - Long port I/O

**Status:** ✅ 1/1 PASS (100%)

### [09-threading/](09-threading/) - Threading
Tests for thread creation and management.
- `@thread_create` - Create thread
- `@thread_join` - Wait for thread
- `@thread_id` - Get thread ID

**Status:** ✅ 1/1 PASS (100%)

### [10-synchronization/](10-synchronization/) - Synchronization
Tests for mutexes, semaphores, and atomic operations.
- `@mutex_create`, `@mutex_lock`, `@mutex_unlock` - Mutex ops
- `@semaphore_create`, `@semaphore_wait`, `@semaphore_post` - Semaphore ops
- `@atomic_inc`, `@atomic_dec`, `@atomic_add` - Atomic ops

**Status:** ✅ 3/3 PASS (100%)

### [11-channels/](11-channels/) - Channels/IPC
Tests for inter-thread communication via channels.
- `@channel_create` - Create channel
- `@channel_send` - Send on channel
- `@channel_recv` - Receive from channel
- `@channel_close` - Close channel

**Status:** ❌ 0/1 FAIL (0% - COMPILER SEGFAULT)

### [12-threadpools/](12-threadpools/) - Thread Pools
Tests for work queue and thread pool management.
- `@threadpool_create` - Create pool
- `@threadpool_enqueue` - Add work
- `@threadpool_wait` - Wait for completion
- `@threadpool_destroy` - Destroy pool

**Status:** ✅ 1/1 PASS (100%)

### [13-meta/](13-meta/) - Compiler Information
Tests for compiler and platform information.
- `@compiler_version` - Get version
- `@platform` - Get platform info
- `@assert` - Assertion checks

**Status:** ✅ 1/1 PASS (100%)

---

## Test Results Summary

| Category     | Pass | Fail | Rate  |
|--------------|------|------|-------|
| System       | 5    | 0    | 100%  |
| Memory       | 3    | 0    | 100%  |
| Types        | 2    | 0    | 100%  |
| Strings      | 2    | 0    | 100%  |
| FileIO       | 2    | 0    | 100%  |
| Network      | 2    | 0    | 100%  |
| Security     | 1    | 1    | 50%   |
| Hardware     | 1    | 0    | 100%  |
| Threading    | 1    | 0    | 100%  |
| Sync         | 3    | 0    | 100%  |
| Channels     | 0    | 1    | 0%    |
| PoolThreads  | 1    | 0    | 100%  |
| Meta         | 1    | 0    | 100%  |
| **TOTAL**    | **24** | **2** | **92%** |

---

## Known Issues

### 1. Channel Operations - CRITICAL BUG
**Issue:** Segmentation fault during compilation when using @channel_create
**Affected Functions:** @channel_create, @channel_send, @channel_recv, @channel_close
**Severity:** CRITICAL
**Location:** buildintest/11-channels/01_channels.ras
**Solution:** Requires debugging in RasCode compiler's codegen or AST handling for channel nodes

### 2. Hash Functions - NOT IMPLEMENTED  
**Issue:** @md5, @sha1, @sha256 functions are not implemented in builtins
**Affected Functions:** @md5, @sha1, @sha256
**Severity:** MEDIUM (Non-critical - alternative functions may exist)
**Location:** buildintest/07-security/02_hashing.ras
**Solution:** Implement hash function wrappers or use alternative @hash[] function

---

## File Structure

```
buildintest/
├── README_TESTS.md          (this file)
├── 01-system/               (5 tests)
│   ├── 01_exit.ras
│   ├── 02_halt.ras
│   ├── 03_sleep.ras
│   ├── 04_clock.ras
│   └── 05_panic.ras
├── 02-memory/               (3 tests)
├── 03-types/                (2 tests)
├── 04-strings/              (2 tests)
├── 05-fileio/               (2 tests)
├── 06-network/              (2 tests)
├── 07-security/             (2 tests)
├── 08-hardware/             (1 test)
├── 09-threading/            (1 test)
├── 10-synchronization/      (3 tests)
├── 11-channels/             (1 test)
├── 12-threadpools/          (1 test)
└── 13-meta/                 (1 test)
```

---

## Test Syntax Notes

All tests use original RasCode syntax:

```ras
// Basic structure
fnc main[]::int {
    show["Starting test...\n"];
    
    // Test code here
    int result = @builtin_function[args];
    
    // Check result
    if[result > 0] {
        show["✓ Test passed\n"];
    }
    
    get[0];  // Exit with code 0
}
```

Key syntax rules:
- Functions declared with `fnc name[]::return_type`
- Output with `show[string]` (NOT print())
- If conditions use `if[condition]` (NOT if condition)
- Return/exit with `get[exit_code]` (NOT return)
- All function calls use square brackets `function[args]`

---

## Running Specific Tests

```bash
# Compile and test a single file
./rascom buildintest/01-system/01_exit.ras -o test_bin

# Run specific category tests
for f in buildintest/02-memory/*.ras; do
    echo "Testing $f"
    ./rascom "$f" -o /tmp/test || echo "FAILED"
done

# Quick test all
./run_buildin_tests.sh
```

---

## Next Steps

1. **Fix Channel Operations** - Debug segfault in @channel_create
2. **Implement Hash Functions** - Add @md5, @sha1, @sha256
3. **Expand Test Coverage** - Add error conditions, edge cases
4. **Performance Benchmarks** - Measure concurrent operation throughput
5. **Documentation** - Add usage examples for each builtin

