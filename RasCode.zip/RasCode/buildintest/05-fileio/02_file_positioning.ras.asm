global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x3d, 0x3d, 0x3d, 0x20, 0x46, 0x69, 0x6c, 0x65, 0x20, 0x50, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x69, 0x6e, 0x67, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L3:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L5
    cmp byte [rsi], 0
    je .L4
    inc rdx
    inc rsi
    jmp .L3
.L5:
    mov rdx, 0          ; truncate to 0 on overflow
.L4:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @fopen
    lea rax, [rel .STR6]
section .data
.STR6: db 0x2f, 0x74, 0x6d, 0x70, 0x2f, 0x72, 0x61, 0x73, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x70, 0x6f, 0x73, 0x5f, 0x74, 0x65, 0x73, 0x74, 0x2e, 0x74, 0x78, 0x74, 0x00
section .text
    mov rdi, rax        ; path
    mov rax, 1
    mov rsi, rax        ; flags
    call sc_fopen
    push rax            ; var fd
    mov rax, [rbp - 8]  ; load fd
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L7
    ; Builtin function @fwrite
    mov rax, [rbp - 8]  ; load fd
    mov rdi, rax        ; fd
    lea rax, [rel .STR9]
section .data
.STR9: db 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x00
section .text
    mov rsi, rax        ; buffer
    mov rdx, rax        ; length
    call sc_fwrite
    ; Builtin function @fclose
    mov rax, [rbp - 8]  ; load fd
    mov rdi, rax        ; fd
    call sc_fclose
    ; Builtin function @fopen
    lea rax, [rel .STR10]
section .data
.STR10: db 0x2f, 0x74, 0x6d, 0x70, 0x2f, 0x72, 0x61, 0x73, 0x63, 0x6f, 0x64, 0x65, 0x5f, 0x70, 0x6f, 0x73, 0x5f, 0x74, 0x65, 0x73, 0x74, 0x2e, 0x74, 0x78, 0x74, 0x00
section .text
    mov rdi, rax        ; path
    mov rax, 0
    mov rsi, rax        ; flags
    call sc_fopen
    mov [rbp - 8], rax  ; assign fd
    lea rax, [rel .STR11]
section .data
.STR11: db 0x0a, 0x31, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x74, 0x65, 0x6c, 0x6c, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L12:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L14
    cmp byte [rsi], 0
    je .L13
    inc rdx
    inc rsi
    jmp .L12
.L14:
    mov rdx, 0          ; truncate to 0 on overflow
.L13:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var pos1
    lea rax, [rel .STR15]
section .data
.STR15: db 0x49, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x20, 0x70, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L16:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L18
    cmp byte [rsi], 0
    je .L17
    inc rdx
    inc rsi
    jmp .L16
.L18:
    mov rdx, 0          ; truncate to 0 on overflow
.L17:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load pos1
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR19]
section .data
.STR19: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L20:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L22
    cmp byte [rsi], 0
    je .L21
    inc rdx
    inc rsi
    jmp .L20
.L22:
    mov rdx, 0          ; truncate to 0 on overflow
.L21:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR23]
section .data
.STR23: db 0x0a, 0x32, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x73, 0x65, 0x65, 0x6b, 0x5b, 0x35, 0x2c, 0x20, 0x30, 0x5d, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L24:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L26
    cmp byte [rsi], 0
    je .L25
    inc rdx
    inc rsi
    jmp .L24
.L26:
    mov rdx, 0          ; truncate to 0 on overflow
.L25:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @fseek
    mov rax, [rbp - 8]  ; load fd
    mov rdi, rax        ; fd
    mov rax, 5
    mov rsi, rax        ; offset
    call sc_fseek
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var pos2
    lea rax, [rel .STR27]
section .data
.STR27: db 0x50, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x61, 0x66, 0x74, 0x65, 0x72, 0x20, 0x73, 0x65, 0x65, 0x6b, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L28:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L30
    cmp byte [rsi], 0
    je .L29
    inc rdx
    inc rsi
    jmp .L28
.L30:
    mov rdx, 0          ; truncate to 0 on overflow
.L29:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load pos2
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR31]
section .data
.STR31: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR35]
section .data
.STR35: db 0x0a, 0x33, 0x2e, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x66, 0x65, 0x6f, 0x66, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var at_end
    lea rax, [rel .STR39]
section .data
.STR39: db 0x41, 0x74, 0x20, 0x65, 0x6e, 0x64, 0x20, 0x6f, 0x66, 0x20, 0x66, 0x69, 0x6c, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L40:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L42
    cmp byte [rsi], 0
    je .L41
    inc rdx
    inc rsi
    jmp .L40
.L42:
    mov rdx, 0          ; truncate to 0 on overflow
.L41:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load at_end
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR43]
section .data
.STR43: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR47]
section .data
.STR47: db 0xe2, 0x9c, 0x93, 0x20, 0x46, 0x69, 0x6c, 0x65, 0x20, 0x70, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x74, 0x65, 0x73, 0x74, 0x65, 0x64, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @fclose
    mov rax, [rbp - 8]  ; load fd
    mov rdi, rax        ; fd
    call sc_fclose
    add rsp, 24         ; pop 3 block-local variables
    jmp .L8
.L7:
.L8:
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
