# 02: Lexer Analysis

**Source**: `lexer.c`, `lexer.h`  
**Lines of Code**: ~500  
**Responsibility**: Tokenization (source code → token stream)

---

## Lexer Data Structures

```c
typedef struct {
    const char *source;      // Pointer to entire source code
    int pos;                 // Current position in source
    int line;                // Current line number (1-indexed)
    int col;                 // Current column (1-indexed)
    int length;              // Total source length
} Lexer;

typedef struct {
    TokenType type;          // Classification (keywords, operators, etc.)
    char *value;             // String value of token
    int line;                // Line where token appears
    int col;                 // Column where token appears
} Token;

enum TokenType {
    // Keywords (30+)
    TOK_FNC, TOK_GET, TOK_LOOP, TOK_IF, TOK_OR, TOK_WHILE,
    // ... more keywords
    
    // Data types (8)
    TOK_INT, TOK_DECI, TOK_CHAR, TOK_STR, TOK_BOOL,
    TOK_BYTE, TOK_UBYTE, TOK_NONE,
    
    // Literals
    TOK_NUMBER, TOK_STRING, TOK_IDENTIFIER,
    
    // Operators
    TOK_PLUS, TOK_MINUS, TOK_STAR, TOK_SLASH, TOK_PERCENT,
    TOK_EQ, TOK_NE, TOK_LT, TOK_GT, TOK_LE, TOK_GE,
    TOK_ASSIGN, TOK_AND, TOK_OR_OP, TOK_NOT,
    
    // Delimiters
    TOK_LPAREN, TOK_RPAREN,
    TOK_LBRACE, TOK_RBRACE,
    TOK_LBRACKET, TOK_RBRACKET,
    TOK_SEMICOLON, TOK_COMMA, TOK_DOT,
    TOK_COLON, TOK_DOUBLE_COLON, TOK_ARROW, TOK_AT,
    
    // Special
    TOK_EOF, TOK_ERROR
};
```

---

## Lexer Phases

### Phase 1: Initialization

```c
Lexer *lexer_new(const char *source) {
    Lexer *lexer = xmalloc(sizeof(Lexer));
    lexer->source = source;
    lexer->pos = 0;
    lexer->line = 1;
    lexer->col = 1;
    lexer->length = strlen(source);
    return lexer;
}
```

**Time Complexity**: O(n) where n = source length  
**Space Complexity**: O(1) (does not copy source)

---

### Phase 2: Tokenization Loop

```c
Token *token = lexer_next_token(lexer);
while (token->type != TOK_EOF) {
    // Process token
    token = lexer_next_token(lexer);
}
```

**Core Algorithm**:

```
while (not EOF):
    skip_whitespace()
    if (current == '/') and next == '/' or '>':
        skip_comment()
    else if (isdigit(current)):
        token = read_number()
    else if (isalpha(current)) or current == '_':
        token = read_identifier()
        if is_keyword(identifier):
            token.type = keyword_type
    else if (current == '"'):
        token = read_string()
    else if (current == '\''):
        token = read_char()
    else:
        token = read_operator()
```

---

## Keywords (30+ Total)

### Control Flow Keywords
| Keyword | Token Type | Purpose |
|---------|-----------|---------|
| `fnc` | TOK_FNC | Function definition |
| `get` | TOK_GET | Return statement |
| `if` | TOK_IF | Conditional |
| `while` | TOK_WHILE | Loop condition |
| `loop` | TOK_LOOP | For-loop equivalent |
| `cycle` | TOK_CYCLE | Switch statement |
| `when` | TOK_WHEN | Case label / exception handler |
| `check` | TOK_CHECK | Try block |

### Type Keywords
| Keyword | Token Type | Meaning |
|---------|-----------|---------|
| `int` | TOK_INT | 32-bit signed integer |
| `deci` | TOK_DECI | Double-precision float |
| `char` | TOK_CHAR | Single character |
| `str` | TOK_STR | String (variable-length) |
| `bool` | TOK_BOOL | Boolean (true/false) |
| `byte` | TOK_BYTE | Unsigned byte |
| `ubyte` | TOK_UBYTE | Unsigned byte |
| `none` | TOK_NONE | Void/null type |

### Data Structure Keywords
| Keyword | Token Type | Purpose |
|---------|-----------|---------|
| `arr` | TOK_ARR | Array type |
| `map` | TOK_MAP | Hashmap type |
| `group` | TOK_GROUP | Struct/record type |

### Module Keywords
| Keyword | Token Type | Purpose |
|---------|-----------|---------|
| `pkg` | TOK_PKG | Package/import directive |
| `use` | TOK_USE | Use statement |
| `const` | TOK_CONST | Global constant |

### Boolean Keywords
| Keyword | Token Type | Value |
|---------|-----------|-------|
| `true` | TOK_TRUE | Boolean true |
| `false` | TOK_FALSE | Boolean false |

### Logical Keywords
| Keyword | Token Type | Operation |
|---------|-----------|-----------|
| `and` | TOK_AND_KW | Logical AND |
| `xor` | TOK_XOR | Logical XOR |
| `not` | TOK_NOT | Logical NOT |
| `or` | TOK_OR | Logical OR |

### I/O Keywords
| Keyword | Token Type | Purpose |
|---------|-----------|---------|
| `show` | TOK_SHOW | Output/print |
| `read` | TOK_READ | Input/read |
| `fixed` | TOK_FIXED | Fixed-point number |

### Special Keywords
| Keyword | Token Type | Purpose |
|---------|-----------|---------|
| `set` | TOK_SET | Assignment/set |
| `check` | TOK_CHECK | Error check |

---

## Number Parsing

### Supported Number Formats

```c
// Decimal
123, 0, -456

// Hexadecimal (0x prefix)
0xFF, 0x0A, 0xDEADBEEF

// Octal (0 prefix)  
0755, 0644, 0777

// Binary (0b prefix)
0b1010, 0b11111111, 0b1100_0011

// Floating point (decimals)
3.14, 0.5, 2.71828, 1.23e-4
```

**Algorithm**:

```c
Token *lexer_read_number(Lexer *lexer) {
    if (current == '0') {
        if (next == 'x') return read_hex();
        if (next == 'b') return read_binary();
        if (isdigit(next)) return read_octal();
    }
    
    // Decimal or floating point
    while (isdigit(current) or current == '.') {
        advance();
    }
    
    // Scientific notation?
    if (current == 'e' or current == 'E') {
        advance();
        if (current == '+' or current == '-') advance();
        while (isdigit(current)) advance();
    }
    
    return create_number_token();
}
```

---

## String Parsing

### String Features

```ras
"Simple string"
"Multi\\line\nwith\nescape\tsequences"
"Quote: \"nested\""
"Unicode: Ã©Â§â™ (UTF-8 support)"
"Interpolation: $var or ${expr}"
```

### Escape Sequences Supported

| Escape | Meaning | Value |
|--------|---------|-------|
| `\n` | Newline | ASCII 10 |
| `\t` | Tab | ASCII 9 |
| `\r` | Carriage return | ASCII 13 |
| `\\` | Backslash | `\` |
| `\"` | Double quote | `"` |
| `\'` | Single quote | `'` |
| `\x##` | Hex byte | 0x00-0xFF |
| `\###` | Octal byte | 0-377 |

**Error Detection**:
- Unterminated strings → Error
- Invalid escape sequences → Warning or error
- Invalid hex/octal codes → Error

---

## Operator Recognition

### Single-Character Operators

```c
'+'  → TOK_PLUS       '-'  → TOK_MINUS
'*'  → TOK_STAR       '/'  → TOK_SLASH
'%'  → TOK_PERCENT    '('  → TOK_LPAREN
')'  → TOK_RPAREN     '['  → TOK_LBRACKET
']'  → TOK_RBRACKET   '{'  → TOK_LBRACE
'}'  → TOK_RBRACE     ','  → TOK_COMMA
';'  → TOK_SEMICOLON  '.'  → TOK_DOT
'@'  → TOK_AT         '$'  → TOK_DOLLAR
'!'  → TOK_NOT        '&'  → TOK_AMPERSAND
'|'  → TOK_PIPE       '^'  → TOK_CARET
'~'  → TOK_TILDE      '<'  → TOK_LT
'>'  → TOK_GT         '='  → TOK_ASSIGN
```

### Multi-Character Operators

```c
// Two-character
'=='  → TOK_EQ          '!='  → TOK_NE
'<='  → TOK_LE          '>='  → TOK_GE
'&&'  → TOK_AND         '||'  → TOK_OR_OP
'>>'  → TOK_SHR         '<<'  → TOK_SHL
'->'  → TOK_ARROW       '+='  → TOK_PLUS_ASSIGN
'-='  → TOK_MINUS_ASSIGN

// Three-character
'::' → TOK_DOUBLE_COLON
'//' / '>/>' for comments
```

---

## Comment Handling

### Line Comments

```ras
// This is a line comment
show["Hello"];  // Another comment
```

**Lexer Action**: Skip to end of line, discard

### Multiline Comments

```ras
//> This is a
    multiline comment
    spanning several lines
<//
```

**Lexer Action**: Skip until closing `<//" found

**Error Handling**: Unterminated multi-line comment → Error

---

## Identifier Parsing

```c
// Valid identifiers
variable, _private, snake_case, camelCase, CONSTANT,
func123, _123private, __special__

// Reserved: All keywords (case-sensitive)
```

**Algorithm**:

```c
if (isalpha(current) or current == '_') {
    start = pos;
    while (isalnum(current) or current == '_') {
        advance();
    }
    
    value = extract(start, pos);
    if (is_keyword(value, &type)) {
        return keyword_token(type);
    } else {
        return identifier_token(value);
    }
}
```

---

## Character Literal Parsing

```ras
'A'        // Uppercase letter
'5'        // Digit character  
' '        // Space
'\n'       // Newline
'\t'       // Tab
'\\'       // Backslash
'\''       // Single quote
```

**Storage**: Characters converted to their ASCII integer values internally

---

## Lookahead Strategy

**Single-character lookahead** in most cases:

```c
char lexer_current(Lexer *lexer) {
    if (lexer->pos >= lexer->length) return '\0';
    return lexer->source[lexer->pos];
}

char lexer_peek(Lexer *lexer, int offset) {
    int pos = lexer->pos + offset;
    if (pos >= lexer->length) return '\0';
    return lexer->source[pos];
}
```

**Multi-character lookahead** for multi-character operators:

```c
if (current == '=' && peek(1) == '=') {
    // This is ==
}
```

---

## Error Handling

### Lexer Errors Detected

1. **Unterminated strings**
   ```
   "Hello world
   ```
   → Error with line number

2. **Invalid escape sequences**
   ```
   "Bad \x"
   ```
   → Error with context

3. **Invalid character**
   ```
   ñ  // If not UTF-8 encoded
   ```
   → Error token

### Error Reporting

```c
void error_at(int line, int col, const char *msg) {
    fprintf(stderr, "ERROR at line %d, column %d: %s\n", line, col, msg);
}
```

---

## Performance Characteristics

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| Construction | O(1) | Constant time |
| Next token | O(k) | k = token length |
| Full tokenization | O(n) | n = source length |
| Storage | O(n) | n = source length (source kept) |

**Typical Performance**:
- 1000 lines of source → ~1ms tokenization
- Token stream size: ~10-20% of source size

---

## Lexer Design Decisions

### 1. Source Kept in Memory
**Decision**: Entire source kept as single string  
**Rationale**: Simplifies error reporting with line/column tracking  
**Cost**: O(n) memory usage

### 2. Dynamic Token Value Allocation
**Decision**: Each token's value is strdup'd  
**Rationale**: Allows token stream separation from source  
**Cost**: Memory overhead for token storage

### 3. Line/Column Tracking
**Decision**: Tracked during tokenization  
**Rationale**: Enables precise error reporting  
**Cost**: Additional bookkeeping overhead

### 4. Single-Character Lookahead (Mostly)
**Decision**: Use `lexer_peek()` for operator recognition  
**Rationale**: Sufficient for language grammar  
**Cost**: Minimal

---

## Extensibility

### Adding New Keywords

1. Add to token type enum in `lexer.h`
2. Add entry to `is_keyword()` function in `lexer.c`
3. Parser handles new token type

### Adding New Operators

1. Add token type to enum
2. Modify operator recognition in `lexer_next_token()`
3. Update precedence in parser

### Adding New Escape Sequences

1. Add case to `lexer_read_string()` escape handler
2. Validate sequence
3. Return appropriate character

---

## Limitations

1. **No preprocessor** - No macros or conditional compilation
2. **Limited Unicode** - UTF-8 strings, but ASCII keywords
3. **No lookahead tokens** - Could be added for complex operators
4. **Simple number parsing** - No complex literal formats
5. **No token caching** - All tokens re-scanned each compilation

---

**Key Insight**: The lexer is the "front door" of the compiler. Clean tokenization here prevents cascading errors in parser and later stages.

**Next**: See [03_PARSER_ANALYSIS.md](03_PARSER_ANALYSIS.md) for how tokens become syntax trees.
