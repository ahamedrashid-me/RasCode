# 07: Code Generation Analysis

**Source**: `codegen.c`, `codegen.h`  
**Lines of Code**: ~2000  
**Target**: x86-64 assembly (NASM syntax)  
**Strategy**: Direct AST emission

---

## Code Generation Pipeline

```
AST (from parser)
    ↓
Enter CodeGen phase
    ↓
Initialize code generator
    ↓
Traverse AST recursively
    ↓
Emit x86-64 assembly instructions
    ↓
Manage symbol table & registers
    ↓
Output .asm file
    ↓
NASM assembler processes .asm
```

---

## CodeGen Data Structures

```c
typedef struct {
    FILE *output;               // Output assembly file
    SymbolTable *symbols;       // Current scope symbols
    int label_counter;          // For generating unique labels
    int string_counter;         // For string constants
    GroupType *groups;          // Defined group types
    
    // x86-64 state
    int stack_offset;           // Current stack position
    const char *current_func;   // Being compiled function
} CodeGen;

typedef struct {
    char *name;                 // Variable name
    int offset;                 // Stack offset (from RBP)
    int size;                   // Size in bytes
    char *type;                 // Type string
    bool is_array;              // Is array?
    bool is_array_param;        // Array parameter?
    int array_size;             // Array element count
    int element_size;           // Size of each element
    bool is_group;              // Is struct?
} Symbol;

typedef struct {
    Symbol **symbols;
    int count;
    struct SymbolTable *parent; // Parent scope
} SymbolTable;
```

---

## x86-64 Architecture Target

### Calling Convention (System V AMD64 ABI)

**Registers Used**:
- `RAX` - Return value
- `RBX` - Callee-saved
- `RCX` - First integer argument
- `RDX` - Second integer argument  
- `RSI` - Third integer argument
- `RDI` - Fourth integer argument
- `R8-R11` - Additional arguments & temp
- `R12-R15` - Callee-saved

**Stack Frame**:
```
                    ↑ (growing upward)
    [Arg 2]
    [Arg 1]         ← RSP before call
    [Return addr]   ← RSP after call
    [RBP save]      ← RBP (frame pointer)
    [Local vars]    ← decreasing addresses
                    ↓ (growing downward)
```

---

## Assembly Generation Strategy

### 1. Program & Global Setup

```nasm
; Global section header
section .rodata
    ; String constants go here
    str_0: db "Hello, World!", 0

section .data
    ; Global variables
    MAX_SIZE: dq 100

section .text
    global _start
```

### 2. Function Prologue

Each function emits:

```nasm
function_name:
    push rbp              ; Save old frame pointer
    mov rbp, rsp          ; Set up new frame pointer
    sub rsp, [stack_size] ; Allocate local variables
```

### 3. Function Epilogue

```nasm
    mov rsp, rbp          ; Restore stack pointer
    pop rbp               ; Restore frame pointer
    ret                   ; Return to caller
```

---

## Symbol Table Management

### Scope Management

```c
// Enter new scope (function)
symbol_table_push();

// Add local variable
symbol_add(symtable, "x", 4, "int", false);

// Lookup variable
Symbol *sym = symbol_lookup(symtable, "x");

// Exit scope (function)
symbol_table_pop();
```

### Stack Allocation

```c
// Each local variable gets stack offset
symtable->current_offset -= size;  // Growing down
symbol->offset = symtable->current_offset;

// When emitting code:
mov eax, [rbp + offset]    // Load from stack
```

---

## Expression Code Generation

### Literal Values

```ras
// Source
int x = 42;

// AST
VAR_DECL(type="int", name="x", value=LITERAL("int", "42"))

// Assembly
mov dword [rbp - 4], 42     ; Store 42 at local offset -4
```

### Binary Operations

```ras
// Source
int result = a + b;

// AST
ASSIGN(name="result", value=BINARY_OP("+", IDENT("a"), IDENT("b")))

// Assembly
mov eax, [rbp - 8]          ; Load 'a' into RAX
mov ecx, [rbp - 12]         ; Load 'b' into RCX
add eax, ecx                ; EAX = EAX + ECX
mov [rbp - 16], eax         ; Store result
```

### Function Calls

```ras
// Source
int sum = add[x, y];

// Assembly
mov eax, [rbp - 8]          ; arg1 in EAX
mov ecx, [rbp - 12]         ; arg2 in ECX
call add                    ; Call function
mov [rbp - 16], eax         ; Save return value
```

---

## Control Flow Code Generation

### If Statement

```ras
// Source
if[x > 0] {
    show["positive"];
} else {
    show["non-positive"];
}

// Assembly
mov eax, [rbp - 4]          ; Load 'x'
cmp eax, 0                  ; Compare to 0
jle .else_label             ; Jump if x <= 0

; Then branch
call show_positive
jmp .end_if

.else_label:
; Else branch
call show_non_positive

.end_if:
```

### While Loop

```ras
// Source
while[x < 10] {
    show[x];
    x = x + 1;
}

// Assembly
.while_start:
mov eax, [rbp - 4]          ; Load 'x'
cmp eax, 10                 ; x < 10?
jge .while_end              ; Jump if x >= 10

; Loop body
call show_value
mov eax, [rbp - 4]          ; Load 'x'
add eax, 1                  ; x + 1
mov [rbp - 4], eax          ; Store back

jmp .while_start

.while_end:
```

### For Loop

```ras
// Source
loop[i = 0; i < 5; i = i + 1] {
    show[i];
}

// Assembly
; Initialization
mov dword [rbp - 4], 0      ; i = 0

.for_start:
; Condition
mov eax, [rbp - 4]          ; Load 'i'
cmp eax, 5                  ; i < 5?
jge .for_end                ; Jump if i >= 5

; Body
call show_value
; Increment
mov eax, [rbp - 4]
add eax, 1
mov [rbp - 4], eax

jmp .for_start

.for_end:
```

---

## Array Code Generation

### Array Declaration

```ras
// Source
arr{int, 10} nums;

// Array layout on stack (40 bytes for 10 x 4-byte ints)
[bpms - 4]:  nums[0]
[rbp - 8]:   nums[1]
...
[rbp - 40]:  nums[9]

// Symbol entry
name: "nums", offset: -40, size: 40, is_array: true, array_size: 10
```

### Array Access

```ras
// Source
int value = arr{2};

// Assembly
; Calculate address: base_addr + (index * element_size)
mov eax, 2                  ; Load index
imul eax, 4                 ; Multiply by element size (4)
mov ecx, eax
sub rcx, 40                 ; Calculate offset from RBP
mov eax, [rbp + rcx]        ; Load arr[2]
mov [rbp - 44], eax         ; Store in result variable
```

---

## String Constant Handling

### String Storage

```ras
// Source code
show["Hello"];

// Codegen Action:
// 1. Add string to .rodata section
section .rodata
    str_1: db "Hello", 0

// 2. Generate code to load and pass string
lea rsi, [rel str_1]        ; Load address of string
call show                   ; Pass in RSI
```

### String Interpolation

```ras
// Source
show["Value: $x"];

// Codegen (conceptually):
// 1. Load x value
// 2. Convert to string
// 3. Concatenate "Value: " + str(x)
// 4. Output result
```

---

## Builtin Function Calls

### Memory Operations

```ras
// Source
@alloc[1024];

// Assembly
mov eax, 1024               ; Size in bytes
call builtin_alloc          ; Call runtime function
mov [rbp - 4], rax          ; Save pointer
```

### String Operations

```ras
// Source
@len[str1];

// Assembly
lea rsi, [rbp - 64]         ; Load string address
call builtin_len            ; Call runtime function
mov [rbp - 4], eax          ; Save result
```

---

## Group (Struct) Code Generation

### Group Definition

```ras
// Source
group Point {
    int x;
    int y;
}

// Codegen:
// Point layout in memory:
// [offset 0]: x (4 bytes)
// [offset 4]: y (4 bytes)
// Total size: 8 bytes

// Symbol entry for group:
name: "Point", total_size: 8
field "x": offset 0, size 4
field "y": offset 4, size 4
```

### Group Member Access

```ras
// Source
int px = point.x;

// Assembly
mov rax, [rbp - offset_of_point]    ; Load struct address
mov eax, [rax + 0]                  ; Load member at offset 0
mov [rbp - local_offset], eax       ; Store result
```

---

## Optimization Opportunities in Codegen

### 1. Register Allocation
Current: Simple stack allocation  
Better: Track live ranges, use more registers

### 2. Instruction Selection
Current: Naive 1-to-1 AST mapping  
Better: Combine operations (`mov eax, [rbp-4]; add eax, 1` → single instruction)

### 3. Peephole Optimization
Current: None  
Better: Pattern matching on generated code

### 4. Dead Code Elimination
Current: Might emit unused code  
Better: Analyze reachability

---

## Error Handling in Codegen

### Type Mismatches

```c
// During binary operation codegen:
if (!types_compatible(left_type, right_type)) {
    fprintf(stderr, "Type mismatch in operation\n");
    return false;
}
```

### Undefined Variables

```c
// During identifier codegen:
symbol = symbol_lookup(table, name);
if (!symbol) {
    fprintf(stderr, "Undefined variable: %s\n", name);
    return false;
}
```

### Invalid array access

```c
// Index must be integer
if (strcmp(index_type, "int") != 0) {
    fprintf(stderr, "Array index must be int\n");
    return false;
}
```

---

## Performance Characteristics

| Operation | Generated Instructions | Speed |
|-----------|------------------------|-------|
| Variable load | 1 | O(1) |
| Binary op | 2-3 | O(1) |
| Function call | 5-10 | O(n) |
| Array access | 3-5 | O(1) |
| Branch | 2 | O(1) |

---

## Debugging Information

### Optional Debug Symbols

```nasm
section .debug_info
    ; Line number information
    ; Variable location info
```

---

## Design Decisions

### 1. Direct AST Emission (No IR)
**Decision**: Emit assembly directly from AST  
**Pros**: Simpler, no intermediate representation  
**Cons**: Harder to optimize

### 2. Stack-Based Locals (No Register Allocation)
**Decision**: All locals on stack  
**Pros**: Simple, no register allocation  
**Cons**: Extra memory traffic

### 3. x86-64 Target (Not portable)
**Decision**: Hard-coded x86-64 architecture  
**Pros**: Can use architecture-specific instructions  
**Cons**: Not portable to ARM, MIPS, etc.

---

## Code Example: Full Function Compilation

**Source**:
```ras
fnc add[x, y]::int {
    int sum = x + y;
    get[sum];
}
```

**Generated Assembly**:
```nasm
add:
    push rbp
    mov rbp, rsp
    sub rsp, 8              ; 1 local variable (4 bytes) + padding
    
    ; x is in EAX, y is in ECX (following ABI)
    ; int sum = x + y;
    add eax, ecx
    mov dword [rbp - 4], eax  ; Store sum
    
    ; get[sum];
    mov eax, [rbp - 4]      ; Load sum
    
    ; Return
    mov rsp, rbp
    pop rbp
    ret
```

---

## Limitations

1. **No register allocation** → Extra memory access
2. **No instruction scheduling** → Possible stalls
3. **No loop unrolling** → Suboptimal performance
4. **No vectorization** → No SIMD instructions
5. **No cross-function optimization** → Limited inlining

---

**Next**: See [08_RUNTIME_GENERATION.md](08_RUNTIME_GENERATION.md) for binary generation.
