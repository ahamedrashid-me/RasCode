# 04: Abstract Syntax Tree (AST) Analysis

**Source**: `ast.c`, `ast.h`  
**Node Types**: 20+  
**Design Pattern**: Visitor + recursive tree structure

---

## AST Overview

The Abstract Syntax Tree is the compiler's **intermediate representation** of the program structure. It bridges the parser (tokens) and code generator (machine code).

```
Tokens (e.g., "fnc", "main", "[", "]", etc.)
          ↓
    Parser (Recursive Descent)
          ↓
    AST (Tree of ASTNode structures)
          ↓
    Code Generator (emit assembly)
```

---

## Core AST Data Structures

```c
typedef enum {
    AST_PROGRAM,
    AST_CONST_DECL,
    AST_FUNCTION,
    AST_BLOCK,
    AST_RETURN,
    AST_IF,
    AST_WHILE,
    AST_LOOP,
    AST_SHOW,
    AST_READ,
    AST_CYCLE,
    AST_WHEN,
    AST_CHECK,
    AST_VAR_DECL,
    AST_ASSIGN,
    AST_ARRAY_ASSIGN,
    AST_BINARY_OP,
    AST_UNARY_OP,
    AST_CALL,
    AST_BUILTIN_CALL,
    AST_LITERAL,
    AST_IDENTIFIER,
    AST_ARRAY_ACCESS,
    AST_GROUP_DECL,
    AST_GROUP_MEMBER_ACCESS,
    AST_MAP_OPERATION,
    // ... more types
} ASTNodeType;

typedef struct ASTNode {
    ASTNodeType type;              // What kind of node?
    
    // Type-specific data (union-like):
    union {
        struct {
            ASTList *imports;      // Package imports
            ASTList *constants;    // Global constants
            ASTList *groups;       // Group (struct) definitions
            ASTList *functions;    // Function definitions
        } program;
        
        struct {
            char *name;
            ASTNode *value;
        } const_decl;
        
        struct {
            char *name;
            char *return_type;
            ASTList *params;
            ASTNode *body;
        } function;
        
        struct {
            ASTList *statements;   // Statements in block
        } block;
        
        struct {
            ASTNode *value;
        } ret;
        
        // ... more member structs for other node types
    };
} ASTNode;

typedef struct {
    ASTNode **nodes;
    int count;
    int capacity;
} ASTList;
```

---

## Node Types (20+)

### 1. Program Node (AST_PROGRAM)

**Represents**: Entire program structure  
**Children**: Imports, constants, groups, functions  
**Properties**:

```c
node->program.imports;      // ASTList of package imports
node->program.constants;    // ASTList of global constants
node->program.groups;       // ASTList of group definitions
node->program.functions;    // ASTList of function definitions
```

**Example AST**:
```
PROGRAM
├── CONST_DECL (MAX_SIZE = 100)
├── GROUP_DECL (Point)
└── FUNCTION (main)
    └── BLOCK
        ├── SHOW
        └── RETURN
```

---

### 2. Function Node (AST_FUNCTION)

**Represents**: Function definition  
**Properties**:

```c
node->function.name;           // Function name
node->function.return_type;    // "int", "none", etc.
node->function.params;         // ASTList of parameter names
node->function.body;           // ASTNode (BLOCK)
```

**Example**:
```ras
fnc add[a, b]::int {           // AST_FUNCTION
    get[a + b];
}
```

**AST Structure**:
```
FUNCTION
├── name: "add"
├── return_type: "int"
├── params: ["a", "b"]
└── body: BLOCK
    └── RETURN
        └── BINARY_OP (+)
            ├── IDENTIFIER (a)
            └── IDENTIFIER (b)
```

---

### 3. Variable Declaration (AST_VAR_DECL)

**Represents**: Local or parameter variable declaration  
**Properties**:

```c
node->var_decl.type;           // "int", "str", "arr{int,10}"
node->var_decl.name;           // Variable name
node->var_decl.value;          // Initial value (optional)
node->var_decl.is_array;       // Is this an array?
node->var_decl.array_size;     // Array size expression
```

**Examples**:
```ras
int x;                         // var_decl (no init)
int y = 10;                   // var_decl (with init)
arr{int, 5} nums;             // var_decl (array)
```

---

### 4. Expression Nodes

#### Binary Operation (AST_BINARY_OP)

```c
node->binary_op.left;          // Left operand (ASTNode)
node->binary_op.op;            // Operator ("+", "-", "*", etc.)
node->binary_op.right;         // Right operand (ASTNode)
```

**Examples**:
```
a + b      →  BINARY_OP("+", IDENT(a), IDENT(b))
x * y - z  →  BINARY_OP("-", BINARY_OP("*", ...), ...)
```

#### Unary Operation (AST_UNARY_OP)

```c
node->unary_op.op;             // Operator ("-", "!")
node->unary_op.operand;        // Operand (ASTNode)
```

**Examples**:
```
-x         →  UNARY_OP("-", IDENT(x))
!flag      →  UNARY_OP("!", IDENT(flag))
```

#### Literals (AST_LITERAL)

```c
node->literal.type;            // "int", "str", "char", "deci", etc.
node->literal.value;           // String representation
```

**Examples**:
```
42         →  LITERAL("int", "42")
"hello"    →  LITERAL("str", "hello")
3.14       →  LITERAL("deci", "3.14")
```

#### Identifiers (AST_IDENTIFIER)

```c
node->identifier.name;         // Variable/function name
```

**Example**:
```
x          →  IDENTIFIER("x")
```

---

### 5. Statement Nodes

#### If Statement (AST_IF)

```c
node->if_stmt.condition;       // Condition expression
node->if_stmt.then_block;      // Then branch (BLOCK)
node->if_stmt.else_block;      // Else branch (optional BLOCK)
```

**Example**:
```ras
if[x > 0] {
    show["positive"];
} else {
    show["non-positive"];
}
```

**AST**:
```
IF
├── condition: BINARY_OP(">", IDENT(x), LITERAL(0))
├── then_block: BLOCK
│   └── SHOW
└── else_block: BLOCK
    └── SHOW
```

#### While Loop (AST_WHILE)

```c
node->while_stmt.condition;    // Loop condition
node->while_stmt.body;         // Loop body (BLOCK)
```

#### For Loop (AST_LOOP)

```c
node->loop_stmt.init;          // Initialization
node->loop_stmt.condition;     // Condition
node->loop_stmt.increment;     // Increment
node->loop_stmt.body;          // Body (BLOCK)
```

**Example**:
```ras
loop[i = 0; i < 10; i = i + 1] {
    show[i];
}
```

#### Switch Case (AST_CYCLE)

```c
node->cycle.value;             // Expression to switch on
node->cycle.cases;             // ASTList of WHEN nodes
node->cycle.default_case;      // Default case (optional)
```

---

### 6. I/O Nodes

#### Show (AST_SHOW)

```c
node->show.value;              // Expression to output
```

**Example**: `show["Hello"];` → SHOW(LITERAL("Hello"))

#### Read (AST_READ)

```c
node->read.target;             // Variable to read into
node->read.prompt;             // Optional prompt
```

---

### 7. Special Nodes

#### Return Statement (AST_RETURN)

```c
node->ret.value;               // Value to return (ASTNode)
```

#### Function Call (AST_CALL)

```c
node->call.name;               // Function name
node->call.args;               // ASTList of arguments
```

#### Builtin Function Call (AST_BUILTIN_CALL)

```c
node->builtin_call.name;       // Builtin name (without @)
node->builtin_call.args;       // ASTList of arguments
node->builtin_call.cast_type;  // For @type[x]::int
```

#### Array Access (AST_ARRAY_ACCESS)

```c
node->array_access.name;       // Array variable name
node->array_access.index;      // Index expression
```

---

## Memory Management

### Node Creation

```c
ASTNode *node = ast_node_new(AST_FUNCTION);
// Initialize node->function members
// ... set name, return_type, params, body ...
```

### List Operations

```c
ASTList *list = ast_list_new();
ast_list_add(list, node1);
ast_list_add(list, node2);
```

**Dynamic Resizing**:
- Start: capacity = 8
- Growth: capacity *= 2 when count >= capacity

### Cleanup

```c
// Recursive cleanup
void ast_node_free(ASTNode *node) {
    // Recursively free child nodes based on type
    // Free allocated strings (name, etc.)
}
```

---

## AST Traversal Patterns

### Preorder Traversal (most common in codegen)

```c
void traverse_preorder(ASTNode *node) {
    if (!node) return;
    
    // Process current node
    process(node);
    
    // Process children (based on node type)
    switch (node->type) {
        case AST_BINARY_OP:
            traverse_preorder(node->binary_op.left);
            traverse_preorder(node->binary_op.right);
            break;
        // ... other cases ...
    }
}
```

### Recursive Function Processing

```c
void codegen_function(CodeGen *gen, ASTNode *func) {
    // Enter function scope
    symbol_table_push();
    
    // Process function body recursively
    codegen_block(gen, func->function.body);
    
    // Exit function scope
    symbol_table_pop();
}
```

---

## Type Information in AST

### Type Annotations

Each node may carry type information added by semantic analyzer:

```c
// Added during semantic analysis:
node->inferred_type;           // "int", "str", etc.
node->is_constant;             // Compile-time constant?
node->is_lvalue;               // Can be assigned to?
```

---

## Example: Complete AST for Small Program

**Source**:
```ras
const MAX = 10;

fnc main[]::int {
    int x = 5;
    if[x > 0] {
        show["positive"];
    }
    get[0];
}
```

**AST Tree**:
```
PROGRAM
├── CONST_DECL
│   ├── name: "MAX"
│   └── value: LITERAL("int", "10")
└── FUNCTION
    ├── name: "main"
    ├── return_type: "int"
    ├── params: []
    └── body: BLOCK
        ├── VAR_DECL
        │   ├── type: "int"
        │   ├── name: "x"
        │   └── value: LITERAL("int", "5")
        ├── IF
        │   ├── condition: BINARY_OP(">", IDENT("x"), LITERAL("int", "0"))
        │   └── then_block: BLOCK
        │       └── SHOW
        │           └── LITERAL("str", "positive")
        └── RETURN
            └── LITERAL("int", "0")
```

---

## AST Statistics

| Metric | Range | Typical |
|--------|-------|---------|
| Average program depth | 5-10 | 7 |
| Node count per function | 10-100 | 30 |
| Node types per program | 1-20 | 8-12 |
| Memory per node | 64B | 64B |

---

## Design Decisions

### 1. Node Union Structure
**Decision**: Use union for type-specific data  
**Rationale**: Saves memory, one allocation per node  
**Cost**: Type safety requires casting

### 2. Separate List Container
**Decision**: ASTList for managing node collections  
**Rationale**: Flexible, supports dynamic growth  
**Cost**: Extra indirection

### 3. String-based Operators
**Decision**: Operators stored as strings ("+", "-", etc.)  
**Rationale**: Easy comparison, human-readable  
**Cost**: Slower than enum lookup

---

## Verification and Optimization

### AST Validation

The semantic analyzer can validate:
- Type compatibility
- Scope correctness
- Constant expression evaluation
- Reachability analysis

### AST Optimization

Possible optimizations:
- Constant folding: `3 + 4` → `7`
- Dead code elimination
- Unreachable block removal
- Common subexpression elimination

---

**Next**: See [07_CODEGEN_ANALYSIS.md](07_CODEGEN_ANALYSIS.md) for how AST becomes assembly.
