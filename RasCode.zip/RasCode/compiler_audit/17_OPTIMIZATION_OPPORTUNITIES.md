# 17: Optimization Opportunities & Roadmap

**Analysis Date**: April 4, 2026  
**Compiler Version**: RasCode (rascom)  
**Focus**: Performance, features, architecture improvements

---

## Executive Summary

The RasCode compiler has a **solid foundational architecture** but significant opportunities exist for:
1. **Code generation optimization** (50-200% performance gains)
2. **Language feature expansion** (type system, generics)
3. **Compilation speed** (parallel compilation)
4. **Code quality** (type checking improvements)

---

## Phase 1: Quick Wins (Low Effort, High Impact)

### 1.1 Constant Folding

**Current State**: No compile-time evaluation  
**Opportunity**: Evaluate constant expressions at compile time

```ras
// Current: Generated at runtime
const BUFFER_SIZE = 100 * 1024 * 2;  // 2 multiplications at runtime

// Optimized: Folded to 204800 at compile time
```

**Implementation**:
```c
// In codegen.c: evaluate_constant_expression()
// - Detects binary ops with literal operands
// - Computes result at compile time
// - Emits single constant value

ASTNode *fold_constants(ASTNode *expr) {
    if (expr->type == AST_BINARY_OP) {
        if (is_literal(expr->binary_op.left) && 
            is_literal(expr->binary_op.right)) {
            // Compute result
            int result = compute(expr);
            return create_literal(result);
        }
    }
    return expr;
}
```

**Expected Benefit**: 10-30% reduction in constant computations  
**Effort**: 2-4 hours

---

### 1.2 Dead Code Elimination

**Current State**: No elimination of unreachable code  
**Opportunity**: Remove after unconditional branches

```ras
// Current: Code emitted (wasteful)
fnc test[]::int {
    get[0];
    show["unreachable"];  // Dead code generated
}

// Optimized: Skip unreachable code
```

**Implementation**:
```c
// Analyzer phase: detect-unreachable-code()
// - After unconditional return/exit, mark code dead
// - Skip code generation for dead blocks
// - Warn user about dead code

bool is_unreachable(ASTNode *node) {
    if (node->type == AST_RETURN) {
        return true;  // Everything after return is dead
    }
    if (node->type == AST_BLOCK && 
        has_unconditional_return(node)) {
        return true;
    }
    return false;
}
```

**Expected Benefit**: 5-15% code size reduction  
**Effort**: 3-5 hours

---

### 1.3 String Literal Deduplication

**Current State**: Duplicate string constants emit separately  
**Opportunity**: Share identical string literals

```ras
show["Hello"];  // str_1
show["Hello"];  // str_2 (same content, different constant)

// Optimized: Both use str_1
```

**Implementation**:
```c
// In codegen.c: maintain string_table hash
// - Hash each string literal
// - Reuse identical strings
// - Reduce .rodata section size

typedef struct {
    char *value;
    int label;  // str_N label
} StringConstant;

// HashMap: value → label
```

**Expected Benefit**: 10-50% .rodata reduction (varies by program)  
**Effort**: 2-3 hours

---

### 1.4 Comparison Chain Optimization

**Current State**: `a < b < c` generates suboptimal code  
**Opportunity**: Recognize common patterns

```ras
// Current (generates multiple comparisons)
if[(x > 0) && (x < 100)] { }

// Optimized (single range check)
// x > 0 && x < 100  →  (uintified_x < 100)
```

**Implementation**:
```c
// Pattern recognition in codegen_binary_op()
// Detect: (a CMP b) OP (b CMP c)
// Generate efficient comparison chain
```

**Expected Benefit**: 10-20% conditional speed  
**Effort**: 4-6 hours

---

## Phase 2: Core Optimizations (Medium Effort, Significant Impact)

### 2.1 Register Allocation & Live Range Analysis

**Current State**: All locals on stack (wasteful)  
**Opportunity**: Use CPU registers more efficiently

```ras
fnc calculate[a, b, c]::int {
    int x = a + b;      // x could stay in register
    int y = x * c;      // y could stay in register
    get[y];             // Return y
}
```

**Current Assembly**:
```nasm
mov eax, [rbp - 4]      ; Load a
mov ecx, [rbp - 8]      ; Load b
add eax, ecx            ; Compute x
mov [rbp - 12], eax     ; Store x to stack (!)
mov eax, [rbp - 12]     ; Load x from stack (!)
imul eax, [rbp - 16]    ; Multiply by c
mov [rbp - 20], eax     ; Store y to stack (!)
mov eax, [rbp - 20]     ; Load y from stack (!)
ret
```

**Optimized Assembly**:
```nasm
mov eax, [rbp - 4]      ; Load a (stay in EAX)
add eax, [rbp - 8]      ; Add b directly
imul eax, [rbp - 16]    ; Multiply by c (stay in EAX)
ret                     ; Return in EAX
```

**Implementation Steps**:
1. **Live range analysis** - Determine when variables are "live"
2. **Interference graph** - Build graph of conflicting live ranges
3. **Graph coloring** - Assign registers to minimize conflicts
4. **Code generation** - Emit using allocated registers

**Expected Benefit**: 20-50% performance improvement  
**Effort**: 20-40 hours (complex)

---

### 2.2 Loop Optimization

**Current State**: No special handling for loops  
**Opportunity**: Vectorization, invariant lifting, strength reduction

```ras
// Invariant lifting
loop[i = 0; i < n; i = i + 1] {
    int offset = BASE_ADDR + 1000;  // Invariant (same each iteration)
    arr{offset + i} = i;
}

// Optimized: Compute invariant once
int offset = BASE_ADDR + 1000;  // Pulled outside loop
loop[i = 0; i < n; i = i + 1] {
    arr{offset + i} = i;
}
```

**Other Loop Optimizations**:
- **Loop unrolling**: Reduce branch overhead
- **Strength reduction**: `i * 4` → `i << 2`
- **Induction variable simplification**

**Expected Benefit**: 10-30% loop performance  
**Effort**: 15-25 hours

---

### 2.3 Inline Function Expansion

**Current State**: All calls are full function calls  
**Opportunity**: Inline small functions

```ras
fnc square[x]::int {
    get[x * x];  // Small function: good candidate
}

fnc main[]::int {
    int result = square[5];  // Inline this?
    get[result];
}

// Inlined:
fnc main[]::int {
    int result = 5 * 5;  // Direct computation
    get[result];
}
```

**Heuristics for inlining**:
- Function size < 10 instructions
- Few call sites (< 3)
- No recursion

**Expected Benefit**: 5-15% function call overhead reduction  
**Effort**: 8-12 hours

---

### 2.4 Better Code Scheduling

**Current State**: Emit assembly in AST order  
**Opportunity**: Reorder instructions to reduce stalls

```nasm
; Current (stall danger: mov depends on add)
add eax, ecx            ; 1-3 cycles
mov edx, [rbp - 4]      ; Could execute in parallel
mov [rbp - 8], edx
mov ebx, eax            ; Stall: waits for add result

; Optimized (independent instructions moved up)
mov edx, [rbp - 4]      ; Does not depend on add
mov [rbp - 8], edx      
add eax, ecx            ; Execute in parallel
mov ebx, eax
```

**Implementation**:
- Build dependency graph between instructions
- Use list scheduling algorithm
- Reorder for pipeline efficiency

**Expected Benefit**: 10-25% execution speed  
**Effort**: 12-18 hours

---

## Phase 3: Type System Enhancements

### 3.1 Generic Functions / Parametric Types

**Current State**: No generics, monomorphic functions  
**Opportunity**: Template-style functions

```ras
// Dream syntax (not yet supported)
fnc swap[T][a, b]::none {
    T temp = a;
    a = b;
    b = temp;
}

// Usage:
struct Point { int x; int y; }
Point p1 = {1, 2};
Point p2 = {3, 4};
swap[Point][p1, p2];
```

**Implementation Strategy**:
- Monomorphization (compile multiple copies)
- Type constraints system
- Template specialization

**Expected Benefit**: Reusable code library  
**Effort**: 40-60 hours (complex language change)

---

### 3.2 Union Types / Sum Types

**Current State**: Only product types (groups/structs)  
**Opportunity**: Discriminated unions

```ras
// Dream syntax
type Result = Success[int] | Error[str];

fnc process[]::Result {
    if (error_condition) {
        return Error["Something went wrong"];
    }
    return Success[42];
}
```

**Benefit**: Type-safe error handling  
**Effort**: 30-50 hours

---

## Phase 4: Compilation Infrastructure

### 4.1 Parallel Compilation

**Current State**: Single-threaded compilation  
**Opportunity**: Parallelize independent components

```
Current Timeline:
Lexing (1ms) → Parsing (5ms) → Analysis (5ms) → Codegen (20ms) → Total: ~31ms

Potential with parallelization:
- Multiple source files compiled in parallel (if supported)
- Lexing while parsing previous tokens
- Analysis on one function while codegen processes another
```

**Implementation**:
- Task queue for independent functions
- Thread pool for workers
- Thread-safe symbol table

**Expected Benefit**: 2-4x faster compilation (with multiple cores)  
**Effort**: 20-30 hours

---

### 4.2 Incremental Compilation

**Current State**: Full recompilation every time  
**Opportunity**: Reuse compilations of unchanged modules

```
Current: Every `rascom prog.ras` recompiles everything
Optimized: Only recompile changed files/functions
Benefit: Large projects compile 10-100x faster
```

**Components Needed**:
- Dependency tracking
- File hash/timestamp checking
- Persistent symbol cache
- Incremental linking

**Expected Benefit**: 90% build time reduction (for re-runs)  
**Effort**: 30-50 hours

---

### 4.3 Debug Information Support

**Current State**: No debug symbols  
**Opportunity**: Full DWARF debug info

```
Benefit: Support debuggers (gdb, lldb)
Can step through source code
Can inspect variables at runtime
```

**Implementation**:
- DWARF version 4/5 format
- Line number information
- Variable location tracking
- Type information

**Effort**: 25-40 hours

---

## Phase 5: Language Feature Expansion

### 5.1 Module System

**Current State**: All code in single namespace  
**Opportunity**: Proper module/package system

```ras
// math.ras
module math;

export fnc sqrt[x]::deci { ... }
export fnc pow[x, y]::deci { ... }

// main.ras
use math;

fnc main[]::int {
    deci result = math::sqrt[16.0];
    get[0];
}
```

**Effort**: 25-35 hours

---

### 5.2 Exception Handling Improvements

**Current State**: Basic check/when  
**Opportunity**: Proper exception types and stack unwinding

```ras
type DivisionByZero extends Exception;
type FileNotFound extends Exception;

fnc divide[a, b]::int {
    check {
        if [b == 0] throw DivisionByZero;
        get[a / b];
    } when[e: DivisionByZero] {
        show["Cannot divide by zero"];
    }
}
```

**Effort**: 15-25 hours

---

### 5.3 Pattern Matching

**Current State**: Simple cycle/when  
**Opportunity**: Destructuring and guards

```ras
// Not yet supported
result = match value {
    when [Success[x]] => x + 1,
    when [Error[msg]] where [length[msg] > 10] => -1,
    when _ => 0
}
```

**Effort**: 20-30 hours

---

## Phase 6: Standard Library Expansion

### 6.1 Collections Library

**Current State**: Only arr and map primitives  
**Opportunity**: Rich collection types

```ras
// Not yet supported
Vector[T]: dynamic array
LinkedList[T]: linked list
HashSet[T]: set of unique values
PriorityQueue[T]: ordered queue
Graph[T]: graph data structure
```

**Effort**: 15-30 hours per collection

---

### 6.2 Math Library

**Enhancements**:
- Trigonometric functions (sin, cos, tan)
- Logarithmic functions (log, log10, log2)
- Matrix operations
- Complex numbers

**Effort**: 10-20 hours

---

### 6.3 System/Process Library

**Enhancements**:
- Better file operations (directory handling)
- Process spawning with stream redirection
- Environment variable access
- Signals/interrupts handling

**Effort**: 15-25 hours

---

## Performance Profiling Recommendations

### Before Optimization (Establish Baseline)

```bash
# Profile compiler itself
time rascom -O0 large_program.ras
time rascom -O1 large_program.ras

# Profile generated code
perf record ./compiled_program
perf report
```

### Optimization Strategy

1. **Measure** - Profile to find bottlenecks
2. **Hypothesize** - Propose optimization
3. **Implement** - Code the improvement
4. **Measure Again** - Verify improvement
5. **Evaluate** - Consider complexity vs. benefit

**Key Metrics**:
- Compilation time (seconds)
- Generated code size (bytes)
- Runtime performance (operations/sec)
- Memory usage (bytes)

---

## Architectural Improvements

### Separate Compilation

**Benefit**: Scale to large projects  
**Current Issue**: Everything in one pass

**Solution**:
- Compile each file to intermediate format
- Link intermediate files
- Recompile only changed files

---

### Better Type Checking

**Current**: Basic type checking in analyzer  
**Opportunity**: Full type inference system

```ras
// Type inference
let x = 5;           // Inferred: int
let y = x + 3;       // Inferred: int
let z = y * 2.5;     // Inferred: deci (mixed type)
```

---

### Compiler Plugins

**Opportunity**: Extensible compiler architecture

```ras
// Dream: Custom optimization passes
plugin CustomOptimizer {
    fn analyze(ast: AST) -> Recommendations {
        // Custom analysis
    }
}
```

---

## Implementation Roadmap (Suggested)

### Quarter 1 (Immediate)
- ✅ Constant expression folding (1.1)
- ✅ Dead code elimination (1.2)
- ✅ String deduplication (1.3)

### Quarter 2
- 🔄 Register allocation (2.1)
- 🔄 Loop optimization (2.2)
- 🔄 Inline expansion (2.3)

### Quarter 3
- 🔄 Better scheduling (2.4)
- 🔄 Parallel compilation (4.1)
- 🔄 Debug info (4.3)

### Quarter 4
- 🔄 Generic types (3.1)
- 🔄 Module system (5.1)
- 🔄 Exception improvements (5.2)

---

## Risk Assessment

| Optimization | Risk | Mitigation |
|-------------|------|-----------|
| Register allocation | High (complex) | Start with simple cases |
| Loop optimization | Medium | Test with benchmark suite |
| Parallel compilation | Medium | Thread safety critical |
| Generics | High (language) | Start with syntax design |
| Incremental compile | High (complex) | Dependency tracking critical |

---

## Success Criteria

### Performance Targets
- Compilation speed: 10x faster (50ms → 5ms for typical programs)
- Generated code: 20-30% faster execution
- Code size: 15-20% smaller binaries

### Feature Targets
- Module system working
- Generic functions supported
- Full debug info generation

### Quality Targets
- 95%+ test pass rate
- No memory leaks (all allocations freed)
- Graceful error recovery

---

## Conclusion

The RasCode compiler has a **strong foundation** with significant room for improvement. **Quick wins** (constant folding, DCE) provide immediate benefits, while **medium-effort optimizations** (register allocation, loop opt) deliver substantial performance gains. The roadmap balances immediate improvements with long-term language enhancements.

**Recommended Starting Point**: Constant folding + dead code elimination (Week 1), then progress to register allocation (Weeks 2-3).

---

**Next**: See [16_COMPILER_METRICS.md](16_COMPILER_METRICS.md) for detailed measurements.
