# 01: Compiler Architecture Analysis

**Source**: `main.c`, `lexer.c`, `parser.c`, `codegen.c`, `analyzer.c`

---

## Compiler Pipeline Overview

The RasCode compiler implements a traditional **multi-stage compilation model**:

```
┌─────────────┐
│ Source File │ (*.ras)
└──────┬──────┘
       │
       ▼
┌──────────────────┐
│  LEXER PHASE     │  (lexer.c)
│  Tokenization    │  Input: Source string
└────────┬─────────┘  Output: Token stream
         │
         ▼
┌──────────────────┐
│  PARSER PHASE    │  (parser.c)
│  Syntax Analysis │  Input: Tokens
└────────┬─────────┘  Output: AST
         │
         ▼
┌──────────────────────┐
│  ANALYZER PHASE      │  (analyzer.c)
│  Semantic Analysis   │  Input: AST
│  Type Checking       │  Output: Validated AST
└────────┬─────────────┘
         │
         ▼
┌──────────────────────┐
│  CODEGEN PHASE       │  (codegen.c)
│  Code Generation     │  Input: AST
│  x86-64 emission     │  Output: Assembly (.asm)
└────────┬─────────────┘
         │
         ▼
┌──────────────────────┐
│  ASSEMBLER PHASE     │  (assembler.c)
│  NASM Compilation    │  Input: .asm file
│  Linking             │  Output: Executable
└────────┬─────────────┘
         │
         ▼
┌──────────────────────┐
│  BINARY GENERATOR    │  (elfgen.c)
│  ELF Creation        │  Input: Object files
│                      │  Output: Binary (.bin)
└────────┬─────────────┘
         │
         ▼
┌─────────────────────┐
│ Executable Binary   │ (./program)
└─────────────────────┘
```

---

## Component Responsibilities

### 1. LEXER (`lexer.c` - ~500 lines)

**Responsibility**: Convert source text into token stream  
**Input**: Raw source code string  
**Output**: Token stream for parser  

**Key Data Structures**:
```c
typedef struct {
    const char *source;      // Source code
    int pos;                 // Current position
    int line, col;           // Line/column tracking
    int length;              // Source length
} Lexer;

typedef struct {
    TokenType type;          // Token classification
    char *value;             // Token string value
    int line, col;           // Position info
} Token;
```

**Operations**:
- `lexer_new()` - Initialize lexer from source
- `lexer_next_token()` - Get next token from stream
- Handles: keywords, identifiers, numbers, strings, operators, comments
- Error detection: unterminated strings, invalid escape sequences

**Token Types** (12 categories):
- Keywords: `fnc`, `if`, `while`, `loop`, `show`, `read`, etc.
- Types: `int`, `deci`, `char`, `str`, `bool`, `byte`, `ubyte`, `none`
- Operators: `+`, `-`, `*`, `/`, `%`, `==`, `!=`, `&&`, `||`, etc.
- Delimiters: `{`, `}`, `[`, `]`, `;`, `,`, `::`, `@`, `$`
- Special: identifiers, numbers, strings

---

### 2. PARSER (`parser.c` - ~1500 lines)

**Responsibility**: Build Abstract Syntax Tree from tokens  
**Input**: Token stream  
**Output**: AST root node  

**Parsing Strategy**: **Recursive Descent Parser**

**Key Functions**:
```c
ASTNode *parse_program(Parser *parser);        // Top-level
ASTNode *parse_function(Parser *parser);       // Function defs
ASTNode *parse_statement(Parser *parser);      // Statements
ASTNode *parse_expression(Parser *parser);     // Expressions
ASTNode *parse_primary(Parser *parser);        // Terminals
```

**Operator Precedence** (inherent in recursive descent):
1. Primary (literals, identifiers, parenthesized expressions)
2. Postfix (array/map access, function calls)
3. Unary (negation, NOT)
4. Multiplicative (`*`, `/`, `%`)
5. Additive (`+`, `-`)
6. Relational (`<`, `>`, `<=`, `>=`)
7. Equality (`==`, `!=`)
8. Logical AND (`&&`, `and`)
9. Logical OR (`||`, `or`)
10. Assignment (`=`)

**Error Handling**:
- Context-aware error messages with line numbers
- Source line extraction and display
- Error hints and suggestions
- Parser recovery (partially)

---

### 3. SEMANTIC ANALYZER (`analyzer.c` - ~500 lines)

**Responsibility**: Type checking and semantic validation  
**Input**: AST  
**Output**: Validated AST + type information  

**Key Features**:
- **Type checking**: Verify operand types for operations
- **Symbol resolution**: Resolve variable/function references
- **Scope management**: Track variable scopes
- **Warning system**: Optional warnings (`-Wall`, `-Wextra`)
- **Code completion**: IDE support features
- **Error prediction**: Anticipate runtime issues

**Warnings Supported**:
- Unused variables (`-Wno-unused` to disable)
- Type mismatches (`-Wtype-mismatch`)
- Unreachable code detection
- Variable shadowing (`-Wno-shadowing`)
- Pedantic checks (`-Wpedantic`)

---

### 4. CODEGEN (`codegen.c` - ~2000 lines)

**Responsibility**: Generate executable code from AST  
**Input**: AST  
**Output**: x86-64 assembly code  

**Code Generation Strategy**:
```
Read AST Node
    ↓
Determine node type
    ↓
Generate corresponding x86-64 assembly
    ↓
Manage registers & stack
    ↓
Emit to output .asm file
```

**Key Responsibilities**:
- **Register management**: Allocate x86-64 registers
- **Stack frame management**: Function prologue/epilogue
- **Symbol management**: Maintain symbol table with offsets
- **Label generation**: Create branch targets
- **Assembly emission**: Write .asm output file

**Target Architecture**: x86-64 (64-bit x86 ISA)  
**ABI**: System V AMD64 ABI (Linux/Unix standard)

---

### 5. ASSEMBLER (`assembler.c` - ~300 lines)

**Responsibility**: Compile assembly to machine code  
**Input**: x86-64 assembly (.asm)  
**Output**: Executable binary or object files  

**Process**:
```
Generated .asm file
        ↓
    NASM Invocation
        ↓
Generate .o object files
        ↓
Link with runtime libraries
        ↓
Final executable
```

**External Dependencies**:
- **NASM** (Netwide Assembler) - Compiles assembly to machine code
- **ld** or **gcc** - Link object files

**Security Features**:
- Safe process execution using `fork()` + `execvp()`
- Prevents shell injection attacks
- Replaces unsafe `system()` calls

---

### 6. RUNTIME GENERATOR (`elfgen.c` - ~300 lines)

**Responsibility**: Create executable binaries (ELF format)  
**Input**: Assembly or object files  
**Output**: Final executable (.bin or ELF)  

**ELF Features**:
- Executable and Linkable Format (Linux/Unix standard)
- Position Independent Code (PIE)
- Security sections (.rodata, .got, etc.)
- Debug symbols (optional)

---

## Execution Flow (main.c)

```c
// Typical compilation sequence in main():

1. Parse command-line arguments
2. Read source file into memory
3. Create lexer from source
4. Parse program (lexer → parser → AST)
5. Semantic analysis (type checking)
6. Code generation (AST → x86-64 assembly)
7. Invoke NASM assembler
8. Link with runtime
9. Execute or output binary

// Safe execution:
safe_exec(program, arg1, arg2, NULL);  // Prevents injection
```

---

## Key Architectural Decisions

### 1. Recursive Descent Parser (Not LALR)
**Pros**: 
- Direct AST construction (no intermediate parse tables)
- Easy error reporting with context
- Simple operator precedence handling

**Cons**: 
- Cannot handle all grammar classes
- Left recursion must be eliminated manually

### 2. Symbol Table Strategy
- **Per-scope symbol tables** - Each function has own scope
- **Linked list implementation** - Dynamic size
- **Linear search** - O(n) lookup (acceptable for typical functions)
- **Stack allocation** - Variables offset from frame pointer

### 3. Code Generation Approach
- **Direct AST emission** - No intermediate IR (3-address code)
- **x86-64 targeting** - Modern 64-bit architecture
- **Register allocation** - Simple greedy strategy
- **Stack-based locals** - All local variables on stack

### 4. Type System
- **Static typing** - All types known at compile time
- **Type inference** - Minimal (mostly explicit)
- **No generics** - Fixed set of type primitives
- **Implicit conversions** - Limited (mostly explicit `@type[]`)

---

## Compilation Statistics

| Phase | Typical Time | Output |
|-------|--------------|--------|
| Lexing | <1ms | Token stream (~100-1000 tokens) |
| Parsing | 1-5ms | AST (~100-1000 nodes) |
| Analysis | 1-10ms | Type info + warnings |
| Codegen | 5-50ms | Assembly (~1000-10000 lines) |
| Assembly | 10-100ms | Object files (.o) |
| Linking | 5-50ms | Executable binary |
| **Total** | **~50-200ms** | **Working binary** |

---

## Security Features

### 1. Process Safety
- Uses `fork()` + `execvp()` instead of `system()`
- Prevents shell command injection
- No shell interpretation of arguments

### 2. Memory Safety
- Bounds checking on buffer operations
- No buffer-overflow-prone functions
- Uses `strncpy()` instead of `strcpy()`

### 3. Input Validation
- Lexer validates escape sequences
- Parser rejects malformed syntax early
- Semantic analysis checks type compatibility

---

## Performance Characteristics

### Compilation Speed
- Linear time (mostly) in source size
- Typical: 100KB source → 100-200ms compile time

### Generated Code Efficiency
- Minimal optimization (basic assembly)
- Direct variable access (no extra indirection)
- Simple register allocation strategy

### Memory Usage
- Entire source kept in memory
- Full AST built before codegen
- Linear in source size

---

## Extensibility Points

1. **Adding keywords**: Modify lexer.c `is_keyword()`
2. **New operators**: Update parser precedence
3. **New AST nodes**: Add to ast.h enum + ast.c handlers
4. **Code generation**: Extend codegen.c switch statements
5. **Builtin functions**: Add to builtins.c registry
6. **Type system**: Modify type checking in analyzer.c

---

## Limitations

1. **Single-pass compilation** - Some errors not caught early
2. **No separate compilation** - Must recompile entire program
3. **Basic optimization** - Generated code not heavily optimized
4. **Limited debugging** - Minimal debug symbol support
5. **No incremental compilation** - Full rebuild required

---

**Next**: See individual component analysis documents for deep dives.
