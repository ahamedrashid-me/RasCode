# 09: Builtin Functions Registry

**Source**: `builtins.c`, `builtins.h`  
**Total Functions**: 100+  
**Categories**: 12 (System, Memory, I/O, Network, Security, etc.)

---

## Builtin Function Registry Structure

```c
typedef struct {
    const char *name;            // Function name (without @)
    BuiltinID id;                // Unique ID
    BuiltinCategory category;    // Function category
    int min_args;                // Minimum arguments
    int max_args;                // Maximum arguments (-1 = variadic)
    const char *return_type;     // Return type name
    const char *description;     // Documentation
} BuiltinInfo;
```

---

## Categories (12 Types)

### 1. SYSTEM CONTROL (5 functions)

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 0    | exit          | 1   | 1   | none   | Exit program with status code      |
| 1    | halt          | 0   | 0   | none   | Halt CPU (embedded systems)       |
| 2    | sleep         | 1   | 1   | none   | Sleep for milliseconds            |
| 3    | clock         | 0   | 0   | int    | Get system uptime in ms           |
| 4    | panic         | 1   | 1   | none   | Force termination with error msg  |
```

**Examples**:
```ras
@exit[0];                 // Normal exit
@halt[];                  // Stop CPU
@sleep[1000];            // Sleep 1 second
int uptime = @clock[];
@panic["Critical error"];
```

---

### 2. MEMORY OPERATIONS (17 functions)

**Low-level memory access and management**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 10   | addr          | 1   | 1   | int    | Get memory address of variable    |
| 11   | peek          | 1   | 1   | byte   | Read byte from memory address     |
| 12   | poke          | 2   | 2   | none   | Write byte to memory address      |
| 13   | memcpy        | 3   | 3   | none   | Copy memory block                 |
| 14   | memclr        | 2   | 2   | none   | Clear memory block to 0           |
| 15   | align         | 2   | 2   | int    | Align pointer to boundary         |
| 16   | alloc         | 1   | 1   | int    | Allocate heap memory (size)       |
| 17   | free          | 1   | 1   | none   | Free allocated memory (ptr)       |
| 18   | realloc       | 2   | 2   | int    | Resize allocation (ptr, newsize)  |
| 19   | salloc        | 1   | 1   | int    | Stack allocate (size in bytes)    |
| 20   | memset        | 3   | 3   | none   | Set memory to value (ptr,val,sz)  |
| 21   | memcmp        | 3   | 3   | int    | Compare memory blocks (ptr1,ptr2) |
| 22   | mmap          | 3   | 3   | int    | Memory map (size, prot, flags)    |
| 23   | munmap        | 2   | 2   | int    | Unmap memory (ptr, size)          |
| 24   | mprotect      | 3   | 3   | int    | Change protection (ptr,sz,prot)   |
| 25   | heap_start    | 0   | 0   | int    | Get heap start address            |
| 26   | heap_end      | 0   | 0   | int    | Get heap end address              |
```

**Examples**:
```ras
int var = 100;
int addr = @addr[var];              // Get address
byte val = @peek[addr];             // Read 1 byte
@poke[addr, 200];                  // Write 1 byte

int ptr = @alloc[1024];            // Allocate 1KB
@memcpy[ptr, src, 256];            // Copy 256 bytes
@free[ptr];                        // Deallocate

@memset[ptr, 0, 1024];             // Zero out memory
```

---

### 3. MEMORY FENCES (3 functions)

**Synchronization primitives for concurrent access**:

```c
|  ID  | Function      | Purpose                           |
|------|---------------|-----------------------------------|
| 27   | mfence        | Full memory barrier               |
| 28   | lfence        | Load memory barrier               |
| 29   | sfence        | Store memory barrier              |
```

---

### 4. TYPE CONVERSION (6 functions)

**Type casting and conversion**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 30   | type          | 1   | -1  | varies | Unified type cast @type[x]::type  |
| 31   | to_int        | 1   | 1   | int    | Convert to int (DEPRECATED)       |
| 32   | to_deci       | 1   | 1   | deci   | Convert to deci (DEPRECATED)      |
| 33   | to_byte       | 1   | 1   | byte   | Convert to byte (DEPRECATED)      |
| 34   | to_bool       | 1   | 1   | bool   | Convert to bool (DEPRECATED)      |
| 35   | to_str        | 1   | 1   | str    | Convert to str (DEPRECATED)       |
```

**Modern usage** (recommended):
```ras
@type[42]::str          // int to string: "42"
@type["42"]::int        // string to int: 42
@type[3.14]::int        // float to int: 3
@type[true]::int        // bool to int: 1
```

---

### 5. FILE I/O (6 functions)

**File operations**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 40   | fopen         | 2   | 2   | int    | Open file (path, mode)            |
| 41   | fread         | 3   | 3   | int    | Read from file (fd, buf, size)    |
| 42   | fwrite        | 3   | 3   | int    | Write to file (fd, buf, size)     |
| 43   | fseek         | 2   | 2   | int    | Seek file position (fd, offset)   |
| 44   | fclose        | 1   | 1   | int    | Close file descriptor             |
| 45   | fdelete       | 1   | 1   | int    | Delete file by path               |
```

**Examples**:
```ras
int fd = @fopen["output.txt", "w"];
@fwrite[fd, "Hello\n", 6];
@fclose[fd];

int fd2 = @fopen["input.txt", "r"];
byte buffer{256};
int bytes_read = @fread[fd2, buffer, 256];
@fclose[fd2];
```

---

### 6. NETWORK (8 functions)

**Network socket operations**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 50   | socket        | 2   | 2   | int    | Create socket (type, protocol)    |
| 51   | connect       | 3   | 3   | int    | Connect (socket, addr, port)      |
| 52   | send          | 3   | 3   | int    | Send data (socket, buf, len)      |
| 53   | recv          | 3   | 3   | int    | Receive data (socket, buf, len)   |
| 54   | bind          | 3   | 3   | int    | Bind (socket, addr, port)         |
| 55   | listen        | 2   | 2   | int    | Listen (socket, backlog)          |
| 56   | accept        | 1   | 1   | int    | Accept connection (socket)        |
| 57   | close         | 1   | 1   | int    | Close socket                      |
```

---

### 7. SECURITY (5 functions)

**Cryptographic and security operations**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 60   | hash          | 2   | 2   | int    | Hash data (buffer, algorithm)     |
| 61   | rand          | 1   | 1   | int    | Generate random bytes (size)      |
| 62   | secure_zero   | 2   | 2   | none   | Securely zero memory (ptr, size)  |
| 63   | entropy       | 0   | 0   | int    | Read hardware entropy             |
| 64   | verify        | 3   | 3   | bool   | Verify signature (sig, pub, data) |
```

**Examples**:
```ras
int entropy_bytes = @entropy[];     // Get random entropy
int hash_val = @hash[buffer, 1];   // Hash with algo 1 (MD5, SHA1, etc)
@secure_zero[sensitive_ptr, 256];  // Securely wipe memory
```

---

### 8. STRING/CONVERSION (8 functions)

**String manipulation and utility conversion**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 70   | len           | 1   | 1   | int    | Get length of string/array        |
| 71   | sizeof        | 1   | 1   | int    | Get size of type in bytes         |
| 72   | concat        | 2   | 2   | str    | Concatenate strings (str1, str2)  |
| 73   | substr        | 3   | 3   | str    | Substring (str, start, len)       |
| 74   | strcmp        | 2   | 2   | int    | Compare strings (0=equal)         |
| 75   | chr           | 1   | 1   | char   | Convert int to char (ASCII)       |
| 76   | ord           | 1   | 1   | int    | Convert char to int (ASCII code)  |
| 77   | split         | 2   | 2   | arr    | Split string by delim (PARTIAL)   |
```

**Examples**:
```ras
int len = @len["Hello"];                // 5
str greeting = @concat["Hello", " World"];  // "Hello World"
str part = @substr["Hello", 1, 3];      // "ell"
int cmp = @strcmp["abc", "abc"];        // 0 (equal)
char c = @chr[65];                      // 'A'
int ascii = @ord['A'];                  // 65
```

---

### 9. HARDWARE (6 functions)

**Low-level hardware access**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 80   | port_in       | 1   | 1   | byte   | Read from I/O port                |
| 81   | port_out      | 2   | 2   | none   | Write to I/O port (port, val)     |
| 82   | irq_enable    | 1   | 1   | none   | Enable interrupt (IRQ number)     |
| 83   | irq_disable   | 1   | 1   | none   | Disable interrupt                 |
| 84   | ioread        | 1   | 1   | int    | Read memory-mapped I/O            |
| 85   | iowrite       | 2   | 2   | none   | Write memory-mapped I/O (addr,v)  |
```

---

### 10. PROCESS/THREAD (4 functions)

**Process and thread management**:

```c
|  ID  | Function      | Min | Max | Return | Purpose                           |
|------|---------------|-----|-----|--------|-----------------------------------|
| 90   | spawn         | 2   | 2   | int    | Create thread/process (fn, arg)   |
| 91   | join          | 1   | 1   | int    | Wait for thread (tid)             |
| 92   | pid           | 0   | 0   | int    | Get process ID                    |
| 93   | kill          | 1   | 1   | int    | Terminate process (pid)           |
```

---

### 11. SYNCHRONIZATION (15 functions)

**Concurrency primitives**:

```c
|  ID  | Function           | Purpose                         |
|------|--------------------|---------------------------------|
| 110  | mutex_create       | Create mutex, return ID         |
| 111  | mutex_lock         | Lock mutex (blocking)           |
| 112  | mutex_unlock       | Unlock mutex                    |
| 113  | mutex_trylock      | Try lock (non-blocking)         |
| 114  | cond_create        | Create condition variable       |
| 115  | cond_wait          | Wait on condition (blocking)    |
| 116  | cond_signal        | Signal one waiter               |
| 117  | cond_broadcast     | Signal all waiters              |
| 118  | rwlock_create      | Create reader-writer lock       |
| 119  | rwlock_read_lock   | Acquire read lock               |
| 120  | rwlock_read_unlock | Release read lock               |
| 121  | rwlock_write_lock  | Acquire write lock              |
| 122  | rwlock_write_unlock| Release write lock              |
| 123  | barrier_create     | Create barrier (n threads)      |
| 124  | barrier_wait       | Wait at barrier                 |
```

**Example**:
```ras
int lock = @mutex_create[];
@mutex_lock[lock];
// ... critical section ...
@mutex_unlock[lock];
```

---

### 12. MATH OPERATIONS (8+ functions)

**Mathematical calculations**:

```c
Functions available via builtins:
- @abs - Absolute value
- @min - Minimum of two values
- @max - Maximum of two values
- @sqrt - Square root
- @pow - Power (base, exponent)
- @floor - Floor (round down)
- @ceil - Ceiling (round up)
- @round - Round to nearest
```

---

## Usage Pattern

### Calling Builtins

```ras
@function_name[arg1, arg2, ...];
```

### With Return Values

```ras
int result = @len["Hello"];
str concatenated = @concat["a", "b"];
```

### Variadic Builtins

```ras
@type[value]::target_type     // Variadic type conversion
```

---

## Builtin Function Categories Summary

| Category | Count | Examples | Purpose |
|----------|-------|----------|---------|
| System | 5 | exit, sleep, clock | Program control |
| Memory | 17 | alloc, free, memcpy | Memory management |
| I/O | 6 | fopen, fread, fwrite | File operations |
| Network | 8 | socket, connect, send | Network ops |
| Security | 5 | hash, rand, entropy | Cryptography |
| String | 8 | len, concat, split | String operations |
| Hardware | 6 | port_in, ioread | H/W access |
| Process | 4 | spawn, join, pid | Process control |
| Sync | 15 | mutex_lock, cond_wait | Concurrency |
| **Total** | **~100** | **...** | **Comprehensive stdlib** |

---

## Safety Features

### 1. Argument Validation
```c
int min_args = builtin_info->min_args;    // Must have minimum
int max_args = builtin_info->max_args;    // Enforce maximum
```

### 2. Type Checking
Each builtin specifies return type for type safety

### 3. Error Handling
Most functions return error codes (-1, 0, false, etc.)

### 4. Memory Safety
Memory functions bounds-checked where possible

---

## Performance Characteristics

| Operation | Time | Notes |
|-----------|------|-------|
| `@len[str]` | O(n) | String length scan |
| `@concat[s1,s2]` | O(n+m) | n=len(s1), m=len(s2) |
| `@substr[s,i,l]` | O(l) | l = substring length |
| `@memcpy[...]` | O(n) | n = bytes copied |
| `@alloc[size]` | O(1) | Heap allocation |

---

## Best Practices

1. **Memory**: Always pair `@alloc[]` with `@free[]`
2. **Synchronization**: Always unlock after lock
3. **Files**: Close file descriptors after use
4. **Type: Use `@type[x]::target` for conversions (modern)
5. **Safety**: Use `@secure_zero[]` for sensitive data

---

**Next**: See [17_OPTIMIZATION_OPPORTUNITIES.md](17_OPTIMIZATION_OPPORTUNITIES.md) for builtin optimization suggestions.
