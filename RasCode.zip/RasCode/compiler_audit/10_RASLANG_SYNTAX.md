# 10: RasLang Syntax Reference

**Source**: `lexer.c`, `parser.c`, `docs/02-SYNTAX-RULES.md`  
**Language Name**: RasLang  
**Compilation Model**: Single-pass compilation to x86-64 assembly

---

## Program Structure

Every RasLang program has this hierarchical structure:

```ras
[Package Imports]     ← Optional (pkg:name;)
[Global Constants]    ← Optional (const NAME = value;)
[Group Definitions]   ← Optional (group Name { fields })
[Function Definitions] ← Required (fnc main[]::int { ... })
```

### Minimal Program

```ras
fnc main[]::int {
    show["Hello, World!"];
    get[0];
}
```

**Execution**: `rascom program.ras` → Compiles to executable

---

## Syntax Rules (from lexer.c and parser.c)

### 1. Statement Termination

**Rule**: Every statement ends with semicolon (`;`), EXCEPT block statements

```ras
// These need semicolons:
int x = 5;              ✓
x = 10;                 ✓
show["Hello"];          ✓
get[5];                 ✓
@len["string"];         ✓
arr{0} = 1;             ✓

// These DON'T need semicolons after the block:
if[x > 0] {             ✗ No semicolon after }
    show["Positive"];
}

while[true] {           ✗ No semicolon after }
    // loop body
}
```

### 2. Brackets vs Braces vs Parentheses

RasLang uses **three distinct bracket types**, each with specific meaning:

#### Square Brackets `[ ]` (TOK_LBRACKET / TOK_RBRACKET)
Used for:
- Function parameters: `fnc add[a, b]::int`
- Function calls: `show[x]`
- Statement conditions: `if[x > 0]`, `while[x < 10]`
- Array initializers: `{1, 2, 3}`
- Builtin function calls: `@len[str]`

```ras
fnc greet[name]::none {         // Parameters in []
    show[name];                 // Argument in []
}

if[x > 0] { ... }               // Condition in []
@concat["Hello", " World"]      // Builtins in []
```

#### Curly Braces `{ }` (TOK_LBRACE / TOK_RBRACE)
Used for:
- Code blocks: function bodies, if bodies, loop bodies
- Array type specification: `arr{int, 10}` (array of int, size 10)
- Array indexing: `arr{0}`, `arr{i}`, `name{index}`
- Array/map literals: `{1, 2, 3}` or `{10, 20, 30}`

```ras
fnc test[]::int {               // Braces for code block
    arr{int, 10} nums;          // Braces for array type
    nums{0} = 5;                // Braces for indexing
    get[0];
}
```

#### Parentheses `( )` (TOK_LPAREN / TOK_RPAREN)
Used for:
- Grouping expressions: `(a + b) * c`
- No special language meaning beyond grouping

```ras
int y = (5 + 3) * 2;            // Parentheses for grouping
int z = ((a + b) * (c - d));    // Nested grouping
```

### 3. Delimiters Reference

| Delimiter | Name | Type | Usage | Example |
|-----------|------|------|-------|---------|
| `[ ]` | Square brackets | Function/statement | Params, args, conditions | `fnc[a,b]`, `if[x>0]` |
| `{ }` | Curly braces | Code/data | Blocks, types, indexing | `{code}`, `arr{int,10}` |
| `( )` | Parentheses | Expression | Grouping | `(a+b)*c` |
| `:` | Colon | Separator | Type separator in cycle | `when[val]:` |
| `::` | Double colon | Type | Return type | `fnc f[]::int` |
| `;` | Semicolon | Terminator | Statement end | `int x;` |
| `,` | Comma | Separator | Parameter/arg separator | `fnc[a,b,c]` |
| `.` | Period | Accessor | Member access | `struct.field` |
| `->` | Arrow | Accessor | Map operations | `map->get[key]` |
| `@` | At sign | Prefix | Builtin functions | `@len[str]` |
| `$` | Dollar | Prefix | String interpolation | `"Value: $x"` |

---

## Comments

### Line Comments

```ras
// Single line comment
show["Hello"];  // Comment at end of line
```

**Effect**: Text from `//` to end of line is ignored

### Multiline Comments

```ras
//> This is a multiline comment
    that spans multiple lines
    and continues here
<//
```

**Syntax**: Start with `//>` end with `<//`  
**Nesting**: Comments cannot nest (inner `<//` ends outer comment)

---

## Tokens and Operators

### Arithmetic Operators

| Operator | Token | Precedence | Associativity | Example |
|----------|-------|-----------|---------------|---------|
| `+` | TOK_PLUS | 4 (additive) | Left | `a + b` |
| `-` | TOK_MINUS | 4 | Left | `a - b` |
| `*` | TOK_STAR | 5 (multiplicative) | Left | `a * b` |
| `/` | TOK_SLASH | 5 | Left | `a / b` (integer division) |
| `%` | TOK_PERCENT | 5 | Left | `a % b` (modulo) |
| `-` | TOK_MINUS | 8 (unary) | Right | `-a` (negation) |

### Comparison Operators

| Operator | Token | Type | Example | Result |
|----------|-------|------|---------|--------|
| `==` | TOK_EQ | Equality | `a == b` | bool |
| `!=` | TOK_NE | Inequality | `a != b` | bool |
| `<` | TOK_LT | Less than | `a < b` | bool |
| `>` | TOK_GT | Greater than | `a > b` | bool |
| `<=` | TOK_LE | Less or equal | `a <= b` | bool |
| `>=` | TOK_GE | Greater or equal | `a >= b` | bool |

### Logical Operators

| Operator | Keyword | Token | Example | Result |
|----------|---------|-------|---------|--------|
| `&&` | `and` | TOK_AND | `a && b` | bool (short-circuit AND) |
| `\|\|` | `or` | TOK_OR | `a \|\| b` | bool (short-circuit OR) |
| `!` | `not` | TOK_NOT | `!a` | bool (logical NOT) |
| `^` | `xor` | TOK_XOR | `a ^ b` | bool (XOR) |

### Bitwise Operators (x86-64 backend)

| Operator | Meaning | Example |
|----------|---------|---------|
| `&` | Bitwise AND | `a & b` |
| `\|` | Bitwise OR | `a \| b` |
| `^` | Bitwise XOR | `a ^ b` |
| `~` | Bitwise NOT | `~a` |
| `<<` | Left shift | `a << 2` |
| `>>` | Right shift | `a >> 3` |

### Assignment Operator

| Operator | Meaning | Example |
|----------|---------|---------|
| `=` | Assignment | `x = 10;` |

**Note**: No compound assignments (`+=`, `-=`, etc.) in base syntax

---

## Operator Precedence (High to Low)

```
1. Postfix operators (function calls, array/map access)
2. Unary operators (-, !, ~, not)
3. Multiplicative (*, /, %)
4. Additive (+, -)
5. Shift (<<, >>)
6. Relational (<, >, <=, >=)
7. Equality (==, !=)
8. Bitwise AND (&)
9. Bitwise XOR (^)
10. Bitwise OR (|)
11. Logical AND (&&, and)
12. Logical OR (||, or)
13. Assignment (=)
```

---

## Keywords (30+)

### Control Flow (8)
- `fnc` - Function definition
- `get` - Return statement
- `if` - Conditional statement
- `while` - While loop
- `loop` - For-loop equivalent
- `cycle` - Switch statement
- `when` - Case label / Try handler
- `check` - Try block

### Data Types (8)
- `int` - 32-bit signed integer
- `deci` - 64-bit floating point
- `char` - Single character
- `str` - String (variable-length)
- `bool` - Boolean value
- `byte` - Unsigned byte
- `ubyte` - Unsigned byte
- `none` - Void/null type

### Data Structures (3)
- `arr` - Array type
- `map` - Hash map type
- `group` - Struct/record type

### Modules (3)
- `pkg` - Package import
- `use` - Use statement
- `const` - Global constant

### Booleans (2)
- `true` - Boolean true (1)
- `false` - Boolean false (0)

### Logical Keywords (4)
- `and` - Logical AND
- `or` - Logical OR
- `xor` - Logical XOR
- `not` - Logical NOT

### I/O Keywords (2)
- `show` - Output/print
- `read` - Input/read

### Special (1)
- `fixed` - Fixed-point numbers (rare)
- `set` - Set/assignment operation

---

## String Interpolation

RasLang supports **string interpolation** in string literals:

### Simple Variable Interpolation

```ras
str name = "World";
show["Hello $name"];        // Output: Hello World
```

### Expression Interpolation

```ras
int x = 10;
int y = 20;
show["Sum: ${x + y}"];      // Output: Sum: 30
```

### Complex Expressions

```ras
show["Calc: ${(a + b) * c}"];
show["Array: ${arr{0}}"];
show["Map: ${map->get[key]}"];
```

### How It Works

**At compile time**:
```ras
show["Hello $name"];
```

**Becomes**:
```ras
str _interp_1 = @concat["Hello ", @type[name]::str];
show[_interp_1];
```

---

## Identifiers

**Valid identifiers** (from lexer.c):

```ras
variable              // Lowercase snake_case
_private             // Underscore prefix for private
snake_case_names     // Underscores for word separation
camelCase            // Camel case allowed
CONSTANT_NAMES       // All caps for constants
func123              // Numbers allowed (not as first char)
__special__          // Double underscore allowed
_123nums             // Starts with underscore, then numbers
```

**Invalid identifiers**:

```ras
123invalid           // Cannot start with number
my-var              // Hyphens not allowed
my var              // Spaces not allowed
"string"            // Strings are not identifiers
```

**Reserved**: All keywords are reserved and cannot be used as identifiers

---

## Literals

### Number Literals

```ras
// Integer literals
123                 // Decimal
0xFF                // Hexadecimal
0755                // Octal
0b1010              // Binary

// Floating point literals
3.14                // Decimal point
2.71828
1.23e-4             // Scientific notation (if supported)
0.00001
```

### Boolean Literals

```ras
true                // Boolean true
false               // Boolean false
```

### Character Literals

```ras
'A'                 // Uppercase letter
'5'                 // Digit character
' '                 // Space
'\n'                // Newline escape
'\t'                // Tab
'\\'                // Backslash
'\''                // Single quote
```

### String Literals

```ras
"Simple string"
"With\nescape\tsequences"
"With \"quoted\" text"
"Interpolation: $var"
"Expression: ${x + y}"
""                  // Empty string
```

---

## Escape Sequences in Strings and Characters

| Escape | Meaning | Example |
|--------|---------|---------|
| `\n` | Newline | `"Line1\nLine2"` |
| `\t` | Tab | `"Col1\tCol2"` |
| `\r` | Carriage return | `"Windows\rLine"` |
| `\\` | Backslash | `"C:\\path"` |
| `\"` | Double quote | `"Say \"Hi\""` |
| `\'` | Single quote | `'It\'s'` |
| `\x##` | Hex byte | `"\xFF"` |
| `\###` | Octal byte | `"\101"` (= 'A') |

---

## Scope and Naming

### Global Scope

```ras
const GLOBAL_CONST = 100;       // Accessible everywhere

fnc helper[]::int {
    get[GLOBAL_CONST];
}

fnc main[]::int {
    get[GLOBAL_CONST];
}
```

### Function Scope

```ras
fnc test[]::int {
    int local_var = 10;         // Scope: inside this function
    // local_var is NOT accessible outside
    get[local_var];
}
```

### Block Scope

```ras
fnc test[]::int {
    int x = 10;
    if[true] {
        int y = 20;             // Scope: inside if block
        // y not accessible outside if
    }
    // Cannot access y here
    get[x];
}
```

---

## Statement Types

### Variable Declaration

```ras
int x;              // Uninitialized
int x = 10;         // Initialized
deci pi = 3.14159;
str name = "Alice";
bool active = true;
```

### Assignment

```ras
x = 20;
y = x + 5;
name = "Bob";
```

### Function Call

```ras
show["Hello"];
read[];
helper[];
@len["string"];
```

### Builtin Function Call

```ras
@len[arr]
@type[x]::int
@concat[str1, str2]
```

### Array Access

```ras
int val = arr{0};
arr{1} = 42;
arr{i + 1} = arr{i} + 1;
```

### Return Statement

```ras
get[0];             // Return value to caller
get[result];
get[x + y];
```

### Control Flow

```ras
if[condition] { ... }
if[condition] { ... } else { ... }

while[condition] { ... }

loop[init; condition; increment] { ... }

cycle[expr] {
    when[val1]: { ... }
    when[val2]: { ... }
}

check { ... }
when[exception]: { ... }
```

---

## Type Compatibility

### Implicit Conversions

```ras
int x = 5;
deci y = x;         // OK: int → deci (widening)
```

### Explicit Conversions

```ras
int i = 42;
@type[i]::str       // int → str: "42"
@type[i]::deci      // int → deci: 42.0

deci d = 3.14;
@type[d]::int       // deci → int: 3 (truncation)

str s = "42";
@type[s]::int       // str → int: 42 (parsing)
```

---

## Program Entry Point

**Required**: Every program must have a `main` function

```ras
fnc main[]::int {
    show["Entry point"];
    get[0];             // Exit code 0 (success)
}
```

**Execution sequence**:
1. Global constants initialized
2. Global groups defined
3. `main[]` function called
4. Program exits with return value

---

**Next**: See [11_DATA_TYPES.md](11_DATA_TYPES.md) for complete type system reference.
