global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify
extern safe_alloc_versioned, safe_free_versioned, validate_array_access, memory_safety_init

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



skip_whitespace:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter s
    mov [rbp-16], rsi     ; parameter idx
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L2:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L3
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load s
    push rax            ; save str
    mov rax, 1
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, [rbp - 16]  ; load idx
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR13]
section .data
.STR13: db 0x20, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check left operand
    jnz .L11            ; if true, result is true
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR14]
section .data
.STR14: db 0x09, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jnz .L11            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L12
.L11:
    mov rax, 1          ; result is 1
.L12:
    test rax, rax       ; check left operand
    jnz .L9            ; if true, result is true
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR15]
section .data
.STR15: db 0x0a, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jnz .L9            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L10
.L9:
    mov rax, 1          ; result is 1
.L10:
    test rax, rax       ; check left operand
    jnz .L7            ; if true, result is true
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR16]
section .data
.STR16: db 0x0d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jnz .L7            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L8
.L7:
    mov rax, 1          ; result is 1
.L8:
    cmp rax, 0
    je .L5
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_17       ; jump if overflow flag set
    jmp .overflow_done_18
.overflow_17:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_18:
    mov [rbp - 16], rax  ; assign idx
    jmp .L6
.L5:
    jmp .L3
.L6:
    add rsp, 8         ; pop 1 block-local variables
.L4:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_19       ; jump if overflow flag set
    jmp .overflow_done_20
.overflow_19:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_20:
    mov [rbp - 16], rax  ; assign idx
    jmp .L2
.L3:
    mov rax, [rbp - 16]  ; load idx
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

char_at:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_21
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_21:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_22
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_22:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter s
    mov [rbp-16], rsi     ; parameter idx
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    cmp rax, 0
    je .L23
    lea rax, [rel .STR25]
section .data
.STR25: db 0x30, 0x00
section .text
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L24
.L23:
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load s
    push rax            ; save str
    mov rax, 1
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, [rbp - 16]  ; load idx
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L24:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

validate_string:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_26
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_26:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_27
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_27:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter s
    mov [rbp-16], rsi     ; parameter idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_28
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_28
.recursion_limit_28:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_28:
    push rax            ; var ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR31]
section .data
.STR31: db 0x22, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L29
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L30
.L29:
.L30:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_32       ; jump if overflow flag set
    jmp .overflow_done_33
.overflow_32:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_33:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L34:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L35
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_37
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_37
.recursion_limit_37:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_37:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR40]
section .data
.STR40: db 0x22, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L38
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_41       ; jump if overflow flag set
    jmp .overflow_done_42
.overflow_41:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_42:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L39
.L38:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR45]
section .data
.STR45: db 0x5c, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L43
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_46       ; jump if overflow flag set
    jmp .overflow_done_47
.overflow_46:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_47:
    mov [rbp - 16], rax  ; assign idx
    jmp .L44
.L43:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_48       ; jump if overflow flag set
    jmp .overflow_done_49
.overflow_48:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_49:
    mov [rbp - 16], rax  ; assign idx
.L44:
.L39:
.L36:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_50       ; jump if overflow flag set
    jmp .overflow_done_51
.overflow_50:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_51:
    mov [rbp - 16], rax  ; assign idx
    jmp .L34
.L35:
    mov rax, -1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

validate_number:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_52
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_52:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_53
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_53:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter s
    mov [rbp-16], rsi     ; parameter idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_54
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_54
.recursion_limit_54:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_54:
    push rax            ; var ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR57]
section .data
.STR57: db 0x2d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L55
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_58       ; jump if overflow flag set
    jmp .overflow_done_59
.overflow_58:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_59:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_60
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_60
.recursion_limit_60:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_60:
    mov [rbp - 24], rax  ; assign ch
    jmp .L56
.L55:
.L56:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR63]
section .data
.STR63: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L61
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_64       ; jump if overflow flag set
    jmp .overflow_done_65
.overflow_64:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_65:
    mov [rbp - 16], rax  ; assign idx
    jmp .L62
.L61:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR70]
section .data
.STR70: db 0x31, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L68             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR71]
section .data
.STR71: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L68             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L69
.L68:
    xor rax, rax        ; result is 0
.L69:
    cmp rax, 0
    je .L66
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L72:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L73
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_75
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_75
.recursion_limit_75:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_75:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR80]
section .data
.STR80: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L78             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR81]
section .data
.STR81: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L78             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L79
.L78:
    xor rax, rax        ; result is 0
.L79:
    cmp rax, 0
    je .L76
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_82       ; jump if overflow flag set
    jmp .overflow_done_83
.overflow_82:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_83:
    mov [rbp - 16], rax  ; assign idx
    jmp .L77
.L76:
    jmp .L73
.L77:
.L74:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_84       ; jump if overflow flag set
    jmp .overflow_done_85
.overflow_84:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_85:
    mov [rbp - 16], rax  ; assign idx
    jmp .L72
.L73:
    jmp .L67
.L66:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L67:
.L62:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_86
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_86
.recursion_limit_86:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_86:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR89]
section .data
.STR89: db 0x2e, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L87
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_90       ; jump if overflow flag set
    jmp .overflow_done_91
.overflow_90:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_91:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_92
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_92
.recursion_limit_92:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_92:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR97]
section .data
.STR97: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L95             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR98]
section .data
.STR98: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L95             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L96
.L95:
    xor rax, rax        ; result is 0
.L96:
    cmp rax, 0
    je .L93
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L99:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L100
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_102
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_102
.recursion_limit_102:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_102:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR107]
section .data
.STR107: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L105             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR108]
section .data
.STR108: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L105             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L106
.L105:
    xor rax, rax        ; result is 0
.L106:
    cmp rax, 0
    je .L103
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_109       ; jump if overflow flag set
    jmp .overflow_done_110
.overflow_109:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_110:
    mov [rbp - 16], rax  ; assign idx
    jmp .L104
.L103:
    jmp .L100
.L104:
.L101:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_111       ; jump if overflow flag set
    jmp .overflow_done_112
.overflow_111:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_112:
    mov [rbp - 16], rax  ; assign idx
    jmp .L99
.L100:
    jmp .L94
.L93:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L94:
    jmp .L88
.L87:
.L88:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_113
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_113
.recursion_limit_113:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_113:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR118]
section .data
.STR118: db 0x65, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check left operand
    jnz .L116            ; if true, result is true
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR119]
section .data
.STR119: db 0x45, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jnz .L116            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L117
.L116:
    mov rax, 1          ; result is 1
.L117:
    cmp rax, 0
    je .L114
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_120       ; jump if overflow flag set
    jmp .overflow_done_121
.overflow_120:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_121:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_122
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_122
.recursion_limit_122:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_122:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR127]
section .data
.STR127: db 0x2b, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check left operand
    jnz .L125            ; if true, result is true
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR128]
section .data
.STR128: db 0x2d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    test rax, rax       ; check right operand
    jnz .L125            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L126
.L125:
    mov rax, 1          ; result is 1
.L126:
    cmp rax, 0
    je .L123
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_129       ; jump if overflow flag set
    jmp .overflow_done_130
.overflow_129:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_130:
    mov [rbp - 16], rax  ; assign idx
    jmp .L124
.L123:
.L124:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_131
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_131
.recursion_limit_131:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_131:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR136]
section .data
.STR136: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L134             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR137]
section .data
.STR137: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L134             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L135
.L134:
    xor rax, rax        ; result is 0
.L135:
    cmp rax, 0
    je .L132
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L138:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L139
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_141
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_141
.recursion_limit_141:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_141:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR146]
section .data
.STR146: db 0x30, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setge al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L144             ; if false, skip right
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR147]
section .data
.STR147: db 0x39, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    test rax, rax       ; check right operand
    jz .L144             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L145
.L144:
    xor rax, rax        ; result is 0
.L145:
    cmp rax, 0
    je .L142
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_148       ; jump if overflow flag set
    jmp .overflow_done_149
.overflow_148:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_149:
    mov [rbp - 16], rax  ; assign idx
    jmp .L143
.L142:
    jmp .L139
.L143:
.L140:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_150       ; jump if overflow flag set
    jmp .overflow_done_151
.overflow_150:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_151:
    mov [rbp - 16], rax  ; assign idx
    jmp .L138
.L139:
    jmp .L133
.L132:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L133:
    jmp .L115
.L114:
.L115:
    mov rax, [rbp - 16]  ; load idx
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

validate_value:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_152
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_152:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_153
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_153:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter s
    mov [rbp-16], rsi     ; parameter idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_154
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_154
.recursion_limit_154:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_154:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_155
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_155
.recursion_limit_155:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_155:
    push rax            ; var ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR158]
section .data
.STR158: db 0x22, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L156
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_159
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_string
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_159
.recursion_limit_159:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_159:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L157
.L156:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR162]
section .data
.STR162: db 0x7b, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L160
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_163       ; jump if overflow flag set
    jmp .overflow_done_164
.overflow_163:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_164:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_165
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_165
.recursion_limit_165:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_165:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_166
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_166
.recursion_limit_166:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_166:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR169]
section .data
.STR169: db 0x7d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L167
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_170       ; jump if overflow flag set
    jmp .overflow_done_171
.overflow_170:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_171:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L168
.L167:
.L168:
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L172:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L173
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_175
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_175
.recursion_limit_175:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_175:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_176
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_176
.recursion_limit_176:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_176:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR179]
section .data
.STR179: db 0x22, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L177
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L178
.L177:
.L178:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_180
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_string
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_180
.recursion_limit_180:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_180:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    neg rax             ; unary minus
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L181
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L182
.L181:
.L182:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_183
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_183
.recursion_limit_183:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_183:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_184
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_184
.recursion_limit_184:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_184:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR187]
section .data
.STR187: db 0x3a, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L185
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L186
.L185:
.L186:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_188       ; jump if overflow flag set
    jmp .overflow_done_189
.overflow_188:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_189:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_190
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_190
.recursion_limit_190:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_190:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    neg rax             ; unary minus
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L191
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L192
.L191:
.L192:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_193
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_193
.recursion_limit_193:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_193:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_194
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_194
.recursion_limit_194:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_194:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR197]
section .data
.STR197: db 0x2c, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L195
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_198       ; jump if overflow flag set
    jmp .overflow_done_199
.overflow_198:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_199:
    mov [rbp - 16], rax  ; assign idx
    jmp .L196
.L195:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR202]
section .data
.STR202: db 0x7d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L200
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_203       ; jump if overflow flag set
    jmp .overflow_done_204
.overflow_203:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_204:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L201
.L200:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L201:
.L196:
.L174:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_205       ; jump if overflow flag set
    jmp .overflow_done_206
.overflow_205:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_206:
    mov [rbp - 16], rax  ; assign idx
    jmp .L172
.L173:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L161
.L160:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR209]
section .data
.STR209: db 0x5b, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L207
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_210       ; jump if overflow flag set
    jmp .overflow_done_211
.overflow_210:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_211:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_212
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_212
.recursion_limit_212:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_212:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_213
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_213
.recursion_limit_213:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_213:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR216]
section .data
.STR216: db 0x5d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L214
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_217       ; jump if overflow flag set
    jmp .overflow_done_218
.overflow_217:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_218:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L215
.L214:
.L215:
    mov rax, [rbp - 16]  ; load idx
    mov [rbp - 16], rax  ; assign idx
.L219:
    mov rax, [rbp - 16]  ; load idx
    push rax
    xor rax, rax        ; unknown builtin - return 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L220
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_222
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_222
.recursion_limit_222:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_222:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    neg rax             ; unary minus
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L223
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L224
.L223:
.L224:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_225
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call skip_whitespace
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_225
.recursion_limit_225:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_225:
    mov [rbp - 16], rax  ; assign idx
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_226
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call char_at
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_226
.recursion_limit_226:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_226:
    mov [rbp - 24], rax  ; assign ch
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR229]
section .data
.STR229: db 0x2c, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L227
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_230       ; jump if overflow flag set
    jmp .overflow_done_231
.overflow_230:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_231:
    mov [rbp - 16], rax  ; assign idx
    jmp .L228
.L227:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR234]
section .data
.STR234: db 0x5d, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L232
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_235       ; jump if overflow flag set
    jmp .overflow_done_236
.overflow_235:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_236:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L233
.L232:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L233:
.L228:
.L221:
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_237       ; jump if overflow flag set
    jmp .overflow_done_238
.overflow_237:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_238:
    mov [rbp - 16], rax  ; assign idx
    jmp .L219
.L220:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L208
.L207:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR241]
section .data
.STR241: db 0x74, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L239
    ; Builtin function @strcmp
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load s
    push rax            ; save str
    mov rax, 4
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, [rbp - 16]  ; load idx
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    mov rdi, rax        ; str1
    lea rax, [rel .STR244]
section .data
.STR244: db 0x74, 0x72, 0x75, 0x65, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L242
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 4
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_245       ; jump if overflow flag set
    jmp .overflow_done_246
.overflow_245:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_246:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L243
.L242:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L243:
    jmp .L240
.L239:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR249]
section .data
.STR249: db 0x66, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L247
    ; Builtin function @strcmp
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load s
    push rax            ; save str
    mov rax, 5
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, [rbp - 16]  ; load idx
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    mov rdi, rax        ; str1
    lea rax, [rel .STR252]
section .data
.STR252: db 0x66, 0x61, 0x6c, 0x73, 0x65, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L250
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 5
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_253       ; jump if overflow flag set
    jmp .overflow_done_254
.overflow_253:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_254:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L251
.L250:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L251:
    jmp .L248
.L247:
    ; Builtin function @strcmp
    mov rax, [rbp - 24]  ; load ch
    mov rdi, rax        ; str1
    lea rax, [rel .STR257]
section .data
.STR257: db 0x6e, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L255
    ; Builtin function @strcmp
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load s
    push rax            ; save str
    mov rax, 4
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, [rbp - 16]  ; load idx
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    mov rdi, rax        ; str1
    lea rax, [rel .STR260]
section .data
.STR260: db 0x6e, 0x75, 0x6c, 0x6c, 0x00
section .text
    mov rsi, rax        ; str2
    call strcmp
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L258
    mov rax, [rbp - 16]  ; load idx
    push rax
    mov rax, 4
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_261       ; jump if overflow flag set
    jmp .overflow_done_262
.overflow_261:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_262:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L259
.L258:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L259:
    jmp .L256
.L255:
    mov rax, [rbp - 8]  ; load s
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load idx
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_263
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_number
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_263
.recursion_limit_263:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_263:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L256:
.L248:
.L240:
.L208:
.L161:
.L157:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_264
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_264:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_265
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_265:
    lea rax, [rel .STR266]
section .data
.STR266: db 0x0a, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L267:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L269
    cmp byte [rsi], 0
    je .L268
    inc rdx
    inc rsi
    jmp .L267
.L269:
    mov rdx, 0          ; truncate to 0 on overflow
.L268:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR270]
section .data
.STR270: db 0x20, 0x20, 0x20, 0x20, 0x20, 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x20, 0x4a, 0x53, 0x4f, 0x4e, 0x20, 0x56, 0x61, 0x6c, 0x69, 0x64, 0x61, 0x74, 0x6f, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L271:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L273
    cmp byte [rsi], 0
    je .L272
    inc rdx
    inc rsi
    jmp .L271
.L273:
    mov rdx, 0          ; truncate to 0 on overflow
.L272:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR274]
section .data
.STR274: db 0x20, 0x20, 0x20, 0x20, 0x20, 0x4c, 0x69, 0x67, 0x68, 0x74, 0x77, 0x65, 0x69, 0x67, 0x68, 0x74, 0x20, 0x4a, 0x53, 0x4f, 0x4e, 0x20, 0x53, 0x74, 0x72, 0x75, 0x63, 0x74, 0x75, 0x72, 0x65, 0x20, 0x56, 0x61, 0x6c, 0x69, 0x64, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L275:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L277
    cmp byte [rsi], 0
    je .L276
    inc rdx
    inc rsi
    jmp .L275
.L277:
    mov rdx, 0          ; truncate to 0 on overflow
.L276:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR278]
section .data
.STR278: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L279:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L281
    cmp byte [rsi], 0
    je .L280
    inc rdx
    inc rsi
    jmp .L279
.L281:
    mov rdx, 0          ; truncate to 0 on overflow
.L280:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR282]
section .data
.STR282: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x3a, 0x20, 0x53, 0x69, 0x6d, 0x70, 0x6c, 0x65, 0x20, 0x73, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L283:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L285
    cmp byte [rsi], 0
    je .L284
    inc rdx
    inc rsi
    jmp .L283
.L285:
    mov rdx, 0          ; truncate to 0 on overflow
.L284:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR286]
section .data
.STR286: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x22, 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L287:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L289
    cmp byte [rsi], 0
    je .L288
    inc rdx
    inc rsi
    jmp .L287
.L289:
    mov rdx, 0          ; truncate to 0 on overflow
.L288:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR291]
section .data
.STR291: db 0x22, 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x22, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_290
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_290
.recursion_limit_290:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_290:
    push rax            ; var result
    lea rax, [rel .STR292]
section .data
.STR292: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L293:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L295
    cmp byte [rsi], 0
    je .L294
    inc rdx
    inc rsi
    jmp .L293
.L295:
    mov rdx, 0          ; truncate to 0 on overflow
.L294:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L296
    lea rax, [rel .STR298]
section .data
.STR298: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L299:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L301
    cmp byte [rsi], 0
    je .L300
    inc rdx
    inc rsi
    jmp .L299
.L301:
    mov rdx, 0          ; truncate to 0 on overflow
.L300:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L297
.L296:
    lea rax, [rel .STR302]
section .data
.STR302: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L303:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L305
    cmp byte [rsi], 0
    je .L304
    inc rdx
    inc rsi
    jmp .L303
.L305:
    mov rdx, 0          ; truncate to 0 on overflow
.L304:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L297:
    lea rax, [rel .STR306]
section .data
.STR306: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x32, 0x3a, 0x20, 0x4e, 0x75, 0x6d, 0x62, 0x65, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L307:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L309
    cmp byte [rsi], 0
    je .L308
    inc rdx
    inc rsi
    jmp .L307
.L309:
    mov rdx, 0          ; truncate to 0 on overflow
.L308:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR310]
section .data
.STR310: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x34, 0x32, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L311:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L313
    cmp byte [rsi], 0
    je .L312
    inc rdx
    inc rsi
    jmp .L311
.L313:
    mov rdx, 0          ; truncate to 0 on overflow
.L312:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR315]
section .data
.STR315: db 0x34, 0x32, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_314
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_314
.recursion_limit_314:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_314:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR316]
section .data
.STR316: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L317:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L319
    cmp byte [rsi], 0
    je .L318
    inc rdx
    inc rsi
    jmp .L317
.L319:
    mov rdx, 0          ; truncate to 0 on overflow
.L318:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L320
    lea rax, [rel .STR322]
section .data
.STR322: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L323:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L325
    cmp byte [rsi], 0
    je .L324
    inc rdx
    inc rsi
    jmp .L323
.L325:
    mov rdx, 0          ; truncate to 0 on overflow
.L324:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L321
.L320:
    lea rax, [rel .STR326]
section .data
.STR326: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L327:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L329
    cmp byte [rsi], 0
    je .L328
    inc rdx
    inc rsi
    jmp .L327
.L329:
    mov rdx, 0          ; truncate to 0 on overflow
.L328:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L321:
    lea rax, [rel .STR330]
section .data
.STR330: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x33, 0x3a, 0x20, 0x4e, 0x65, 0x67, 0x61, 0x74, 0x69, 0x76, 0x65, 0x20, 0x64, 0x65, 0x63, 0x69, 0x6d, 0x61, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L331:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L333
    cmp byte [rsi], 0
    je .L332
    inc rdx
    inc rsi
    jmp .L331
.L333:
    mov rdx, 0          ; truncate to 0 on overflow
.L332:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR334]
section .data
.STR334: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x2d, 0x33, 0x2e, 0x31, 0x34, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L335:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L337
    cmp byte [rsi], 0
    je .L336
    inc rdx
    inc rsi
    jmp .L335
.L337:
    mov rdx, 0          ; truncate to 0 on overflow
.L336:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR339]
section .data
.STR339: db 0x2d, 0x33, 0x2e, 0x31, 0x34, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_338
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_338
.recursion_limit_338:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_338:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR340]
section .data
.STR340: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L341:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L343
    cmp byte [rsi], 0
    je .L342
    inc rdx
    inc rsi
    jmp .L341
.L343:
    mov rdx, 0          ; truncate to 0 on overflow
.L342:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L344
    lea rax, [rel .STR346]
section .data
.STR346: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L347:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L349
    cmp byte [rsi], 0
    je .L348
    inc rdx
    inc rsi
    jmp .L347
.L349:
    mov rdx, 0          ; truncate to 0 on overflow
.L348:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L345
.L344:
    lea rax, [rel .STR350]
section .data
.STR350: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L351:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L353
    cmp byte [rsi], 0
    je .L352
    inc rdx
    inc rsi
    jmp .L351
.L353:
    mov rdx, 0          ; truncate to 0 on overflow
.L352:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L345:
    lea rax, [rel .STR354]
section .data
.STR354: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x34, 0x3a, 0x20, 0x42, 0x6f, 0x6f, 0x6c, 0x65, 0x61, 0x6e, 0x20, 0x74, 0x72, 0x75, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L355:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L357
    cmp byte [rsi], 0
    je .L356
    inc rdx
    inc rsi
    jmp .L355
.L357:
    mov rdx, 0          ; truncate to 0 on overflow
.L356:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR358]
section .data
.STR358: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x74, 0x72, 0x75, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L359:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L361
    cmp byte [rsi], 0
    je .L360
    inc rdx
    inc rsi
    jmp .L359
.L361:
    mov rdx, 0          ; truncate to 0 on overflow
.L360:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR363]
section .data
.STR363: db 0x74, 0x72, 0x75, 0x65, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_362
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_362
.recursion_limit_362:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_362:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR364]
section .data
.STR364: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L365:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L367
    cmp byte [rsi], 0
    je .L366
    inc rdx
    inc rsi
    jmp .L365
.L367:
    mov rdx, 0          ; truncate to 0 on overflow
.L366:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L368
    lea rax, [rel .STR370]
section .data
.STR370: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L371:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L373
    cmp byte [rsi], 0
    je .L372
    inc rdx
    inc rsi
    jmp .L371
.L373:
    mov rdx, 0          ; truncate to 0 on overflow
.L372:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L369
.L368:
    lea rax, [rel .STR374]
section .data
.STR374: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L375:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L377
    cmp byte [rsi], 0
    je .L376
    inc rdx
    inc rsi
    jmp .L375
.L377:
    mov rdx, 0          ; truncate to 0 on overflow
.L376:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L369:
    lea rax, [rel .STR378]
section .data
.STR378: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x35, 0x3a, 0x20, 0x42, 0x6f, 0x6f, 0x6c, 0x65, 0x61, 0x6e, 0x20, 0x66, 0x61, 0x6c, 0x73, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L379:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L381
    cmp byte [rsi], 0
    je .L380
    inc rdx
    inc rsi
    jmp .L379
.L381:
    mov rdx, 0          ; truncate to 0 on overflow
.L380:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR382]
section .data
.STR382: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x66, 0x61, 0x6c, 0x73, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L383:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L385
    cmp byte [rsi], 0
    je .L384
    inc rdx
    inc rsi
    jmp .L383
.L385:
    mov rdx, 0          ; truncate to 0 on overflow
.L384:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR387]
section .data
.STR387: db 0x66, 0x61, 0x6c, 0x73, 0x65, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_386
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_386
.recursion_limit_386:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_386:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR388]
section .data
.STR388: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L389:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L391
    cmp byte [rsi], 0
    je .L390
    inc rdx
    inc rsi
    jmp .L389
.L391:
    mov rdx, 0          ; truncate to 0 on overflow
.L390:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L392
    lea rax, [rel .STR394]
section .data
.STR394: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L395:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L397
    cmp byte [rsi], 0
    je .L396
    inc rdx
    inc rsi
    jmp .L395
.L397:
    mov rdx, 0          ; truncate to 0 on overflow
.L396:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L393
.L392:
    lea rax, [rel .STR398]
section .data
.STR398: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L399:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L401
    cmp byte [rsi], 0
    je .L400
    inc rdx
    inc rsi
    jmp .L399
.L401:
    mov rdx, 0          ; truncate to 0 on overflow
.L400:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L393:
    lea rax, [rel .STR402]
section .data
.STR402: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x36, 0x3a, 0x20, 0x4e, 0x75, 0x6c, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L403:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L405
    cmp byte [rsi], 0
    je .L404
    inc rdx
    inc rsi
    jmp .L403
.L405:
    mov rdx, 0          ; truncate to 0 on overflow
.L404:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR406]
section .data
.STR406: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x6e, 0x75, 0x6c, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L407:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L409
    cmp byte [rsi], 0
    je .L408
    inc rdx
    inc rsi
    jmp .L407
.L409:
    mov rdx, 0          ; truncate to 0 on overflow
.L408:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR411]
section .data
.STR411: db 0x6e, 0x75, 0x6c, 0x6c, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_410
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_410
.recursion_limit_410:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_410:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR412]
section .data
.STR412: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L413:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L415
    cmp byte [rsi], 0
    je .L414
    inc rdx
    inc rsi
    jmp .L413
.L415:
    mov rdx, 0          ; truncate to 0 on overflow
.L414:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L416
    lea rax, [rel .STR418]
section .data
.STR418: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L419:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L421
    cmp byte [rsi], 0
    je .L420
    inc rdx
    inc rsi
    jmp .L419
.L421:
    mov rdx, 0          ; truncate to 0 on overflow
.L420:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L417
.L416:
    lea rax, [rel .STR422]
section .data
.STR422: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L423:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L425
    cmp byte [rsi], 0
    je .L424
    inc rdx
    inc rsi
    jmp .L423
.L425:
    mov rdx, 0          ; truncate to 0 on overflow
.L424:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L417:
    lea rax, [rel .STR426]
section .data
.STR426: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x37, 0x3a, 0x20, 0x45, 0x6d, 0x70, 0x74, 0x79, 0x20, 0x61, 0x72, 0x72, 0x61, 0x79, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L427:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L429
    cmp byte [rsi], 0
    je .L428
    inc rdx
    inc rsi
    jmp .L427
.L429:
    mov rdx, 0          ; truncate to 0 on overflow
.L428:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR430]
section .data
.STR430: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x5b, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L431:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L433
    cmp byte [rsi], 0
    je .L432
    inc rdx
    inc rsi
    jmp .L431
.L433:
    mov rdx, 0          ; truncate to 0 on overflow
.L432:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR435]
section .data
.STR435: db 0x5b, 0x5d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_434
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_434
.recursion_limit_434:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_434:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR436]
section .data
.STR436: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L437:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L439
    cmp byte [rsi], 0
    je .L438
    inc rdx
    inc rsi
    jmp .L437
.L439:
    mov rdx, 0          ; truncate to 0 on overflow
.L438:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L440
    lea rax, [rel .STR442]
section .data
.STR442: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L443:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L445
    cmp byte [rsi], 0
    je .L444
    inc rdx
    inc rsi
    jmp .L443
.L445:
    mov rdx, 0          ; truncate to 0 on overflow
.L444:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L441
.L440:
    lea rax, [rel .STR446]
section .data
.STR446: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L447:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L449
    cmp byte [rsi], 0
    je .L448
    inc rdx
    inc rsi
    jmp .L447
.L449:
    mov rdx, 0          ; truncate to 0 on overflow
.L448:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L441:
    lea rax, [rel .STR450]
section .data
.STR450: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x38, 0x3a, 0x20, 0x41, 0x72, 0x72, 0x61, 0x79, 0x20, 0x77, 0x69, 0x74, 0x68, 0x20, 0x6e, 0x75, 0x6d, 0x62, 0x65, 0x72, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L451:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L453
    cmp byte [rsi], 0
    je .L452
    inc rdx
    inc rsi
    jmp .L451
.L453:
    mov rdx, 0          ; truncate to 0 on overflow
.L452:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR454]
section .data
.STR454: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x5b, 0x31, 0x2c, 0x20, 0x32, 0x2c, 0x20, 0x33, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L455:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L457
    cmp byte [rsi], 0
    je .L456
    inc rdx
    inc rsi
    jmp .L455
.L457:
    mov rdx, 0          ; truncate to 0 on overflow
.L456:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR459]
section .data
.STR459: db 0x5b, 0x31, 0x2c, 0x20, 0x32, 0x2c, 0x20, 0x33, 0x5d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_458
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_458
.recursion_limit_458:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_458:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR460]
section .data
.STR460: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L461:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L463
    cmp byte [rsi], 0
    je .L462
    inc rdx
    inc rsi
    jmp .L461
.L463:
    mov rdx, 0          ; truncate to 0 on overflow
.L462:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L464
    lea rax, [rel .STR466]
section .data
.STR466: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L467:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L469
    cmp byte [rsi], 0
    je .L468
    inc rdx
    inc rsi
    jmp .L467
.L469:
    mov rdx, 0          ; truncate to 0 on overflow
.L468:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L465
.L464:
    lea rax, [rel .STR470]
section .data
.STR470: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L471:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L473
    cmp byte [rsi], 0
    je .L472
    inc rdx
    inc rsi
    jmp .L471
.L473:
    mov rdx, 0          ; truncate to 0 on overflow
.L472:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L465:
    lea rax, [rel .STR474]
section .data
.STR474: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x39, 0x3a, 0x20, 0x45, 0x6d, 0x70, 0x74, 0x79, 0x20, 0x6f, 0x62, 0x6a, 0x65, 0x63, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L475:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L477
    cmp byte [rsi], 0
    je .L476
    inc rdx
    inc rsi
    jmp .L475
.L477:
    mov rdx, 0          ; truncate to 0 on overflow
.L476:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR478]
section .data
.STR478: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x7b, 0x7d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L479:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L481
    cmp byte [rsi], 0
    je .L480
    inc rdx
    inc rsi
    jmp .L479
.L481:
    mov rdx, 0          ; truncate to 0 on overflow
.L480:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR483]
section .data
.STR483: db 0x7b, 0x7d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_482
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_482
.recursion_limit_482:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_482:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR484]
section .data
.STR484: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L485:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L487
    cmp byte [rsi], 0
    je .L486
    inc rdx
    inc rsi
    jmp .L485
.L487:
    mov rdx, 0          ; truncate to 0 on overflow
.L486:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L488
    lea rax, [rel .STR490]
section .data
.STR490: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L491:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L493
    cmp byte [rsi], 0
    je .L492
    inc rdx
    inc rsi
    jmp .L491
.L493:
    mov rdx, 0          ; truncate to 0 on overflow
.L492:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L489
.L488:
    lea rax, [rel .STR494]
section .data
.STR494: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L495:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L497
    cmp byte [rsi], 0
    je .L496
    inc rdx
    inc rsi
    jmp .L495
.L497:
    mov rdx, 0          ; truncate to 0 on overflow
.L496:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L489:
    lea rax, [rel .STR498]
section .data
.STR498: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x30, 0x3a, 0x20, 0x53, 0x69, 0x6d, 0x70, 0x6c, 0x65, 0x20, 0x6f, 0x62, 0x6a, 0x65, 0x63, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L499:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L501
    cmp byte [rsi], 0
    je .L500
    inc rdx
    inc rsi
    jmp .L499
.L501:
    mov rdx, 0          ; truncate to 0 on overflow
.L500:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR502]
section .data
.STR502: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x7b, 0x22, 0x6e, 0x61, 0x6d, 0x65, 0x22, 0x3a, 0x22, 0x54, 0x65, 0x73, 0x74, 0x22, 0x7d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L503:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L505
    cmp byte [rsi], 0
    je .L504
    inc rdx
    inc rsi
    jmp .L503
.L505:
    mov rdx, 0          ; truncate to 0 on overflow
.L504:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR507]
section .data
.STR507: db 0x7b, 0x22, 0x6e, 0x61, 0x6d, 0x65, 0x22, 0x3a, 0x22, 0x54, 0x65, 0x73, 0x74, 0x22, 0x7d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_506
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_506
.recursion_limit_506:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_506:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR508]
section .data
.STR508: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L509:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L511
    cmp byte [rsi], 0
    je .L510
    inc rdx
    inc rsi
    jmp .L509
.L511:
    mov rdx, 0          ; truncate to 0 on overflow
.L510:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L512
    lea rax, [rel .STR514]
section .data
.STR514: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L515:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L517
    cmp byte [rsi], 0
    je .L516
    inc rdx
    inc rsi
    jmp .L515
.L517:
    mov rdx, 0          ; truncate to 0 on overflow
.L516:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L513
.L512:
    lea rax, [rel .STR518]
section .data
.STR518: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L519:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L521
    cmp byte [rsi], 0
    je .L520
    inc rdx
    inc rsi
    jmp .L519
.L521:
    mov rdx, 0          ; truncate to 0 on overflow
.L520:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L513:
    lea rax, [rel .STR522]
section .data
.STR522: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x31, 0x3a, 0x20, 0x4e, 0x65, 0x73, 0x74, 0x65, 0x64, 0x20, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x75, 0x72, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L523:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L525
    cmp byte [rsi], 0
    je .L524
    inc rdx
    inc rsi
    jmp .L523
.L525:
    mov rdx, 0          ; truncate to 0 on overflow
.L524:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR526]
section .data
.STR526: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x7b, 0x22, 0x69, 0x74, 0x65, 0x6d, 0x73, 0x22, 0x3a, 0x5b, 0x31, 0x2c, 0x32, 0x2c, 0x33, 0x5d, 0x7d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L527:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L529
    cmp byte [rsi], 0
    je .L528
    inc rdx
    inc rsi
    jmp .L527
.L529:
    mov rdx, 0          ; truncate to 0 on overflow
.L528:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR531]
section .data
.STR531: db 0x7b, 0x22, 0x69, 0x74, 0x65, 0x6d, 0x73, 0x22, 0x3a, 0x5b, 0x31, 0x2c, 0x32, 0x2c, 0x33, 0x5d, 0x7d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_530
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_530
.recursion_limit_530:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_530:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR532]
section .data
.STR532: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L533:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L535
    cmp byte [rsi], 0
    je .L534
    inc rdx
    inc rsi
    jmp .L533
.L535:
    mov rdx, 0          ; truncate to 0 on overflow
.L534:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L536
    lea rax, [rel .STR538]
section .data
.STR538: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L539:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L541
    cmp byte [rsi], 0
    je .L540
    inc rdx
    inc rsi
    jmp .L539
.L541:
    mov rdx, 0          ; truncate to 0 on overflow
.L540:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L537
.L536:
    lea rax, [rel .STR542]
section .data
.STR542: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L543:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L545
    cmp byte [rsi], 0
    je .L544
    inc rdx
    inc rsi
    jmp .L543
.L545:
    mov rdx, 0          ; truncate to 0 on overflow
.L544:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L537:
    lea rax, [rel .STR546]
section .data
.STR546: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x32, 0x3a, 0x20, 0x53, 0x63, 0x69, 0x65, 0x6e, 0x74, 0x69, 0x66, 0x69, 0x63, 0x20, 0x6e, 0x6f, 0x74, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L547:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L549
    cmp byte [rsi], 0
    je .L548
    inc rdx
    inc rsi
    jmp .L547
.L549:
    mov rdx, 0          ; truncate to 0 on overflow
.L548:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR550]
section .data
.STR550: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x31, 0x2e, 0x35, 0x65, 0x31, 0x30, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L551:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L553
    cmp byte [rsi], 0
    je .L552
    inc rdx
    inc rsi
    jmp .L551
.L553:
    mov rdx, 0          ; truncate to 0 on overflow
.L552:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR555]
section .data
.STR555: db 0x31, 0x2e, 0x35, 0x65, 0x31, 0x30, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_554
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_554
.recursion_limit_554:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_554:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR556]
section .data
.STR556: db 0x53, 0x74, 0x61, 0x74, 0x75, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L557:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L559
    cmp byte [rsi], 0
    je .L558
    inc rdx
    inc rsi
    jmp .L557
.L559:
    mov rdx, 0          ; truncate to 0 on overflow
.L558:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L560
    lea rax, [rel .STR562]
section .data
.STR562: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L563:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L565
    cmp byte [rsi], 0
    je .L564
    inc rdx
    inc rsi
    jmp .L563
.L565:
    mov rdx, 0          ; truncate to 0 on overflow
.L564:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L561
.L560:
    lea rax, [rel .STR566]
section .data
.STR566: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L567:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L569
    cmp byte [rsi], 0
    je .L568
    inc rdx
    inc rsi
    jmp .L567
.L569:
    mov rdx, 0          ; truncate to 0 on overflow
.L568:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L561:
    lea rax, [rel .STR570]
section .data
.STR570: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x33, 0x3a, 0x20, 0x49, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x2d, 0x20, 0x65, 0x78, 0x74, 0x72, 0x61, 0x20, 0x61, 0x66, 0x74, 0x65, 0x72, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L571:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L573
    cmp byte [rsi], 0
    je .L572
    inc rdx
    inc rsi
    jmp .L571
.L573:
    mov rdx, 0          ; truncate to 0 on overflow
.L572:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR574]
section .data
.STR574: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x31, 0x32, 0x33, 0x20, 0x34, 0x35, 0x36, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L575:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L577
    cmp byte [rsi], 0
    je .L576
    inc rdx
    inc rsi
    jmp .L575
.L577:
    mov rdx, 0          ; truncate to 0 on overflow
.L576:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR579]
section .data
.STR579: db 0x31, 0x32, 0x33, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_578
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_578
.recursion_limit_578:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_578:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR580]
section .data
.STR580: db 0x56, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x70, 0x61, 0x72, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L581:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L583
    cmp byte [rsi], 0
    je .L582
    inc rdx
    inc rsi
    jmp .L581
.L583:
    mov rdx, 0          ; truncate to 0 on overflow
.L582:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L584
    lea rax, [rel .STR586]
section .data
.STR586: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x2c, 0x20, 0x50, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L587:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L589
    cmp byte [rsi], 0
    je .L588
    inc rdx
    inc rsi
    jmp .L587
.L589:
    mov rdx, 0          ; truncate to 0 on overflow
.L588:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR590]
section .data
.STR590: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L591:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L593
    cmp byte [rsi], 0
    je .L592
    inc rdx
    inc rsi
    jmp .L591
.L593:
    mov rdx, 0          ; truncate to 0 on overflow
.L592:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L585
.L584:
    lea rax, [rel .STR594]
section .data
.STR594: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L595:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L597
    cmp byte [rsi], 0
    je .L596
    inc rdx
    inc rsi
    jmp .L595
.L597:
    mov rdx, 0          ; truncate to 0 on overflow
.L596:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L585:
    lea rax, [rel .STR598]
section .data
.STR598: db 0x0a, 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x34, 0x3a, 0x20, 0x43, 0x6f, 0x6d, 0x70, 0x6c, 0x65, 0x78, 0x20, 0x61, 0x72, 0x72, 0x61, 0x79, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L599:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L601
    cmp byte [rsi], 0
    je .L600
    inc rdx
    inc rsi
    jmp .L599
.L601:
    mov rdx, 0          ; truncate to 0 on overflow
.L600:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR602]
section .data
.STR602: db 0x49, 0x6e, 0x70, 0x75, 0x74, 0x3a, 0x20, 0x5b, 0x7b, 0x22, 0x69, 0x64, 0x22, 0x3a, 0x31, 0x7d, 0x2c, 0x7b, 0x22, 0x69, 0x64, 0x22, 0x3a, 0x32, 0x7d, 0x5d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L603:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L605
    cmp byte [rsi], 0
    je .L604
    inc rdx
    inc rsi
    jmp .L603
.L605:
    mov rdx, 0          ; truncate to 0 on overflow
.L604:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR607]
section .data
.STR607: db 0x7b, 0x22, 0x69, 0x64, 0x22, 0x3a, 0x31, 0x7d, 0x00
section .text
    push rax            ; save arg 0
    mov rax, 0
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_606
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call validate_value
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_606
.recursion_limit_606:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_606:
    mov [rbp - 8], rax  ; assign result
    lea rax, [rel .STR608]
section .data
.STR608: db 0x4f, 0x62, 0x6a, 0x65, 0x63, 0x74, 0x20, 0x70, 0x61, 0x72, 0x73, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L609:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L611
    cmp byte [rsi], 0
    je .L610
    inc rdx
    inc rsi
    jmp .L609
.L611:
    mov rdx, 0          ; truncate to 0 on overflow
.L610:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load result
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L612
    lea rax, [rel .STR614]
section .data
.STR614: db 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L615:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L617
    cmp byte [rsi], 0
    je .L616
    inc rdx
    inc rsi
    jmp .L615
.L617:
    mov rdx, 0          ; truncate to 0 on overflow
.L616:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L613
.L612:
    lea rax, [rel .STR618]
section .data
.STR618: db 0x46, 0x41, 0x49, 0x4c, 0x45, 0x44, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L619:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L621
    cmp byte [rsi], 0
    je .L620
    inc rdx
    inc rsi
    jmp .L619
.L621:
    mov rdx, 0          ; truncate to 0 on overflow
.L620:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L613:
    lea rax, [rel .STR622]
section .data
.STR622: db 0x0a, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L623:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L625
    cmp byte [rsi], 0
    je .L624
    inc rdx
    inc rsi
    jmp .L623
.L625:
    mov rdx, 0          ; truncate to 0 on overflow
.L624:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR626]
section .data
.STR626: db 0x20, 0x20, 0x20, 0x20, 0x20, 0x54, 0x65, 0x73, 0x74, 0x73, 0x20, 0x43, 0x6f, 0x6d, 0x70, 0x6c, 0x65, 0x74, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L627:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L629
    cmp byte [rsi], 0
    je .L628
    inc rdx
    inc rsi
    jmp .L627
.L629:
    mov rdx, 0          ; truncate to 0 on overflow
.L628:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR630]
section .data
.STR630: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L631:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L633
    cmp byte [rsi], 0
    je .L632
    inc rdx
    inc rsi
    jmp .L631
.L633:
    mov rdx, 0          ; truncate to 0 on overflow
.L632:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
