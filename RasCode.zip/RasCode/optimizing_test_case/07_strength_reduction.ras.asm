global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



scale_multiply:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov rax, 0
    push rax            ; var i
.L2:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L3
    mov rax, [rbp - 16]  ; load i
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_4
    cmp rax, 50
    jge .bounds_error_4
    mov rax, [rbp - 16]  ; load i
    cmp rax, 0
    jl .bounds_error_5
    cmp rax, 50
    jge .bounds_error_5
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_6
.bounds_error_5:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_6:
    push rax
    mov rax, 8
    mov rbx, rax
    pop rax
    imul rax, rbx
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 8         ; element size
    imul rax, rcx       ; index * size
    mov rcx, [rbp - 8] ; load array pointer (parameter)
    add rcx, rax        ; element address
    mov qword [rcx], rbx ; store qword
    jmp .bounds_ok_5
.bounds_error_4:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_5:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign i
    jmp .L2
.L3:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

scale_shift:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_6
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_6:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_7
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_7:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov rax, 0
    push rax            ; var i
.L8:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L9
    mov rax, [rbp - 16]  ; load i
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_10
    cmp rax, 50
    jge .bounds_error_10
    mov rax, [rbp - 16]  ; load i
    cmp rax, 0
    jl .bounds_error_11
    cmp rax, 50
    jge .bounds_error_11
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_12
.bounds_error_11:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_12:
    push rax
    mov rax, 3
    mov rbx, rax
    pop rax
    mov rcx, rbx
    shl rax, cl
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 8         ; element size
    imul rax, rcx       ; index * size
    mov rcx, [rbp - 8] ; load array pointer (parameter)
    add rcx, rax        ; element address
    mov qword [rcx], rbx ; store qword
    jmp .bounds_ok_11
.bounds_error_10:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_11:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign i
    jmp .L8
.L9:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

init_array:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_12
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_12:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_13
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_13:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov rax, 0
    push rax            ; var i
.L14:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L15
    mov rax, [rbp - 16]  ; load i
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_16
    cmp rax, 50
    jge .bounds_error_16
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 8         ; element size
    imul rax, rcx       ; index * size
    mov rcx, [rbp - 8] ; load array pointer (parameter)
    add rcx, rax        ; element address
    mov qword [rcx], rbx ; store qword
    jmp .bounds_ok_17
.bounds_error_16:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_17:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign i
    jmp .L14
.L15:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

verify_arrays:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_17
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_17:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_18
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_18:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter arr_mult
    mov [rbp-16], rsi     ; parameter arr_shift
    mov rax, 0
    push rax            ; var i
.L19:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L20
    mov rax, [rbp - 24]  ; load i
    cmp rax, 0
    jl .bounds_error_23
    cmp rax, 50
    jge .bounds_error_23
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_24
.bounds_error_23:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_24:
    push rax
    mov rax, [rbp - 24]  ; load i
    cmp rax, 0
    jl .bounds_error_24
    cmp rax, 50
    jge .bounds_error_24
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 16] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_25
.bounds_error_24:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_25:
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L21
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L22
.L21:
.L22:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    jmp .L19
.L20:
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_25
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_25:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_26
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_26:
    lea rax, [rel .STR27]
section .data
.STR27: db 0x54, 0x45, 0x53, 0x54, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x20, 0x52, 0x65, 0x64, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x28, 0x4d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x20, 0x76, 0x73, 0x20, 0x53, 0x68, 0x69, 0x66, 0x74, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L28:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L30
    cmp byte [rsi], 0
    je .L29
    inc rdx
    inc rsi
    jmp .L28
.L30:
    mov rdx, 0          ; truncate to 0 on overflow
.L29:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR31]
section .data
.STR31: db 0x4d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x20, 0x62, 0x79, 0x20, 0x38, 0x3a, 0x20, 0x27, 0x78, 0x20, 0x2a, 0x20, 0x38, 0x27, 0x20, 0x76, 0x73, 0x20, 0x27, 0x78, 0x20, 0x3c, 0x3c, 0x20, 0x33, 0x27, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; array declaration: arr_mult{int, 50} (element_size=4 bytes)
    sub rsp, 200         ; allocate array space
    ; array declaration: arr_shift{int, 50} (element_size=4 bytes)
    sub rsp, 200         ; allocate array space
    mov rax, [rbp - 200]  ; load arr_mult
    push rax            ; save arg 0
    pop rdi              ; load arg 0
    call init_array
    mov rax, [rbp - 400]  ; load arr_shift
    push rax            ; save arg 0
    pop rdi              ; load arg 0
    call init_array
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_mult
    mov rax, [rbp - 200]  ; load arr_mult
    push rax            ; save arg 0
    pop rdi              ; load arg 0
    call scale_multiply
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_mult
    mov rax, [rbp - 416]  ; load end_mult
    push rax
    mov rax, [rbp - 408]  ; load start_mult
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_mult
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_shift
    mov rax, [rbp - 400]  ; load arr_shift
    push rax            ; save arg 0
    pop rdi              ; load arg 0
    call scale_shift
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_shift
    mov rax, [rbp - 440]  ; load end_shift
    push rax
    mov rax, [rbp - 432]  ; load start_shift
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_shift
    lea rax, [rel .STR35]
section .data
.STR35: db 0x4d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 424]  ; load time_mult
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR39]
section .data
.STR39: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L40:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L42
    cmp byte [rsi], 0
    je .L41
    inc rdx
    inc rsi
    jmp .L40
.L42:
    mov rdx, 0          ; truncate to 0 on overflow
.L41:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR43]
section .data
.STR43: db 0x4d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x20, 0x62, 0x79, 0x20, 0x38, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    cmp rax, 0
    jl .bounds_error_47
    cmp rax, 50
    jge .bounds_error_47
    mov rbx, 4         ; element size
    imul rax, rbx       ; index * size
    lea rbx, [rbp - 200] ; array base (first element)
    add rbx, rax        ; element address
    mov eax, dword [rbx] ; load dword
    cdqe                 ; sign extend to 64-bit
    jmp .bounds_ok_48
.bounds_error_47:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_48:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR48]
section .data
.STR48: db 0x20, 0x28, 0x31, 0x20, 0x2a, 0x20, 0x38, 0x29, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L49:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L51
    cmp byte [rsi], 0
    je .L50
    inc rdx
    inc rsi
    jmp .L49
.L51:
    mov rdx, 0          ; truncate to 0 on overflow
.L50:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR52]
section .data
.STR52: db 0x53, 0x68, 0x69, 0x66, 0x74, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L53:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L55
    cmp byte [rsi], 0
    je .L54
    inc rdx
    inc rsi
    jmp .L53
.L55:
    mov rdx, 0          ; truncate to 0 on overflow
.L54:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 448]  ; load time_shift
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR56]
section .data
.STR56: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR60]
section .data
.STR60: db 0x53, 0x68, 0x69, 0x66, 0x74, 0x20, 0x6c, 0x65, 0x66, 0x74, 0x20, 0x33, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    cmp rax, 0
    jl .bounds_error_64
    cmp rax, 50
    jge .bounds_error_64
    mov rbx, 4         ; element size
    imul rax, rbx       ; index * size
    lea rbx, [rbp - 400] ; array base (first element)
    add rbx, rax        ; element address
    mov eax, dword [rbx] ; load dword
    cdqe                 ; sign extend to 64-bit
    jmp .bounds_ok_65
.bounds_error_64:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_65:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR65]
section .data
.STR65: db 0x20, 0x28, 0x31, 0x20, 0x3c, 0x3c, 0x20, 0x33, 0x29, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L66:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L68
    cmp byte [rsi], 0
    je .L67
    inc rdx
    inc rsi
    jmp .L66
.L68:
    mov rdx, 0          ; truncate to 0 on overflow
.L67:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 200]  ; load arr_mult
    push rax            ; save arg 0
    mov rax, [rbp - 400]  ; load arr_shift
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_69
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call verify_arrays
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_69
.recursion_limit_69:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_69:
    push rax            ; var arrays_equal
    mov rax, [rbp - 456]  ; load arrays_equal
    cmp rax, 0
    je .L70
    lea rax, [rel .STR72]
section .data
.STR72: db 0xe2, 0x9c, 0x93, 0x20, 0x50, 0x41, 0x53, 0x53, 0x3a, 0x20, 0x42, 0x6f, 0x74, 0x68, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x70, 0x72, 0x6f, 0x64, 0x75, 0x63, 0x65, 0x20, 0x73, 0x61, 0x6d, 0x65, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 448]  ; load time_shift
    push rax
    mov rax, [rbp - 424]  ; load time_mult
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L76
    lea rax, [rel .STR78]
section .data
.STR78: db 0xe2, 0x9c, 0x93, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x56, 0x45, 0x52, 0x49, 0x46, 0x49, 0x45, 0x44, 0x3a, 0x20, 0x53, 0x68, 0x69, 0x66, 0x74, 0x20, 0x66, 0x61, 0x73, 0x74, 0x65, 0x72, 0x20, 0x74, 0x68, 0x61, 0x6e, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L77
.L76:
    lea rax, [rel .STR82]
section .data
.STR82: db 0xe2, 0x9c, 0x97, 0x20, 0x4e, 0x4f, 0x20, 0x43, 0x4c, 0x45, 0x41, 0x52, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x28, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x6f, 0x6f, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L77:
    jmp .L71
.L70:
    lea rax, [rel .STR86]
section .data
.STR86: db 0xe2, 0x9c, 0x97, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x3a, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x70, 0x72, 0x6f, 0x64, 0x75, 0x63, 0x65, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x65, 0x6e, 0x74, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L71:
    add rsp, 456         ; pop 57 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
