global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



extract_substring:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    lea rax, [rel .STR2]
section .data
.STR2: db 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x20, 0x4f, 0x70, 0x74, 0x69, 0x6d, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x00
section .text
    push rax            ; var text
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load text
    push rax            ; save str
    mov rax, 4
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, 4
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var word
    mov rax, [rbp - 16]  ; load word
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 16         ; pop 2 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

build_string:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_3
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_3:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_4
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_4:
    lea rax, [rel .STR5]
section .data
.STR5: db 0x6f, 0x70, 0x74, 0x69, 0x6d, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x00
section .text
    push rax            ; var part1
    lea rax, [rel .STR6]
section .data
.STR6: db 0x74, 0x65, 0x73, 0x74, 0x00
section .text
    push rax            ; var part2
    ; Builtin function @concat
    mov rax, [rbp - 8]  ; load part1
    mov r12, rax        ; r12 = str1
    mov rax, [rbp - 16]  ; load part2
    mov r13, rax        ; r13 = str2
    mov rdi, r12
    call strlen
    mov r14, rax        ; r14 = len1
    mov rdi, r13
    call strlen
    mov r15, rax        ; r15 = len2
    lea rdi, [r14 + r15 + 1]  ; total size
    call malloc
    mov rbx, rax        ; rbx = result buffer
    mov rdi, rbx
    mov rsi, r12
    mov rcx, r14
    rep movsb
    mov rsi, r13
    mov rcx, r15
    rep movsb
    mov byte [rdi], 0
    mov rax, rbx        ; return result
    push rax            ; var combined
    mov rax, [rbp - 24]  ; load combined
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

string_operations:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_7
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_7:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_8
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_8:
    lea rax, [rel .STR9]
section .data
.STR9: db 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x57, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax            ; var original
    ; Builtin function @len
    mov rax, [rbp - 8]  ; load original
    mov rdi, rax
    xor rcx, rcx
.len_loop_10:
    cmp byte [rdi+rcx], 0
    je .len_done_10
    inc rcx
    jmp .len_loop_10
.len_done_10:
    mov rax, rcx
    push rax            ; var len
    lea rax, [rel .STR11]
section .data
.STR11: db 0xe2, 0x86, 0x92, 0x20, 0x00
section .text
    push rax            ; var prefix
    ; Builtin function @concat
    mov rax, [rbp - 24]  ; load prefix
    mov r12, rax        ; r12 = str1
    mov rax, [rbp - 8]  ; load original
    mov r13, rax        ; r13 = str2
    mov rdi, r12
    call strlen
    mov r14, rax        ; r14 = len1
    mov rdi, r13
    call strlen
    mov r15, rax        ; r15 = len2
    lea rdi, [r14 + r15 + 1]  ; total size
    call malloc
    mov rbx, rax        ; rbx = result buffer
    mov rdi, rbx
    mov rsi, r12
    mov rcx, r14
    rep movsb
    mov rsi, r13
    mov rcx, r15
    rep movsb
    mov byte [rdi], 0
    mov rax, rbx        ; return result
    push rax            ; var output
    mov rax, [rbp - 32]  ; load output
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L12:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L14
    cmp byte [rsi], 0
    je .L13
    inc rdx
    inc rsi
    jmp .L12
.L14:
    mov rdx, 0          ; truncate to 0 on overflow
.L13:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR15]
section .data
.STR15: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L16:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L18
    cmp byte [rsi], 0
    je .L17
    inc rdx
    inc rsi
    jmp .L16
.L18:
    mov rdx, 0          ; truncate to 0 on overflow
.L17:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load original
    push rax            ; save str
    mov rax, 5
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, 0
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var hello
    ; Builtin function @substr
    mov rax, [rbp - 8]  ; load original
    push rax            ; save str
    mov rax, 5
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, 6
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var world
    lea rax, [rel .STR19]
section .data
.STR19: db 0x46, 0x69, 0x72, 0x73, 0x74, 0x20, 0x70, 0x61, 0x72, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L20:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L22
    cmp byte [rsi], 0
    je .L21
    inc rdx
    inc rsi
    jmp .L20
.L22:
    mov rdx, 0          ; truncate to 0 on overflow
.L21:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load hello
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L23:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L25
    cmp byte [rsi], 0
    je .L24
    inc rdx
    inc rsi
    jmp .L23
.L25:
    mov rdx, 0          ; truncate to 0 on overflow
.L24:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR26]
section .data
.STR26: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L27:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L29
    cmp byte [rsi], 0
    je .L28
    inc rdx
    inc rsi
    jmp .L27
.L29:
    mov rdx, 0          ; truncate to 0 on overflow
.L28:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR30]
section .data
.STR30: db 0x53, 0x65, 0x63, 0x6f, 0x6e, 0x64, 0x20, 0x70, 0x61, 0x72, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L31:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L33
    cmp byte [rsi], 0
    je .L32
    inc rdx
    inc rsi
    jmp .L31
.L33:
    mov rdx, 0          ; truncate to 0 on overflow
.L32:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load world
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L34:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L36
    cmp byte [rsi], 0
    je .L35
    inc rdx
    inc rsi
    jmp .L34
.L36:
    mov rdx, 0          ; truncate to 0 on overflow
.L35:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR37]
section .data
.STR37: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L38:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L40
    cmp byte [rsi], 0
    je .L39
    inc rdx
    inc rsi
    jmp .L38
.L40:
    mov rdx, 0          ; truncate to 0 on overflow
.L39:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load len
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 48         ; pop 6 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_41
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_41:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_42
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_42:
    lea rax, [rel .STR43]
section .data
.STR43: db 0x3d, 0x3d, 0x3d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x41, 0x52, 0x4f, 0x55, 0x4e, 0x44, 0x20, 0x33, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR47]
section .data
.STR47: db 0x50, 0x52, 0x4f, 0x42, 0x4c, 0x45, 0x4d, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x69, 0x6e, 0x67, 0x20, 0x6e, 0x6f, 0x74, 0x20, 0x61, 0x76, 0x61, 0x69, 0x6c, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x28, 0x73, 0x74, 0x72, 0x7b, 0x69, 0x7d, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR51]
section .data
.STR51: db 0x53, 0x4f, 0x4c, 0x55, 0x54, 0x49, 0x4f, 0x4e, 0x3a, 0x20, 0x55, 0x73, 0x65, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x5b, 0x5d, 0x2c, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x5b, 0x5d, 0x2c, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x5b, 0x5d, 0x20, 0x62, 0x75, 0x69, 0x6c, 0x74, 0x69, 0x6e, 0x73, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L52:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L54
    cmp byte [rsi], 0
    je .L53
    inc rdx
    inc rsi
    jmp .L52
.L54:
    mov rdx, 0          ; truncate to 0 on overflow
.L53:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_55
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call extract_substring
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_55
.recursion_limit_55:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_55:
    push rax            ; var substring
    lea rax, [rel .STR56]
section .data
.STR56: db 0x45, 0x78, 0x74, 0x72, 0x61, 0x63, 0x74, 0x20, 0x27, 0x43, 0x6f, 0x64, 0x65, 0x27, 0x20, 0x66, 0x72, 0x6f, 0x6d, 0x20, 0x27, 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x20, 0x4f, 0x70, 0x74, 0x69, 0x6d, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x27, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR60]
section .data
.STR60: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load substring
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L64:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L66
    cmp byte [rsi], 0
    je .L65
    inc rdx
    inc rsi
    jmp .L64
.L66:
    mov rdx, 0          ; truncate to 0 on overflow
.L65:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR67]
section .data
.STR67: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L68:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L70
    cmp byte [rsi], 0
    je .L69
    inc rdx
    inc rsi
    jmp .L68
.L70:
    mov rdx, 0          ; truncate to 0 on overflow
.L69:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_71
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call build_string
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_71
.recursion_limit_71:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_71:
    push rax            ; var combined
    lea rax, [rel .STR72]
section .data
.STR72: db 0x43, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x65, 0x6e, 0x61, 0x74, 0x65, 0x20, 0x27, 0x6f, 0x70, 0x74, 0x69, 0x6d, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x27, 0x20, 0x2b, 0x20, 0x27, 0x74, 0x65, 0x73, 0x74, 0x27, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR76]
section .data
.STR76: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load combined
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L80:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L82
    cmp byte [rsi], 0
    je .L81
    inc rdx
    inc rsi
    jmp .L80
.L82:
    mov rdx, 0          ; truncate to 0 on overflow
.L81:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR83]
section .data
.STR83: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L84:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L86
    cmp byte [rsi], 0
    je .L85
    inc rdx
    inc rsi
    jmp .L84
.L86:
    mov rdx, 0          ; truncate to 0 on overflow
.L85:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR87]
section .data
.STR87: db 0x55, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x5b, 0x5d, 0x2c, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x5b, 0x5d, 0x2c, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x5b, 0x5d, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L88:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L90
    cmp byte [rsi], 0
    je .L89
    inc rdx
    inc rsi
    jmp .L88
.L90:
    mov rdx, 0          ; truncate to 0 on overflow
.L89:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_91
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call string_operations
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_91
.recursion_limit_91:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_91:
    push rax            ; var length
    lea rax, [rel .STR92]
section .data
.STR92: db 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L93:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L95
    cmp byte [rsi], 0
    je .L94
    inc rdx
    inc rsi
    jmp .L93
.L95:
    mov rdx, 0          ; truncate to 0 on overflow
.L94:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load length
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR96]
section .data
.STR96: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L97:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L99
    cmp byte [rsi], 0
    je .L98
    inc rdx
    inc rsi
    jmp .L97
.L99:
    mov rdx, 0          ; truncate to 0 on overflow
.L98:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR100]
section .data
.STR100: db 0xe2, 0x9c, 0x93, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x41, 0x52, 0x4f, 0x55, 0x4e, 0x44, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x76, 0x69, 0x61, 0x20, 0x62, 0x75, 0x69, 0x6c, 0x74, 0x69, 0x6e, 0x73, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L101:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L103
    cmp byte [rsi], 0
    je .L102
    inc rdx
    inc rsi
    jmp .L101
.L103:
    mov rdx, 0          ; truncate to 0 on overflow
.L102:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR104]
section .data
.STR104: db 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x5b, 0x73, 0x74, 0x72, 0x2c, 0x20, 0x73, 0x74, 0x61, 0x72, 0x74, 0x2c, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x5d, 0x20, 0x2d, 0x20, 0x45, 0x78, 0x74, 0x72, 0x61, 0x63, 0x74, 0x20, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR108]
section .data
.STR108: db 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x5b, 0x73, 0x74, 0x72, 0x31, 0x2c, 0x20, 0x73, 0x74, 0x72, 0x32, 0x5d, 0x20, 0x2d, 0x20, 0x4a, 0x6f, 0x69, 0x6e, 0x20, 0x73, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L109:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L111
    cmp byte [rsi], 0
    je .L110
    inc rdx
    inc rsi
    jmp .L109
.L111:
    mov rdx, 0          ; truncate to 0 on overflow
.L110:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR112]
section .data
.STR112: db 0xe2, 0x9c, 0x93, 0x20, 0x40, 0x6c, 0x65, 0x6e, 0x5b, 0x73, 0x74, 0x72, 0x5d, 0x20, 0x2d, 0x20, 0x47, 0x65, 0x74, 0x20, 0x73, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L113:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L115
    cmp byte [rsi], 0
    je .L114
    inc rdx
    inc rsi
    jmp .L113
.L115:
    mov rdx, 0          ; truncate to 0 on overflow
.L114:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
