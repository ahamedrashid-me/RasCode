global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



count_condition_slow:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov [rbp-16], rsi     ; parameter target
    mov rax, 0
    push rax            ; var i
    mov rax, 0
    push rax            ; var found
.L2:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 100
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L3
    mov rax, [rbp - 24]  ; load i
    cmp rax, 0
    jl .bounds_error_6
    cmp rax, 100
    jge .bounds_error_6
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_7
.bounds_error_6:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_7:
    push rax
    mov rax, [rbp - 16]  ; load target
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L4
    mov rax, 1
    mov [rbp - 32], rax  ; assign found
    jmp .L5
.L4:
.L5:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    jmp .L2
.L3:
    mov rax, [rbp - 32]  ; load found
    cmp rax, 0
    je .L7
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L8
.L7:
.L8:
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 16         ; pop 2 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

count_condition_fast:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_9
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_9:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_10
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_10:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov [rbp-16], rsi     ; parameter target
    mov rax, 0
    push rax            ; var i
.L11:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 100
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L12
    mov rax, [rbp - 24]  ; load i
    cmp rax, 0
    jl .bounds_error_15
    cmp rax, 100
    jge .bounds_error_15
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_16
.bounds_error_15:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_16:
    push rax
    mov rax, [rbp - 16]  ; load target
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L13
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L14
.L13:
.L14:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    jmp .L11
.L12:
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

init_array:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_16
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_16:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_17
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_17:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov rax, 0
    push rax            ; var i
.L18:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 100
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L19
    mov rax, [rbp - 16]  ; load i
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_20
    cmp rax, 100
    jge .bounds_error_20
    mov rax, [rbp - 16]  ; load i
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 8         ; element size
    imul rax, rcx       ; index * size
    mov rcx, [rbp - 8] ; load array pointer (parameter)
    add rcx, rax        ; element address
    mov qword [rcx], rbx ; store qword
    jmp .bounds_ok_21
.bounds_error_20:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_21:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign i
    jmp .L18
.L19:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_21
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_21:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_22
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_22:
    lea rax, [rel .STR23]
section .data
.STR23: db 0x54, 0x45, 0x53, 0x54, 0x3a, 0x20, 0x45, 0x61, 0x72, 0x6c, 0x79, 0x20, 0x4c, 0x6f, 0x6f, 0x70, 0x20, 0x45, 0x78, 0x69, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L24:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L26
    cmp byte [rsi], 0
    je .L25
    inc rdx
    inc rsi
    jmp .L24
.L26:
    mov rdx, 0          ; truncate to 0 on overflow
.L25:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR27]
section .data
.STR27: db 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x69, 0x6e, 0x67, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x65, 0x6c, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x69, 0x6e, 0x20, 0x61, 0x72, 0x72, 0x61, 0x79, 0x20, 0x6f, 0x66, 0x20, 0x31, 0x30, 0x30, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L28:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L30
    cmp byte [rsi], 0
    je .L29
    inc rdx
    inc rsi
    jmp .L28
.L30:
    mov rdx, 0          ; truncate to 0 on overflow
.L29:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; array declaration: numbers{int, 100} (element_size=4 bytes)
    sub rsp, 400         ; allocate array space
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    pop rdi              ; load arg 0
    call init_array
    mov rax, 5
    push rax            ; var target
    lea rax, [rel .STR31]
section .data
.STR31: db 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x69, 0x6e, 0x67, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x74, 0x61, 0x72, 0x67, 0x65, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 408]  ; load target
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR35]
section .data
.STR35: db 0x20, 0x28, 0x65, 0x61, 0x72, 0x6c, 0x79, 0x20, 0x70, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x3d, 0x20, 0x66, 0x61, 0x73, 0x74, 0x65, 0x72, 0x29, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_slow
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    mov rax, [rbp - 408]  ; load target
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_39
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call count_condition_slow
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_39
.recursion_limit_39:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_39:
    push rax            ; var result_slow
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_slow
    mov rax, [rbp - 432]  ; load end_slow
    push rax
    mov rax, [rbp - 416]  ; load start_slow
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_slow
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_fast
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    mov rax, [rbp - 408]  ; load target
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_40
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call count_condition_fast
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_40
.recursion_limit_40:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_40:
    push rax            ; var result_fast
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_fast
    mov rax, [rbp - 464]  ; load end_fast
    push rax
    mov rax, [rbp - 448]  ; load start_fast
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_fast
    lea rax, [rel .STR41]
section .data
.STR41: db 0x53, 0x6c, 0x6f, 0x77, 0x20, 0x28, 0x6e, 0x6f, 0x20, 0x65, 0x61, 0x72, 0x6c, 0x79, 0x20, 0x65, 0x78, 0x69, 0x74, 0x29, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L42:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L44
    cmp byte [rsi], 0
    je .L43
    inc rdx
    inc rsi
    jmp .L42
.L44:
    mov rdx, 0          ; truncate to 0 on overflow
.L43:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 424]  ; load result_slow
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR45]
section .data
.STR45: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L46:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L48
    cmp byte [rsi], 0
    je .L47
    inc rdx
    inc rsi
    jmp .L46
.L48:
    mov rdx, 0          ; truncate to 0 on overflow
.L47:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR49]
section .data
.STR49: db 0x53, 0x6c, 0x6f, 0x77, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L50:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L52
    cmp byte [rsi], 0
    je .L51
    inc rdx
    inc rsi
    jmp .L50
.L52:
    mov rdx, 0          ; truncate to 0 on overflow
.L51:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 440]  ; load time_slow
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR53]
section .data
.STR53: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L54:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L56
    cmp byte [rsi], 0
    je .L55
    inc rdx
    inc rsi
    jmp .L54
.L56:
    mov rdx, 0          ; truncate to 0 on overflow
.L55:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR57]
section .data
.STR57: db 0x46, 0x61, 0x73, 0x74, 0x20, 0x28, 0x65, 0x61, 0x72, 0x6c, 0x79, 0x20, 0x65, 0x78, 0x69, 0x74, 0x29, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L58:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L60
    cmp byte [rsi], 0
    je .L59
    inc rdx
    inc rsi
    jmp .L58
.L60:
    mov rdx, 0          ; truncate to 0 on overflow
.L59:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 456]  ; load result_fast
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR61]
section .data
.STR61: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L62:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L64
    cmp byte [rsi], 0
    je .L63
    inc rdx
    inc rsi
    jmp .L62
.L64:
    mov rdx, 0          ; truncate to 0 on overflow
.L63:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR65]
section .data
.STR65: db 0x46, 0x61, 0x73, 0x74, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L66:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L68
    cmp byte [rsi], 0
    je .L67
    inc rdx
    inc rsi
    jmp .L66
.L68:
    mov rdx, 0          ; truncate to 0 on overflow
.L67:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 472]  ; load time_fast
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR69]
section .data
.STR69: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L70:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L72
    cmp byte [rsi], 0
    je .L71
    inc rdx
    inc rsi
    jmp .L70
.L72:
    mov rdx, 0          ; truncate to 0 on overflow
.L71:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 424]  ; load result_slow
    push rax
    mov rax, [rbp - 456]  ; load result_fast
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L73
    lea rax, [rel .STR75]
section .data
.STR75: db 0xe2, 0x9c, 0x93, 0x20, 0x50, 0x41, 0x53, 0x53, 0x3a, 0x20, 0x42, 0x6f, 0x74, 0x68, 0x20, 0x6d, 0x65, 0x74, 0x68, 0x6f, 0x64, 0x73, 0x20, 0x66, 0x69, 0x6e, 0x64, 0x20, 0x74, 0x61, 0x72, 0x67, 0x65, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L76:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L78
    cmp byte [rsi], 0
    je .L77
    inc rdx
    inc rsi
    jmp .L76
.L78:
    mov rdx, 0          ; truncate to 0 on overflow
.L77:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 472]  ; load time_fast
    push rax
    mov rax, [rbp - 440]  ; load time_slow
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L79
    lea rax, [rel .STR81]
section .data
.STR81: db 0xe2, 0x9c, 0x93, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x56, 0x45, 0x52, 0x49, 0x46, 0x49, 0x45, 0x44, 0x3a, 0x20, 0x45, 0x61, 0x72, 0x6c, 0x79, 0x20, 0x65, 0x78, 0x69, 0x74, 0x20, 0x66, 0x61, 0x73, 0x74, 0x65, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L82:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L84
    cmp byte [rsi], 0
    je .L83
    inc rdx
    inc rsi
    jmp .L82
.L84:
    mov rdx, 0          ; truncate to 0 on overflow
.L83:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L80
.L79:
    lea rax, [rel .STR85]
section .data
.STR85: db 0xe2, 0x9c, 0x97, 0x20, 0x4e, 0x4f, 0x20, 0x43, 0x4c, 0x45, 0x41, 0x52, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x28, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x6f, 0x6f, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L86:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L88
    cmp byte [rsi], 0
    je .L87
    inc rdx
    inc rsi
    jmp .L86
.L88:
    mov rdx, 0          ; truncate to 0 on overflow
.L87:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L80:
    jmp .L74
.L73:
    lea rax, [rel .STR89]
section .data
.STR89: db 0xe2, 0x9c, 0x97, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x3a, 0x20, 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L90:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L92
    cmp byte [rsi], 0
    je .L91
    inc rdx
    inc rsi
    jmp .L90
.L92:
    mov rdx, 0          ; truncate to 0 on overflow
.L91:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L74:
    add rsp, 472         ; pop 59 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
