global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



find_word_slow:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter text
    mov [rbp-16], rsi     ; parameter word
    mov rax, 0
    push rax            ; var i
    ; Builtin function @len
    mov rax, [rbp - 8]  ; load text
    mov rdi, rax
    xor rcx, rcx
.len_loop_2:
    cmp byte [rdi+rcx], 0
    je .len_done_2
    inc rcx
    jmp .len_loop_2
.len_done_2:
    mov rax, rcx
    push rax            ; var text_len
    ; Builtin function @len
    mov rax, [rbp - 16]  ; load word
    mov rdi, rax
    xor rcx, rcx
.len_loop_3:
    cmp byte [rdi+rcx], 0
    je .len_done_3
    inc rcx
    jmp .len_loop_3
.len_done_3:
    mov rax, rcx
    push rax            ; var word_len
.L4:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, [rbp - 32]  ; load text_len
    push rax
    mov rax, [rbp - 40]  ; load word_len
    mov rbx, rax
    pop rax
    sub rax, rbx
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L5
    mov rax, 0
    push rax            ; var j
    mov rax, 1
    push rax            ; var match
.L6:
    mov rax, [rbp - 48]  ; load j
    push rax
    mov rax, [rbp - 40]  ; load word_len
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    test rax, rax       ; check left operand
    jz .L8             ; if false, skip right
    mov rax, [rbp - 56]  ; load match
    test rax, rax       ; check right operand
    jz .L8             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L9
.L8:
    xor rax, rax        ; result is 0
.L9:
    cmp rax, 0
    je .L7
    push rax
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L10
    mov rax, 0
    mov [rbp - 56], rax  ; assign match
    jmp .L11
.L10:
.L11:
    mov rax, [rbp - 48]  ; load j
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 48], rax  ; assign j
    jmp .L6
.L7:
    mov rax, [rbp - 56]  ; load match
    cmp rax, 0
    je .L12
    mov rax, [rbp - 24]  ; load i
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L13
.L12:
.L13:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    add rsp, 16         ; pop 2 block-local variables
    jmp .L4
.L5:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

find_word_fast:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_14
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_14:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_15
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_15:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter text
    mov [rbp-16], rsi     ; parameter word
    ; Builtin function @len
    mov rax, [rbp - 8]  ; load text
    mov rdi, rax
    xor rcx, rcx
.len_loop_16:
    cmp byte [rdi+rcx], 0
    je .len_done_16
    inc rcx
    jmp .len_loop_16
.len_done_16:
    mov rax, rcx
    push rax            ; var text_len
    ; Builtin function @len
    mov rax, [rbp - 16]  ; load word
    mov rdi, rax
    xor rcx, rcx
.len_loop_17:
    cmp byte [rdi+rcx], 0
    je .len_done_17
    inc rcx
    jmp .len_loop_17
.len_done_17:
    mov rax, rcx
    push rax            ; var word_len
    mov rax, 0
    push rax            ; var i
.L18:
    mov rax, [rbp - 40]  ; load i
    push rax
    mov rax, [rbp - 24]  ; load text_len
    push rax
    mov rax, [rbp - 32]  ; load word_len
    mov rbx, rax
    pop rax
    sub rax, rbx
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L19
    mov rax, 0
    push rax            ; var j
    mov rax, 1
    push rax            ; var match
.L20:
    mov rax, [rbp - 48]  ; load j
    push rax
    mov rax, [rbp - 32]  ; load word_len
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L21
    push rax
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setne al
    movzx rax, al
    cmp rax, 0
    je .L22
    mov rax, 0
    mov [rbp - 56], rax  ; assign match
    mov rax, [rbp - 32]  ; load word_len
    mov [rbp - 48], rax  ; assign j
    jmp .L23
.L22:
.L23:
    mov rax, [rbp - 48]  ; load j
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 48], rax  ; assign j
    jmp .L20
.L21:
    mov rax, [rbp - 56]  ; load match
    cmp rax, 0
    je .L24
    mov rax, [rbp - 40]  ; load i
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L25
.L24:
.L25:
    mov rax, [rbp - 40]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 40], rax  ; assign i
    add rsp, 16         ; pop 2 block-local variables
    jmp .L18
.L19:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_26
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_26:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_27
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_27:
    lea rax, [rel .STR28]
section .data
.STR28: db 0x68, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax            ; var haystack
    lea rax, [rel .STR29]
section .data
.STR29: db 0x77, 0x6f, 0x72, 0x6c, 0x64, 0x00
section .text
    push rax            ; var needle
    lea rax, [rel .STR30]
section .data
.STR30: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L31:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L33
    cmp byte [rsi], 0
    je .L32
    inc rdx
    inc rsi
    jmp .L31
.L33:
    mov rdx, 0          ; truncate to 0 on overflow
.L32:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR34]
section .data
.STR34: db 0x48, 0x61, 0x79, 0x73, 0x74, 0x61, 0x63, 0x6b, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L35:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L37
    cmp byte [rsi], 0
    je .L36
    inc rdx
    inc rsi
    jmp .L35
.L37:
    mov rdx, 0          ; truncate to 0 on overflow
.L36:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load haystack
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L38:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L40
    cmp byte [rsi], 0
    je .L39
    inc rdx
    inc rsi
    jmp .L38
.L40:
    mov rdx, 0          ; truncate to 0 on overflow
.L39:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR41]
section .data
.STR41: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L42:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L44
    cmp byte [rsi], 0
    je .L43
    inc rdx
    inc rsi
    jmp .L42
.L44:
    mov rdx, 0          ; truncate to 0 on overflow
.L43:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR45]
section .data
.STR45: db 0x4e, 0x65, 0x65, 0x64, 0x6c, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L46:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L48
    cmp byte [rsi], 0
    je .L47
    inc rdx
    inc rsi
    jmp .L46
.L48:
    mov rdx, 0          ; truncate to 0 on overflow
.L47:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load needle
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L49:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L51
    cmp byte [rsi], 0
    je .L50
    inc rdx
    inc rsi
    jmp .L49
.L51:
    mov rdx, 0          ; truncate to 0 on overflow
.L50:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR52]
section .data
.STR52: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L53:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L55
    cmp byte [rsi], 0
    je .L54
    inc rdx
    inc rsi
    jmp .L53
.L55:
    mov rdx, 0          ; truncate to 0 on overflow
.L54:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load haystack
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load needle
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_56
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call find_word_slow
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_56
.recursion_limit_56:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_56:
    push rax            ; var result_slow
    lea rax, [rel .STR57]
section .data
.STR57: db 0x53, 0x6c, 0x6f, 0x77, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L58:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L60
    cmp byte [rsi], 0
    je .L59
    inc rdx
    inc rsi
    jmp .L58
.L60:
    mov rdx, 0          ; truncate to 0 on overflow
.L59:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load result_slow
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR61]
section .data
.STR61: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L62:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L64
    cmp byte [rsi], 0
    je .L63
    inc rdx
    inc rsi
    jmp .L62
.L64:
    mov rdx, 0          ; truncate to 0 on overflow
.L63:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load haystack
    push rax            ; save arg 0
    mov rax, [rbp - 16]  ; load needle
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_65
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call find_word_fast
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_65
.recursion_limit_65:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_65:
    push rax            ; var result_fast
    lea rax, [rel .STR66]
section .data
.STR66: db 0x46, 0x61, 0x73, 0x74, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L67:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L69
    cmp byte [rsi], 0
    je .L68
    inc rdx
    inc rsi
    jmp .L67
.L69:
    mov rdx, 0          ; truncate to 0 on overflow
.L68:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load result_fast
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR70]
section .data
.STR70: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L71:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L73
    cmp byte [rsi], 0
    je .L72
    inc rdx
    inc rsi
    jmp .L71
.L73:
    mov rdx, 0          ; truncate to 0 on overflow
.L72:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR74]
section .data
.STR74: db 0x78, 0x79, 0x7a, 0x00
section .text
    push rax            ; var needle2
    lea rax, [rel .STR75]
section .data
.STR75: db 0x0a, 0x54, 0x45, 0x53, 0x54, 0x20, 0x32, 0x3a, 0x20, 0x4e, 0x6f, 0x74, 0x20, 0x66, 0x6f, 0x75, 0x6e, 0x64, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L76:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L78
    cmp byte [rsi], 0
    je .L77
    inc rdx
    inc rsi
    jmp .L76
.L78:
    mov rdx, 0          ; truncate to 0 on overflow
.L77:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR79]
section .data
.STR79: db 0x4e, 0x65, 0x65, 0x64, 0x6c, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L80:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L82
    cmp byte [rsi], 0
    je .L81
    inc rdx
    inc rsi
    jmp .L80
.L82:
    mov rdx, 0          ; truncate to 0 on overflow
.L81:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load needle2
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L83:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L85
    cmp byte [rsi], 0
    je .L84
    inc rdx
    inc rsi
    jmp .L83
.L85:
    mov rdx, 0          ; truncate to 0 on overflow
.L84:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR86]
section .data
.STR86: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L87:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L89
    cmp byte [rsi], 0
    je .L88
    inc rdx
    inc rsi
    jmp .L87
.L89:
    mov rdx, 0          ; truncate to 0 on overflow
.L88:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load haystack
    push rax            ; save arg 0
    mov rax, [rbp - 40]  ; load needle2
    push rax            ; save arg 1
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_90
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call find_word_fast
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_90
.recursion_limit_90:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_90:
    push rax            ; var result2
    lea rax, [rel .STR91]
section .data
.STR91: db 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L92:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L94
    cmp byte [rsi], 0
    je .L93
    inc rdx
    inc rsi
    jmp .L92
.L94:
    mov rdx, 0          ; truncate to 0 on overflow
.L93:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load result2
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR95]
section .data
.STR95: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L96:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L98
    cmp byte [rsi], 0
    je .L97
    inc rdx
    inc rsi
    jmp .L96
.L98:
    mov rdx, 0          ; truncate to 0 on overflow
.L97:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 24]  ; load result_slow
    push rax
    mov rax, [rbp - 32]  ; load result_fast
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L99
    lea rax, [rel .STR101]
section .data
.STR101: db 0xe2, 0x9c, 0x93, 0x20, 0x50, 0x41, 0x53, 0x53, 0x3a, 0x20, 0x42, 0x6f, 0x74, 0x68, 0x20, 0x6d, 0x65, 0x74, 0x68, 0x6f, 0x64, 0x73, 0x20, 0x72, 0x65, 0x74, 0x75, 0x72, 0x6e, 0x20, 0x73, 0x61, 0x6d, 0x65, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L102:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L104
    cmp byte [rsi], 0
    je .L103
    inc rdx
    inc rsi
    jmp .L102
.L104:
    mov rdx, 0          ; truncate to 0 on overflow
.L103:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L100
.L99:
    lea rax, [rel .STR105]
section .data
.STR105: db 0xe2, 0x9c, 0x97, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x3a, 0x20, 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L106:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L108
    cmp byte [rsi], 0
    je .L107
    inc rdx
    inc rsi
    jmp .L106
.L108:
    mov rdx, 0          ; truncate to 0 on overflow
.L107:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L100:
    add rsp, 48         ; pop 6 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
