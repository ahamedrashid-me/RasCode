# RasCode Optimization Test Suite
## Folder: `/RasCode/optimizing_test_case`

This directory contains comprehensive test cases to verify ALL optimization techniques from the **29-OPTIMIZATION-GUIDE.md**.

---

## Purpose

Verify which optimization techniques actually work in RasCode by:
- Testing both optimized and unoptimized versions
- Comparing results for **correctness** (must match)
- Comparing **timing** (if measurable difference exists)
- Providing clear PASS/FAIL verdicts

---

## Test Files

### 1. `01_string_operations.ras`
**Optimization**: String search with pre-computed lengths

**Tests**:
- `find_word_slow[]` - Uses length computation inside loop
- `find_word_fast[]` - Pre-computes lengths before loop

**Expected Result**: ✓ PASS - Same correctness, fast should be faster
**Benchmark**: Finding "world" in "hello world"

---

### 2. `02_function_call_overhead.ras`
**Optimization**: Inline computation vs function calls

**Tests**:
- `calculate_slow[]` - Calls `square[i]` 100 times
- `calculate_fast[]` - Inlines `i * i` computation

**Expected Result**: ✓ PASS - Same correctness, inlined should be faster
**Benchmark**: Computing sum of squares (0-99)

---

### 3. `03_array_access_patterns.ras`
**Optimization**: Row-major (cache-friendly) vs column-major (cache-unfriendly)

**Tests**:
- `sum_matrix_fast[]` - Row-major: iterate `i` first, then `j`
- `sum_matrix_slow[]` - Column-major: iterate `j` first, then `i`

**Expected Result**: ✓ PASS - Same correctness but row-major much faster
**Benchmark**: Summing 50x50 matrix (2500 elements)
**Note**: Row-major is ~10-100x faster due to cache locality!

---

### 4. `04_fibonacci_optimization.ras`
**Optimization**: Iterative vs recursive computation

**Tests**:
- `fib_recursive[n]` - Exponential complexity O(2^n)
- `fib_iterative[n]` - Linear complexity O(n)

**Expected Result**: ✓ PASS - Same correctness, iterative exponentially faster
**Benchmark**: Computing fib(10) and above
**Note**: fib(40) recursive ~3 seconds, iterative <1ms (3000x!)

---

### 5. `05_binary_search.ras`
**Optimization**: Binary search vs linear search

**Tests**:
- `linear_search[]` - Searches sequentially O(n)
- `binary_search[]` - Searches logarithmically O(log n)

**Expected Result**: ✓ PASS - Same correctness, binary much faster
**Benchmark**: Finding target in sorted 100-element array
**Note**: For 100K elements: 100K iterations vs 17 iterations (5800x!)

---

### 6. `06_loop_unrolling.ras`
**Optimization**: Loop unrolling (process 4 elements per iteration)

**Tests**:
- `sum_simple[]` - One element per loop iteration
- `sum_unrolled[]` - Four elements per loop iteration

**Expected Result**: ✓ PASS - Same correctness, unrolled ~25% faster
**Benchmark**: Summing 100-element array
**Note**: Reduces loop branch overhead by 4x

---

### 7. `07_strength_reduction.ras`
**Optimization**: Bit shift vs multiply (both do x8)

**Tests**:
- `scale_multiply[]` - Uses `x * 8` (multiple CPU cycles)
- `scale_shift[]` - Uses `x << 3` (single CPU cycle)

**Expected Result**: ✓ PASS - Same correctness, shift faster
**Benchmark**: Multiply/shift 50 elements
**Note**: Shift = ~1 cycle, Multiply = ~3-4 cycles

---

### 8. `08_early_loop_exit.ras`
**Optimization**: Return immediately vs complete full loop

**Tests**:
- `count_condition_slow[]` - Always completes all 100 iterations
- `count_condition_fast[]` - Returns immediately when found

**Expected Result**: ✓ PASS - Same correctness when target found early
**Benchmark**: Finding element at position 5 in 100-element array
**Note**: Huge benefit when target near start!

---

## How to Run Tests

### Step 1: Compile Individual Test
```bash
cd /home/void/Desktop/RASIDE/RasCode/optimizing_test_case
rascom 01_string_operations.ras -o 01_string_operations_bin
./01_string_operations_bin
```

### Step 2: Run Test
Expected output format:
```
TEST: String Search
Haystack: hello world
Needle: world
Slow result: 6
Fast result: 6

✓ PASS: Both methods return same result
```

### Step 3: Interpret Results

**✓ PASS** = Correctness verified (both versions produce same answer)
**✓ OPTIMIZATION VERIFIED** = Timing shows optimization works
**✗ FAIL** = Versions produce different results (bug in code!)
**✗ NO CLEAR OPTIMIZATION** = Timing too close (may be system-dependent)

---

## Execution Results Summary Template

Create a file `TEST_RESULTS.txt` with your findings:

```
TEST RESULTS - RasCode Optimization Suite
==========================================

Date: [YOUR_DATE]
System: Linux [YOUR_SYSTEM]
RasCode Compiler: [VERSION]

TEST 1: String Operations
Result: ✓ PASS - Both find "world" at position 6
Timing: Fast 2491 ns, Slow 3847 ns
Optimization: ✓ VERIFIED

TEST 2: Function Call Overhead  
Result: ✓ PASS - Both sum to 328350
Timing: Inlined 1234 ns, Function calls 2567 ns
Optimization: ✓ VERIFIED

...
```

---

## What This Tests

### Correctness (MUST PASS)
- Both optimized and unoptimized versions compute same results
- No syntax errors or runtime failures
- All functions return correct values

### Performance (Should show benefit)
- Optimized version should be faster (if measurable)
- Timing uses `@time[]` for nanosecond precision
- Results may be system/compiler dependent

### What Actually Works
- Which RasCode features support the optimization
- Where the compiler enables optimizations
- Where manual techniques help most

---

## Analysis After Running

After running all tests, document:

1. **Which optimizations work?** (faster results)
2. **Which show no improvement?** (timing too close)
3. **Which fail?** (different results = bug)
4. **System factors**: CPU cache, compiler optimization level
5. **Code patterns**: What makes biggest difference?
6. **Compiler behavior**: Does RasCode auto-optimize any of these?

---

## Notes

- Tests use authentic RasCode syntax verified from `/RasCode/src/lexer.c`
- All syntax patterns match real test files in `/RasCode/test_*.ras`
- Timing precision depends on system resolution (may be coarse-grained)
- Run multiple times for consistency
- Some tests may not show timing difference if operation too fast

---

## See Also

- [29-OPTIMIZATION-GUIDE.md](../29-OPTIMIZATION-GUIDE.md) - Detailed explanations
- [RasCode Syntax Reference](../02-SYNTAX-RULES.md) - Language features
- `/RasCode/test_*.ras` - Real working examples

---

## Success Criteria

All tests are "successful" if:
1. ✓ All compile without errors
2. ✓ All run without crashes  
3. ✓ All report PASS on correctness
4. ✓ Documentation of which optimizations verified working

This proves the optimization techniques are valid RasCode approaches!
