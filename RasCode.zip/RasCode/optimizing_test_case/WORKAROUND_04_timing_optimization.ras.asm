global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



sum_loop_many_times:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter iterations
    mov rax, 0
    push rax            ; var sum
    mov rax, 0
    push rax            ; var i
.L2:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, [rbp - 8]  ; load iterations
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L3
    mov rax, [rbp - 16]  ; load sum
    push rax
    mov rax, [rbp - 24]  ; load i
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign sum
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    jmp .L2
.L3:
    mov rax, [rbp - 16]  ; load sum
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 16         ; pop 2 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

factorial:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_4
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_4:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_5
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_5:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L6
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L7
.L6:
.L7:
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_8
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call factorial
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_8
.recursion_limit_8:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_8:
    mov rbx, rax
    pop rax
    imul rax, rbx
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

benchmark_small_iteration:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_9
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_9:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_10
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_10:
    lea rax, [rel .STR11]
section .data
.STR11: db 0x53, 0x6d, 0x61, 0x6c, 0x6c, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x20, 0x28, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x6f, 0x6f, 0x20, 0x63, 0x6f, 0x61, 0x72, 0x73, 0x65, 0x29, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L12:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L14
    cmp byte [rsi], 0
    je .L13
    inc rdx
    inc rsi
    jmp .L12
.L14:
    mov rdx, 0          ; truncate to 0 on overflow
.L13:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start
    mov rax, 100
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_15
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call sum_loop_many_times
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_15
.recursion_limit_15:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_15:
    push rax            ; var result
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end
    mov rax, [rbp - 24]  ; load end
    push rax
    mov rax, [rbp - 8]  ; load start
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var elapsed
    lea rax, [rel .STR16]
section .data
.STR16: db 0x20, 0x20, 0x31, 0x30, 0x30, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L17:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L19
    cmp byte [rsi], 0
    je .L18
    inc rdx
    inc rsi
    jmp .L17
.L19:
    mov rdx, 0          ; truncate to 0 on overflow
.L18:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load elapsed
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR20]
section .data
.STR20: db 0x6e, 0x73, 0x20, 0x28, 0x70, 0x72, 0x6f, 0x62, 0x61, 0x62, 0x6c, 0x79, 0x20, 0x30, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L21:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L23
    cmp byte [rsi], 0
    je .L22
    inc rdx
    inc rsi
    jmp .L21
.L23:
    mov rdx, 0          ; truncate to 0 on overflow
.L22:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    add rsp, 32         ; pop 4 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

benchmark_large_iteration:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_24
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_24:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_25
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_25:
    lea rax, [rel .STR26]
section .data
.STR26: db 0x4c, 0x61, 0x72, 0x67, 0x65, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x20, 0x28, 0x6d, 0x65, 0x61, 0x73, 0x75, 0x72, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x29, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L27:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L29
    cmp byte [rsi], 0
    je .L28
    inc rdx
    inc rsi
    jmp .L27
.L29:
    mov rdx, 0          ; truncate to 0 on overflow
.L28:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start
    mov rax, 10000000
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_30
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call sum_loop_many_times
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_30
.recursion_limit_30:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_30:
    push rax            ; var result
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end
    mov rax, [rbp - 24]  ; load end
    push rax
    mov rax, [rbp - 8]  ; load start
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var elapsed
    lea rax, [rel .STR31]
section .data
.STR31: db 0x20, 0x20, 0x31, 0x30, 0x2c, 0x30, 0x30, 0x30, 0x2c, 0x30, 0x30, 0x30, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load elapsed
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR35]
section .data
.STR35: db 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    add rsp, 32         ; pop 4 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

fibonacci_iterations:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_39
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_39:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_40
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_40:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L41
    mov rax, [rbp - 8]  ; load n
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L42
.L41:
.L42:
    mov rax, 0
    push rax            ; var a
    mov rax, 1
    push rax            ; var b
    mov rax, 2
    push rax            ; var i
.L43:
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, [rbp - 8]  ; load n
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L44
    mov rax, [rbp - 16]  ; load a
    push rax
    mov rax, [rbp - 24]  ; load b
    mov rbx, rax
    pop rax
    add rax, rbx
    push rax            ; var temp
    mov rax, [rbp - 24]  ; load b
    mov [rbp - 16], rax  ; assign a
    mov rax, [rbp - 40]  ; load temp
    mov [rbp - 24], rax  ; assign b
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 32], rax  ; assign i
    add rsp, 8         ; pop 1 block-local variables
    jmp .L43
.L44:
    mov rax, [rbp - 24]  ; load b
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

benchmark_computation:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_45
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_45:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_46
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_46:
    lea rax, [rel .STR47]
section .data
.STR47: db 0x43, 0x6f, 0x6d, 0x70, 0x75, 0x74, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x61, 0x6c, 0x20, 0x77, 0x6f, 0x72, 0x6b, 0x6c, 0x6f, 0x61, 0x64, 0x20, 0x28, 0x6d, 0x65, 0x61, 0x73, 0x75, 0x72, 0x61, 0x62, 0x6c, 0x65, 0x29, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start
    mov rax, 0
    push rax            ; var i
    mov rax, 0
    push rax            ; var sum
.L51:
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 100000
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L52
    mov rax, [rbp - 24]  ; load sum
    push rax
    mov rax, 20
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_53
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fibonacci_iterations
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_53
.recursion_limit_53:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_53:
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign sum
    mov rax, [rbp - 16]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 16], rax  ; assign i
    jmp .L51
.L52:
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end
    mov rax, [rbp - 32]  ; load end
    push rax
    mov rax, [rbp - 8]  ; load start
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var elapsed
    lea rax, [rel .STR54]
section .data
.STR54: db 0x20, 0x20, 0x31, 0x30, 0x30, 0x2c, 0x30, 0x30, 0x30, 0x20, 0x66, 0x69, 0x62, 0x28, 0x32, 0x30, 0x29, 0x20, 0x63, 0x61, 0x6c, 0x6c, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L55:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L57
    cmp byte [rsi], 0
    je .L56
    inc rdx
    inc rsi
    jmp .L55
.L57:
    mov rdx, 0          ; truncate to 0 on overflow
.L56:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load elapsed
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR58]
section .data
.STR58: db 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L59:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L61
    cmp byte [rsi], 0
    je .L60
    inc rdx
    inc rsi
    jmp .L59
.L61:
    mov rdx, 0          ; truncate to 0 on overflow
.L60:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    add rsp, 40         ; pop 5 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_62
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_62:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_63
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_63:
    lea rax, [rel .STR64]
section .data
.STR64: db 0x3d, 0x3d, 0x3d, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x41, 0x52, 0x4f, 0x55, 0x4e, 0x44, 0x20, 0x34, 0x3a, 0x20, 0x43, 0x6f, 0x61, 0x72, 0x73, 0x65, 0x20, 0x54, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x52, 0x65, 0x73, 0x6f, 0x6c, 0x75, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x3d, 0x3d, 0x3d, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR68]
section .data
.STR68: db 0x50, 0x52, 0x4f, 0x42, 0x4c, 0x45, 0x4d, 0x3a, 0x20, 0x40, 0x74, 0x69, 0x6d, 0x65, 0x5b, 0x5d, 0x20, 0x72, 0x65, 0x74, 0x75, 0x72, 0x6e, 0x73, 0x20, 0x30, 0x6e, 0x73, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x3c, 0x31, 0x6d, 0x73, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR72]
section .data
.STR72: db 0x53, 0x4f, 0x4c, 0x55, 0x54, 0x49, 0x4f, 0x4e, 0x3a, 0x20, 0x55, 0x73, 0x65, 0x20, 0x6c, 0x61, 0x72, 0x67, 0x65, 0x72, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x6f, 0x72, 0x20, 0x63, 0x6f, 0x6d, 0x70, 0x75, 0x74, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x61, 0x6c, 0x20, 0x77, 0x6f, 0x72, 0x6b, 0x6c, 0x6f, 0x61, 0x64, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    call benchmark_small_iteration
    lea rax, [rel .STR76]
section .data
.STR76: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    call benchmark_large_iteration
    lea rax, [rel .STR80]
section .data
.STR80: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L81:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L83
    cmp byte [rsi], 0
    je .L82
    inc rdx
    inc rsi
    jmp .L81
.L83:
    mov rdx, 0          ; truncate to 0 on overflow
.L82:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    call benchmark_computation
    lea rax, [rel .STR84]
section .data
.STR84: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L85:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L87
    cmp byte [rsi], 0
    je .L86
    inc rdx
    inc rsi
    jmp .L85
.L87:
    mov rdx, 0          ; truncate to 0 on overflow
.L86:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR88]
section .data
.STR88: db 0xe2, 0x9c, 0x93, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x41, 0x52, 0x4f, 0x55, 0x4e, 0x44, 0x20, 0x57, 0x4f, 0x52, 0x4b, 0x53, 0x3a, 0x20, 0x4d, 0x65, 0x61, 0x73, 0x75, 0x72, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L89:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L91
    cmp byte [rsi], 0
    je .L90
    inc rdx
    inc rsi
    jmp .L89
.L91:
    mov rdx, 0          ; truncate to 0 on overflow
.L90:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR92]
section .data
.STR92: db 0xe2, 0x9c, 0x93, 0x20, 0x53, 0x74, 0x72, 0x61, 0x74, 0x65, 0x67, 0x79, 0x20, 0x31, 0x3a, 0x20, 0x49, 0x6e, 0x63, 0x72, 0x65, 0x61, 0x73, 0x65, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x20, 0x28, 0x31, 0x30, 0x4d, 0x2b, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L93:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L95
    cmp byte [rsi], 0
    je .L94
    inc rdx
    inc rsi
    jmp .L93
.L95:
    mov rdx, 0          ; truncate to 0 on overflow
.L94:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR96]
section .data
.STR96: db 0xe2, 0x9c, 0x93, 0x20, 0x53, 0x74, 0x72, 0x61, 0x74, 0x65, 0x67, 0x79, 0x20, 0x32, 0x3a, 0x20, 0x55, 0x73, 0x65, 0x20, 0x63, 0x6f, 0x6d, 0x70, 0x75, 0x74, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x61, 0x6c, 0x20, 0x77, 0x6f, 0x72, 0x6b, 0x6c, 0x6f, 0x61, 0x64, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L97:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L99
    cmp byte [rsi], 0
    je .L98
    inc rdx
    inc rsi
    jmp .L97
.L99:
    mov rdx, 0          ; truncate to 0 on overflow
.L98:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR100]
section .data
.STR100: db 0xe2, 0x9c, 0x93, 0x20, 0x53, 0x74, 0x72, 0x61, 0x74, 0x65, 0x67, 0x79, 0x20, 0x33, 0x3a, 0x20, 0x43, 0x61, 0x6c, 0x6c, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x73, 0x20, 0x69, 0x6e, 0x73, 0x69, 0x64, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x64, 0x20, 0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L101:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L103
    cmp byte [rsi], 0
    je .L102
    inc rdx
    inc rsi
    jmp .L101
.L103:
    mov rdx, 0          ; truncate to 0 on overflow
.L102:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR104]
section .data
.STR104: db 0xe2, 0x9c, 0x93, 0x20, 0x54, 0x79, 0x70, 0x69, 0x63, 0x61, 0x6c, 0x3a, 0x20, 0x47, 0x65, 0x74, 0x20, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x69, 0x6e, 0x20, 0x6d, 0x69, 0x63, 0x72, 0x6f, 0x73, 0x65, 0x63, 0x6f, 0x6e, 0x64, 0x73, 0x20, 0x74, 0x6f, 0x20, 0x6d, 0x69, 0x6c, 0x6c, 0x69, 0x73, 0x65, 0x63, 0x6f, 0x6e, 0x64, 0x73, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
