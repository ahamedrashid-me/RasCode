global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



linear_search:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 24         ; allocate space for 3 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov [rbp-16], rsi     ; parameter target
    mov [rbp-24], rdx     ; parameter size
    mov rax, 0
    push rax            ; var i
.L2:
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, [rbp - 24]  ; load size
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L3
    mov rax, [rbp - 32]  ; load i
    cmp rax, 0
    jl .bounds_error_6
    cmp rax, 100
    jge .bounds_error_6
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_7
.bounds_error_6:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_7:
    push rax
    mov rax, [rbp - 16]  ; load target
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L4
    mov rax, [rbp - 32]  ; load i
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L5
.L4:
.L5:
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 32], rax  ; assign i
    jmp .L2
.L3:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

binary_search:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_7
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_7:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_8
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_8:
    sub rsp, 24         ; allocate space for 3 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov [rbp-16], rsi     ; parameter target
    mov [rbp-24], rdx     ; parameter size
    mov rax, 0
    push rax            ; var left
    mov rax, [rbp - 24]  ; load size
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var right
.L9:
    mov rax, [rbp - 32]  ; load left
    push rax
    mov rax, [rbp - 40]  ; load right
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L10
    mov rax, [rbp - 32]  ; load left
    push rax
    mov rax, [rbp - 40]  ; load right
    push rax
    mov rax, [rbp - 32]  ; load left
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax
    mov rax, 2
    mov rbx, rax
    pop rax
    test rbx, rbx       ; check if divisor is zero
    jz .div_by_zero_11
    xor rdx, rdx
    idiv rbx
    jmp .div_done_11
.div_by_zero_11:
    xor rax, rax        ; return 0 on division by zero
.div_done_11:
    mov rbx, rax
    pop rax
    add rax, rbx
    push rax            ; var mid
    mov rax, [rbp - 48]  ; load mid
    cmp rax, 0
    jl .bounds_error_14
    cmp rax, 100
    jge .bounds_error_14
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_15
.bounds_error_14:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_15:
    push rax
    mov rax, [rbp - 16]  ; load target
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L12
    mov rax, [rbp - 48]  ; load mid
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L13
.L12:
    mov rax, [rbp - 48]  ; load mid
    cmp rax, 0
    jl .bounds_error_17
    cmp rax, 100
    jge .bounds_error_17
    mov rbx, 8         ; element size
    imul rax, rbx       ; index * size
    mov rbx, [rbp - 8] ; load array pointer (parameter)
    add rbx, rax        ; element address
    mov rax, qword [rbx] ; load qword
    jmp .bounds_ok_18
.bounds_error_17:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_18:
    push rax
    mov rax, [rbp - 16]  ; load target
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L15
    mov rax, [rbp - 48]  ; load mid
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 32], rax  ; assign left
    jmp .L16
.L15:
    mov rax, [rbp - 48]  ; load mid
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    mov [rbp - 40], rax  ; assign right
.L16:
.L13:
    add rsp, 8         ; pop 1 block-local variables
    jmp .L9
.L10:
    mov rax, 1
    neg rax             ; unary minus
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 16         ; pop 2 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

init_sorted_array:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_18
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_18:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_19
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_19:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter numbers
    mov [rbp-16], rsi     ; parameter size
    mov rax, 0
    push rax            ; var i
.L20:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, [rbp - 16]  ; load size
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L21
    mov rax, [rbp - 24]  ; load i
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_22
    cmp rax, 100
    jge .bounds_error_22
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 2
    mov rbx, rax
    pop rax
    imul rax, rbx
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 8         ; element size
    imul rax, rcx       ; index * size
    mov rcx, [rbp - 8] ; load array pointer (parameter)
    add rcx, rax        ; element address
    mov qword [rcx], rbx ; store qword
    jmp .bounds_ok_23
.bounds_error_22:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_23:
    mov rax, [rbp - 24]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 24], rax  ; assign i
    jmp .L20
.L21:
    add rsp, 8         ; pop 1 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_23
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_23:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_24
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_24:
    lea rax, [rel .STR25]
section .data
.STR25: db 0x54, 0x45, 0x53, 0x54, 0x3a, 0x20, 0x42, 0x69, 0x6e, 0x61, 0x72, 0x79, 0x20, 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x76, 0x73, 0x20, 0x4c, 0x69, 0x6e, 0x65, 0x61, 0x72, 0x20, 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L26:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L28
    cmp byte [rsi], 0
    je .L27
    inc rdx
    inc rsi
    jmp .L26
.L28:
    mov rdx, 0          ; truncate to 0 on overflow
.L27:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR29]
section .data
.STR29: db 0x41, 0x72, 0x72, 0x61, 0x79, 0x20, 0x73, 0x69, 0x7a, 0x65, 0x3a, 0x20, 0x31, 0x30, 0x30, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L30:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L32
    cmp byte [rsi], 0
    je .L31
    inc rdx
    inc rsi
    jmp .L30
.L32:
    mov rdx, 0          ; truncate to 0 on overflow
.L31:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; array declaration: numbers{int, 100} (element_size=4 bytes)
    sub rsp, 400         ; allocate array space
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    mov rax, 100
    push rax            ; save arg 1
    pop rsi              ; load arg 1
    pop rdi              ; load arg 0
    call init_sorted_array
    mov rax, 150
    push rax            ; var target
    lea rax, [rel .STR33]
section .data
.STR33: db 0x53, 0x65, 0x61, 0x72, 0x63, 0x68, 0x69, 0x6e, 0x67, 0x20, 0x66, 0x6f, 0x72, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L34:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L36
    cmp byte [rsi], 0
    je .L35
    inc rdx
    inc rsi
    jmp .L34
.L36:
    mov rdx, 0          ; truncate to 0 on overflow
.L35:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 408]  ; load target
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR37]
section .data
.STR37: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L38:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L40
    cmp byte [rsi], 0
    je .L39
    inc rdx
    inc rsi
    jmp .L38
.L40:
    mov rdx, 0          ; truncate to 0 on overflow
.L39:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_linear
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    mov rax, [rbp - 408]  ; load target
    push rax            ; save arg 1
    mov rax, 100
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_41
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call linear_search
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_41
.recursion_limit_41:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_41:
    push rax            ; var result_linear
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_linear
    mov rax, [rbp - 432]  ; load end_linear
    push rax
    mov rax, [rbp - 416]  ; load start_linear
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_linear
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_binary
    mov rax, [rbp - 400]  ; load numbers
    push rax            ; save arg 0
    mov rax, [rbp - 408]  ; load target
    push rax            ; save arg 1
    mov rax, 100
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_42
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call binary_search
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_42
.recursion_limit_42:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_42:
    push rax            ; var result_binary
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_binary
    mov rax, [rbp - 464]  ; load end_binary
    push rax
    mov rax, [rbp - 448]  ; load start_binary
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_binary
    lea rax, [rel .STR43]
section .data
.STR43: db 0x4c, 0x69, 0x6e, 0x65, 0x61, 0x72, 0x20, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 424]  ; load result_linear
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR47]
section .data
.STR47: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR51]
section .data
.STR51: db 0x4c, 0x69, 0x6e, 0x65, 0x61, 0x72, 0x20, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L52:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L54
    cmp byte [rsi], 0
    je .L53
    inc rdx
    inc rsi
    jmp .L52
.L54:
    mov rdx, 0          ; truncate to 0 on overflow
.L53:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 440]  ; load time_linear
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR55]
section .data
.STR55: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L56:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L58
    cmp byte [rsi], 0
    je .L57
    inc rdx
    inc rsi
    jmp .L56
.L58:
    mov rdx, 0          ; truncate to 0 on overflow
.L57:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR59]
section .data
.STR59: db 0x42, 0x69, 0x6e, 0x61, 0x72, 0x79, 0x20, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L60:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L62
    cmp byte [rsi], 0
    je .L61
    inc rdx
    inc rsi
    jmp .L60
.L62:
    mov rdx, 0          ; truncate to 0 on overflow
.L61:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 456]  ; load result_binary
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR63]
section .data
.STR63: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L64:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L66
    cmp byte [rsi], 0
    je .L65
    inc rdx
    inc rsi
    jmp .L64
.L66:
    mov rdx, 0          ; truncate to 0 on overflow
.L65:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR67]
section .data
.STR67: db 0x42, 0x69, 0x6e, 0x61, 0x72, 0x79, 0x20, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L68:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L70
    cmp byte [rsi], 0
    je .L69
    inc rdx
    inc rsi
    jmp .L68
.L70:
    mov rdx, 0          ; truncate to 0 on overflow
.L69:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 472]  ; load time_binary
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR71]
section .data
.STR71: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L72:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L74
    cmp byte [rsi], 0
    je .L73
    inc rdx
    inc rsi
    jmp .L72
.L74:
    mov rdx, 0          ; truncate to 0 on overflow
.L73:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 424]  ; load result_linear
    push rax
    mov rax, [rbp - 456]  ; load result_binary
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L75
    lea rax, [rel .STR77]
section .data
.STR77: db 0xe2, 0x9c, 0x93, 0x20, 0x50, 0x41, 0x53, 0x53, 0x3a, 0x20, 0x42, 0x6f, 0x74, 0x68, 0x20, 0x6d, 0x65, 0x74, 0x68, 0x6f, 0x64, 0x73, 0x20, 0x66, 0x69, 0x6e, 0x64, 0x20, 0x73, 0x61, 0x6d, 0x65, 0x20, 0x70, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L78:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L80
    cmp byte [rsi], 0
    je .L79
    inc rdx
    inc rsi
    jmp .L78
.L80:
    mov rdx, 0          ; truncate to 0 on overflow
.L79:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 472]  ; load time_binary
    push rax
    mov rax, [rbp - 440]  ; load time_linear
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L81
    lea rax, [rel .STR83]
section .data
.STR83: db 0xe2, 0x9c, 0x93, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x56, 0x45, 0x52, 0x49, 0x46, 0x49, 0x45, 0x44, 0x3a, 0x20, 0x42, 0x69, 0x6e, 0x61, 0x72, 0x79, 0x20, 0x73, 0x65, 0x61, 0x72, 0x63, 0x68, 0x20, 0x66, 0x61, 0x73, 0x74, 0x65, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L84:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L86
    cmp byte [rsi], 0
    je .L85
    inc rdx
    inc rsi
    jmp .L84
.L86:
    mov rdx, 0          ; truncate to 0 on overflow
.L85:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L82
.L81:
    lea rax, [rel .STR87]
section .data
.STR87: db 0xe2, 0x9c, 0x97, 0x20, 0x4e, 0x4f, 0x20, 0x43, 0x4c, 0x45, 0x41, 0x52, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x28, 0x74, 0x69, 0x6d, 0x69, 0x6e, 0x67, 0x20, 0x74, 0x6f, 0x6f, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L88:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L90
    cmp byte [rsi], 0
    je .L89
    inc rdx
    inc rsi
    jmp .L88
.L90:
    mov rdx, 0          ; truncate to 0 on overflow
.L89:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L82:
    jmp .L76
.L75:
    lea rax, [rel .STR91]
section .data
.STR91: db 0xe2, 0x9c, 0x97, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x3a, 0x20, 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L92:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L94
    cmp byte [rsi], 0
    je .L93
    inc rdx
    inc rsi
    jmp .L92
.L94:
    mov rdx, 0          ; truncate to 0 on overflow
.L93:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L76:
    add rsp, 472         ; pop 59 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
