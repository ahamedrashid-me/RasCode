global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



fib_recursive:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L2
    mov rax, [rbp - 8]  ; load n
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L3
.L2:
.L3:
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_4
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib_recursive
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_4
.recursion_limit_4:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_4:
    push rax
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 2
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_5
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib_recursive
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_5
.recursion_limit_5:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_5:
    mov rbx, rax
    pop rax
    add rax, rbx
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

fib_iterative:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_6
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_6:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_7
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_7:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L8
    mov rax, [rbp - 8]  ; load n
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L9
.L8:
.L9:
    mov rax, 0
    push rax            ; var a
    mov rax, 1
    push rax            ; var b
    mov rax, 2
    push rax            ; var i
.L10:
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, [rbp - 8]  ; load n
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L11
    mov rax, [rbp - 16]  ; load a
    push rax
    mov rax, [rbp - 24]  ; load b
    mov rbx, rax
    pop rax
    add rax, rbx
    push rax            ; var temp
    mov rax, [rbp - 24]  ; load b
    mov [rbp - 16], rax  ; assign a
    mov rax, [rbp - 40]  ; load temp
    mov [rbp - 24], rax  ; assign b
    mov rax, [rbp - 32]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    mov [rbp - 32], rax  ; assign i
    add rsp, 8         ; pop 1 block-local variables
    jmp .L10
.L11:
    mov rax, [rbp - 24]  ; load b
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 24         ; pop 3 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_12
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_12:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_13
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_13:
    lea rax, [rel .STR14]
section .data
.STR14: db 0x54, 0x45, 0x53, 0x54, 0x3a, 0x20, 0x46, 0x69, 0x62, 0x6f, 0x6e, 0x61, 0x63, 0x63, 0x69, 0x20, 0x4f, 0x70, 0x74, 0x69, 0x6d, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L15:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L17
    cmp byte [rsi], 0
    je .L16
    inc rdx
    inc rsi
    jmp .L15
.L17:
    mov rdx, 0          ; truncate to 0 on overflow
.L16:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR18]
section .data
.STR18: db 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x66, 0x69, 0x62, 0x28, 0x31, 0x30, 0x29, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L19:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L21
    cmp byte [rsi], 0
    je .L20
    inc rdx
    inc rsi
    jmp .L19
.L21:
    mov rdx, 0          ; truncate to 0 on overflow
.L20:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_rec
    mov rax, 10
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_22
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib_recursive
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_22
.recursion_limit_22:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_22:
    push rax            ; var result_rec
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_rec
    mov rax, [rbp - 24]  ; load end_rec
    push rax
    mov rax, [rbp - 8]  ; load start_rec
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_rec
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var start_iter
    mov rax, 10
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_23
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib_iterative
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_23
.recursion_limit_23:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_23:
    push rax            ; var result_iter
    ; Builtin function @time
    xor rax, rax        ; unsupported
    push rax            ; var end_iter
    mov rax, [rbp - 56]  ; load end_iter
    push rax
    mov rax, [rbp - 40]  ; load start_iter
    mov rbx, rax
    pop rax
    sub rax, rbx
    push rax            ; var time_iter
    lea rax, [rel .STR24]
section .data
.STR24: db 0x52, 0x65, 0x63, 0x75, 0x72, 0x73, 0x69, 0x76, 0x65, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L25:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L27
    cmp byte [rsi], 0
    je .L26
    inc rdx
    inc rsi
    jmp .L25
.L27:
    mov rdx, 0          ; truncate to 0 on overflow
.L26:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load result_rec
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR28]
section .data
.STR28: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L29:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L31
    cmp byte [rsi], 0
    je .L30
    inc rdx
    inc rsi
    jmp .L29
.L31:
    mov rdx, 0          ; truncate to 0 on overflow
.L30:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR32]
section .data
.STR32: db 0x52, 0x65, 0x63, 0x75, 0x72, 0x73, 0x69, 0x76, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L33:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L35
    cmp byte [rsi], 0
    je .L34
    inc rdx
    inc rsi
    jmp .L33
.L35:
    mov rdx, 0          ; truncate to 0 on overflow
.L34:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 32]  ; load time_rec
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR36]
section .data
.STR36: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR40]
section .data
.STR40: db 0x49, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x76, 0x65, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L41:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L43
    cmp byte [rsi], 0
    je .L42
    inc rdx
    inc rsi
    jmp .L41
.L43:
    mov rdx, 0          ; truncate to 0 on overflow
.L42:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load result_iter
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR44]
section .data
.STR44: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L45:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L47
    cmp byte [rsi], 0
    je .L46
    inc rdx
    inc rsi
    jmp .L45
.L47:
    mov rdx, 0          ; truncate to 0 on overflow
.L46:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR48]
section .data
.STR48: db 0x49, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x76, 0x65, 0x20, 0x74, 0x69, 0x6d, 0x65, 0x20, 0x28, 0x6e, 0x73, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L49:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L51
    cmp byte [rsi], 0
    je .L50
    inc rdx
    inc rsi
    jmp .L49
.L51:
    mov rdx, 0          ; truncate to 0 on overflow
.L50:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load time_iter
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR52]
section .data
.STR52: db 0x0a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L53:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L55
    cmp byte [rsi], 0
    je .L54
    inc rdx
    inc rsi
    jmp .L53
.L55:
    mov rdx, 0          ; truncate to 0 on overflow
.L54:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 16]  ; load result_rec
    push rax
    mov rax, [rbp - 48]  ; load result_iter
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L56
    lea rax, [rel .STR58]
section .data
.STR58: db 0xe2, 0x9c, 0x93, 0x20, 0x50, 0x41, 0x53, 0x53, 0x3a, 0x20, 0x42, 0x6f, 0x74, 0x68, 0x20, 0x6d, 0x65, 0x74, 0x68, 0x6f, 0x64, 0x73, 0x20, 0x63, 0x6f, 0x6d, 0x70, 0x75, 0x74, 0x65, 0x20, 0x73, 0x61, 0x6d, 0x65, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L59:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L61
    cmp byte [rsi], 0
    je .L60
    inc rdx
    inc rsi
    jmp .L59
.L61:
    mov rdx, 0          ; truncate to 0 on overflow
.L60:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load time_iter
    push rax
    mov rax, [rbp - 32]  ; load time_rec
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L62
    lea rax, [rel .STR64]
section .data
.STR64: db 0xe2, 0x9c, 0x93, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x20, 0x56, 0x45, 0x52, 0x49, 0x46, 0x49, 0x45, 0x44, 0x3a, 0x20, 0x49, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x76, 0x65, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x69, 0x66, 0x69, 0x63, 0x61, 0x6e, 0x74, 0x6c, 0x79, 0x20, 0x66, 0x61, 0x73, 0x74, 0x65, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L63
.L62:
    lea rax, [rel .STR68]
section .data
.STR68: db 0xe2, 0x9c, 0x97, 0x20, 0x4e, 0x4f, 0x20, 0x43, 0x4c, 0x45, 0x41, 0x52, 0x20, 0x4f, 0x50, 0x54, 0x49, 0x4d, 0x49, 0x5a, 0x41, 0x54, 0x49, 0x4f, 0x4e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L63:
    jmp .L57
.L56:
    lea rax, [rel .STR72]
section .data
.STR72: db 0xe2, 0x9c, 0x97, 0x20, 0x46, 0x41, 0x49, 0x4c, 0x3a, 0x20, 0x52, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73, 0x20, 0x64, 0x69, 0x66, 0x66, 0x65, 0x72, 0x21, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L57:
    add rsp, 64         ; pop 8 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
