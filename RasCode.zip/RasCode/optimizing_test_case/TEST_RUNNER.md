// TEST RUNNER: Master Optimization Test Suite
// Purpose: Execute all optimization tests and report results
// Instructions: Compile and run this to verify all optimizations

show["====================================\n"];
show["RasCode Optimization Test Suite\n"];
show["====================================\n\n"];

show["This directory contains 8 optimization test files:\n"];
show["01. String Operations (fast string search)\n"];
show["02. Function Call Overhead (inline vs functions)\n"];
show["03. Array Access Patterns (row-major vs column-major)\n"];
show["04. Fibonacci Optimization (recursive vs iterative)\n"];
show["05. Binary Search (binary vs linear search)\n"];
show["06. Loop Unrolling (unrolled vs simple loops)\n"];
show["07. Strength Reduction (shift vs multiply)\n"];
show["08. Early Loop Exit (early returns)\n\n"];

show["How to Run Tests:\n"];
show["================\n"];
show["cd /home/void/Desktop/RASIDE/RasCode/optimizing_test_case\n"];
show["rascom 01_string_operations.ras\n"];
show["rascom 02_function_call_overhead.ras\n"];
show["... and so on\n\n"];

show["Each test will:\n"];
show["1. Initialize test data\n"];
show["2. Run optimized version\n"];
show["3. Run unoptimized version\n"];
show["4. Compare results for correctness\n"];
show["5. Compare timing (if measurable)\n"];
show["6. Print PASS/FAIL verdict\n\n"];

show["Expected Results:\n"];
show["=================\n"];
show["✓ All should PASS (same correctness)\n"];
show["✓ Most should show optimization benefits\n"];
show["✗ Some may show no timing difference (code too simple/fast)\n"];
show["✗ Time precision depends on system resolution\n\n"];

show["Notes:\n"];
show["======\n"];
show["- Tests use @time[] to measure nanoseconds\n"];
show["- Timing differences may be small for simple operations\n"];
show["- Run multiple times for consistency\n"];
show["- See 29-OPTIMIZATION-GUIDE.md for detailed explanations\n"];

fnc main[]::int {
    show["Test runner ready.\n"];
    show["Run individual test files listed above.\n"];
    get[0];
}
