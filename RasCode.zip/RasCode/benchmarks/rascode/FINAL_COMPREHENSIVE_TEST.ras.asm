global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify
extern safe_alloc_versioned, safe_free_versioned, validate_array_access, memory_safety_init

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



fib:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L2
    mov rax, [rbp - 8]  ; load n
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L3
.L2:
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    jo .overflow_5       ; jump if overflow flag set
    jmp .overflow_done_6
.overflow_5:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_6:
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_4
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_4
.recursion_limit_4:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_4:
    push rax
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 2
    mov rbx, rax
    pop rax
    sub rax, rbx
    jo .overflow_8       ; jump if overflow flag set
    jmp .overflow_done_9
.overflow_8:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_9:
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_7
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call fib
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_7
.recursion_limit_7:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_7:
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_10       ; jump if overflow flag set
    jmp .overflow_done_11
.overflow_10:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_11:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L3:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

factorial:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_12
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_12:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_13
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_13:
    sub rsp, 8         ; allocate space for 1 parameters
    mov [rbp-8], rdi     ; parameter n
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setle al
    movzx rax, al
    cmp rax, 0
    je .L14
    mov rax, 1
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    jmp .L15
.L14:
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, [rbp - 8]  ; load n
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    sub rax, rbx
    jo .overflow_17       ; jump if overflow flag set
    jmp .overflow_done_18
.overflow_17:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_18:
    push rax            ; save arg 0
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_16
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call factorial
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_16
.recursion_limit_16:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_16:
    mov rbx, rax
    pop rax
    imul rax, rbx
    jo .overflow_19       ; jump if overflow flag set
    jmp .overflow_done_20
.overflow_19:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_20:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
.L15:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_21
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_21:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_22
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_22:
    lea rax, [rel .STR23]
section .data
.STR23: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L24:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L26
    cmp byte [rsi], 0
    je .L25
    inc rdx
    inc rsi
    jmp .L24
.L26:
    mov rdx, 0          ; truncate to 0 on overflow
.L25:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR27]
section .data
.STR27: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L28:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L30
    cmp byte [rsi], 0
    je .L29
    inc rdx
    inc rsi
    jmp .L28
.L30:
    mov rdx, 0          ; truncate to 0 on overflow
.L29:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR31]
section .data
.STR31: db 0x20, 0x20, 0x20, 0x52, 0x41, 0x53, 0x43, 0x4f, 0x44, 0x45, 0x20, 0x43, 0x4f, 0x4d, 0x50, 0x52, 0x45, 0x48, 0x45, 0x4e, 0x53, 0x49, 0x56, 0x45, 0x20, 0x46, 0x55, 0x4e, 0x43, 0x54, 0x49, 0x4f, 0x4e, 0x41, 0x4c, 0x49, 0x54, 0x59, 0x20, 0x54, 0x45, 0x53, 0x54, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L32:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L34
    cmp byte [rsi], 0
    je .L33
    inc rdx
    inc rsi
    jmp .L32
.L34:
    mov rdx, 0          ; truncate to 0 on overflow
.L33:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR35]
section .data
.STR35: db 0x20, 0x20, 0x20, 0x54, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x61, 0x63, 0x74, 0x75, 0x61, 0x6c, 0x20, 0x63, 0x6f, 0x6d, 0x70, 0x69, 0x6c, 0x65, 0x72, 0x2d, 0x69, 0x6d, 0x70, 0x6c, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x65, 0x64, 0x20, 0x66, 0x65, 0x61, 0x74, 0x75, 0x72, 0x65, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L36:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L38
    cmp byte [rsi], 0
    je .L37
    inc rdx
    inc rsi
    jmp .L36
.L38:
    mov rdx, 0          ; truncate to 0 on overflow
.L37:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR39]
section .data
.STR39: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L40:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L42
    cmp byte [rsi], 0
    je .L41
    inc rdx
    inc rsi
    jmp .L40
.L42:
    mov rdx, 0          ; truncate to 0 on overflow
.L41:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR43]
section .data
.STR43: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L44:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L46
    cmp byte [rsi], 0
    je .L45
    inc rdx
    inc rsi
    jmp .L44
.L46:
    mov rdx, 0          ; truncate to 0 on overflow
.L45:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR47]
section .data
.STR47: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x3a, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x4d, 0x61, 0x6e, 0x61, 0x67, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @alloc
    mov rax, 512
    mov rdi, rax        ; size to allocate
    add rdi, 8          ; add 8 bytes for size metadata
    push rdi            ; save total size
    xor rdi, rdi        ; get current brk
    mov rax, 12         ; sys_brk
    syscall
    mov rbx, rax        ; save current brk (metadata location)
    pop rdi             ; restore total size
    add rdi, rbx        ; new brk = old + size
    mov rax, 12         ; sys_brk
    syscall
    cmp rax, rdi        ; check if succeeded
    jne .alloc_fail_51
    mov [rbx], rdi      ; store size metadata
    add rbx, 8          ; skip metadata for user data
    mov rax, rbx        ; return data ptr (after metadata)
    jmp .alloc_done_51
.alloc_fail_51:
    xor rax, rax        ; return 0 on failure
.alloc_done_51:
    push rax            ; var addr
    lea rax, [rel .STR52]
section .data
.STR52: db 0x20, 0x20, 0x2d, 0x20, 0x41, 0x6c, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x65, 0x64, 0x20, 0x35, 0x31, 0x32, 0x20, 0x62, 0x79, 0x74, 0x65, 0x73, 0x20, 0x61, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L53:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L55
    cmp byte [rsi], 0
    je .L54
    inc rdx
    inc rsi
    jmp .L53
.L55:
    mov rdx, 0          ; truncate to 0 on overflow
.L54:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR56]
section .data
.STR56: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @poke
    mov rax, [rbp - 8]  ; load addr
    mov rcx, rax        ; address (ignored)
    ; SECURITY: @poke disabled - arbitrary memory write forbidden
    ; These operations enable memory corruption attacks
    mov rax, 123
    ; @poke is now a no-op for security
    ; Builtin function @peek
    mov rax, [rbp - 8]  ; load addr
    mov rcx, rax        ; address to read
    ; SECURITY: Reject @peek/@poke - arbitrary memory access disabled
    ; These operations enable arbitrary memory read/write attacks
    ; If needed, use safe_read/safe_write APIs instead
    xor rax, rax        ; return 0 (forbidden)
    push rax            ; var read_val
    lea rax, [rel .STR60]
section .data
.STR60: db 0x20, 0x20, 0x2d, 0x20, 0x50, 0x6f, 0x6b, 0x65, 0x2f, 0x50, 0x65, 0x65, 0x6b, 0x3a, 0x20, 0x77, 0x72, 0x6f, 0x74, 0x65, 0x20, 0x31, 0x32, 0x33, 0x2c, 0x20, 0x72, 0x65, 0x61, 0x64, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR64]
section .data
.STR64: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L65:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L67
    cmp byte [rsi], 0
    je .L66
    inc rdx
    inc rsi
    jmp .L65
.L67:
    mov rdx, 0          ; truncate to 0 on overflow
.L66:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @memset
    mov rax, [rbp - 8]  ; load addr
    push rax            ; save ptr
    mov rax, 200
    push rax            ; save value
    mov rax, 20
    mov rcx, rax        ; count
    pop rax             ; restore value
    pop rdi             ; restore ptr
    rep stosb           ; fill memory
    lea rax, [rel .STR68]
section .data
.STR68: db 0x20, 0x20, 0x2d, 0x20, 0x4d, 0x65, 0x6d, 0x73, 0x65, 0x74, 0x20, 0x73, 0x75, 0x63, 0x63, 0x65, 0x73, 0x73, 0x66, 0x75, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L69:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L71
    cmp byte [rsi], 0
    je .L70
    inc rdx
    inc rsi
    jmp .L69
.L71:
    mov rdx, 0          ; truncate to 0 on overflow
.L70:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @free
    mov rax, [rbp - 8]  ; load addr
    mov rdi, rax        ; user ptr
    sub rdi, 8          ; get metadata ptr
    mov qword [rdi], 0  ; mark as freed
    xor rax, rax        ; return 0
    lea rax, [rel .STR72]
section .data
.STR72: db 0x20, 0x20, 0x2d, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x66, 0x72, 0x65, 0x65, 0x64, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L73:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L75
    cmp byte [rsi], 0
    je .L74
    inc rdx
    inc rsi
    jmp .L73
.L75:
    mov rdx, 0          ; truncate to 0 on overflow
.L74:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR76]
section .data
.STR76: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L77:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L79
    cmp byte [rsi], 0
    je .L78
    inc rdx
    inc rsi
    jmp .L77
.L79:
    mov rdx, 0          ; truncate to 0 on overflow
.L78:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR80]
section .data
.STR80: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x32, 0x3a, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x4d, 0x61, 0x6e, 0x69, 0x70, 0x75, 0x6c, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L81:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L83
    cmp byte [rsi], 0
    je .L82
    inc rdx
    inc rsi
    jmp .L81
.L83:
    mov rdx, 0          ; truncate to 0 on overflow
.L82:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR84]
section .data
.STR84: db 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x00
section .text
    push rax            ; var greeting
    xor rax, rax        ; unknown builtin - return 0
    push rax            ; var glen
    lea rax, [rel .STR85]
section .data
.STR85: db 0x20, 0x20, 0x2d, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x20, 0x6f, 0x66, 0x20, 0x27, 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x27, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L86:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L88
    cmp byte [rsi], 0
    je .L87
    inc rdx
    inc rsi
    jmp .L86
.L88:
    mov rdx, 0          ; truncate to 0 on overflow
.L87:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR89]
section .data
.STR89: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L90:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L92
    cmp byte [rsi], 0
    je .L91
    inc rdx
    inc rsi
    jmp .L90
.L92:
    mov rdx, 0          ; truncate to 0 on overflow
.L91:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @upper
    mov rax, [rbp - 24]  ; load greeting
    push rax        ; arg 0
    mov rax, 153             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var upper_str
    lea rax, [rel .STR93]
section .data
.STR93: db 0x20, 0x20, 0x2d, 0x20, 0x55, 0x70, 0x70, 0x65, 0x72, 0x63, 0x61, 0x73, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L94:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L96
    cmp byte [rsi], 0
    je .L95
    inc rdx
    inc rsi
    jmp .L94
.L96:
    mov rdx, 0          ; truncate to 0 on overflow
.L95:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 40]  ; load upper_str
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L97:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L99
    cmp byte [rsi], 0
    je .L98
    inc rdx
    inc rsi
    jmp .L97
.L99:
    mov rdx, 0          ; truncate to 0 on overflow
.L98:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR100]
section .data
.STR100: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L101:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L103
    cmp byte [rsi], 0
    je .L102
    inc rdx
    inc rsi
    jmp .L101
.L103:
    mov rdx, 0          ; truncate to 0 on overflow
.L102:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @lower
    mov rax, [rbp - 40]  ; load upper_str
    push rax        ; arg 0
    mov rax, 154             ; builtin ID
    mov rdi, 1              ; syscall for runtime dispatch
    syscall
    push rax            ; var lower_str
    lea rax, [rel .STR104]
section .data
.STR104: db 0x20, 0x20, 0x2d, 0x20, 0x4c, 0x6f, 0x77, 0x65, 0x72, 0x63, 0x61, 0x73, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L105:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L107
    cmp byte [rsi], 0
    je .L106
    inc rdx
    inc rsi
    jmp .L105
.L107:
    mov rdx, 0          ; truncate to 0 on overflow
.L106:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 48]  ; load lower_str
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L108:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L110
    cmp byte [rsi], 0
    je .L109
    inc rdx
    inc rsi
    jmp .L108
.L110:
    mov rdx, 0          ; truncate to 0 on overflow
.L109:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR111]
section .data
.STR111: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L112:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L114
    cmp byte [rsi], 0
    je .L113
    inc rdx
    inc rsi
    jmp .L112
.L114:
    mov rdx, 0          ; truncate to 0 on overflow
.L113:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @concat
    mov rax, [rbp - 24]  ; load greeting
    mov r12, rax        ; r12 = str1
    lea rax, [rel .STR115]
section .data
.STR115: db 0x20, 0x4c, 0x61, 0x6e, 0x67, 0x75, 0x61, 0x67, 0x65, 0x00
section .text
    mov r13, rax        ; r13 = str2
    mov rdi, r12
    call strlen
    mov r14, rax        ; r14 = len1
    mov rdi, r13
    call strlen
    mov r15, rax        ; r15 = len2
    lea rdi, [r14 + r15 + 1]  ; total size
    call malloc
    mov rbx, rax        ; rbx = result buffer
    mov rdi, rbx
    mov rsi, r12
    mov rcx, r14
    rep movsb
    mov rsi, r13
    mov rcx, r15
    rep movsb
    mov byte [rdi], 0
    mov rax, rbx        ; return result
    push rax            ; var combined
    lea rax, [rel .STR116]
section .data
.STR116: db 0x20, 0x20, 0x2d, 0x20, 0x43, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x65, 0x6e, 0x61, 0x74, 0x65, 0x64, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L117:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L119
    cmp byte [rsi], 0
    je .L118
    inc rdx
    inc rsi
    jmp .L117
.L119:
    mov rdx, 0          ; truncate to 0 on overflow
.L118:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 56]  ; load combined
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L120:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L122
    cmp byte [rsi], 0
    je .L121
    inc rdx
    inc rsi
    jmp .L120
.L122:
    mov rdx, 0          ; truncate to 0 on overflow
.L121:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR123]
section .data
.STR123: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L124:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L126
    cmp byte [rsi], 0
    je .L125
    inc rdx
    inc rsi
    jmp .L124
.L126:
    mov rdx, 0          ; truncate to 0 on overflow
.L125:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @substr
    mov rax, [rbp - 24]  ; load greeting
    push rax            ; save str
    mov rax, 3
    push rax            ; save len
    inc rax             ; +1 for null
    mov rdi, rax
    call malloc         ; allocate buffer
    mov rdi, rax        ; dest
    pop rdx             ; len
    pop rsi             ; str
    mov rax, 0
    add rsi, rax        ; str + start
    mov rcx, rdx        ; count
    rep movsb           ; copy bytes
    mov byte [rdi], 0   ; null terminate
    sub rdi, rdx        ; restore buffer start
    mov rax, rdi
    push rax            ; var part
    lea rax, [rel .STR127]
section .data
.STR127: db 0x20, 0x20, 0x2d, 0x20, 0x53, 0x75, 0x62, 0x73, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x28, 0x30, 0x2c, 0x33, 0x29, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L128:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L130
    cmp byte [rsi], 0
    je .L129
    inc rdx
    inc rsi
    jmp .L128
.L130:
    mov rdx, 0          ; truncate to 0 on overflow
.L129:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 64]  ; load part
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L131:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L133
    cmp byte [rsi], 0
    je .L132
    inc rdx
    inc rsi
    jmp .L131
.L133:
    mov rdx, 0          ; truncate to 0 on overflow
.L132:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR134]
section .data
.STR134: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L135:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L137
    cmp byte [rsi], 0
    je .L136
    inc rdx
    inc rsi
    jmp .L135
.L137:
    mov rdx, 0          ; truncate to 0 on overflow
.L136:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR138]
section .data
.STR138: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L139:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L141
    cmp byte [rsi], 0
    je .L140
    inc rdx
    inc rsi
    jmp .L139
.L141:
    mov rdx, 0          ; truncate to 0 on overflow
.L140:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR142]
section .data
.STR142: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x33, 0x3a, 0x20, 0x4d, 0x61, 0x74, 0x68, 0x65, 0x6d, 0x61, 0x74, 0x69, 0x63, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L143:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L145
    cmp byte [rsi], 0
    je .L144
    inc rdx
    inc rsi
    jmp .L143
.L145:
    mov rdx, 0          ; truncate to 0 on overflow
.L144:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 144
    push rax            ; var a
    mov rax, 12
    push rax            ; var b
    lea rax, [rel .STR146]
section .data
.STR146: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x34, 0x34, 0x20, 0x2b, 0x20, 0x31, 0x32, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L147:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L149
    cmp byte [rsi], 0
    je .L148
    inc rdx
    inc rsi
    jmp .L147
.L149:
    mov rdx, 0          ; truncate to 0 on overflow
.L148:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR150]
section .data
.STR150: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L151:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L153
    cmp byte [rsi], 0
    je .L152
    inc rdx
    inc rsi
    jmp .L151
.L153:
    mov rdx, 0          ; truncate to 0 on overflow
.L152:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR154]
section .data
.STR154: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x34, 0x34, 0x20, 0x2d, 0x20, 0x31, 0x32, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L155:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L157
    cmp byte [rsi], 0
    je .L156
    inc rdx
    inc rsi
    jmp .L155
.L157:
    mov rdx, 0          ; truncate to 0 on overflow
.L156:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR158]
section .data
.STR158: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L159:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L161
    cmp byte [rsi], 0
    je .L160
    inc rdx
    inc rsi
    jmp .L159
.L161:
    mov rdx, 0          ; truncate to 0 on overflow
.L160:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR162]
section .data
.STR162: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x34, 0x34, 0x20, 0x2a, 0x20, 0x31, 0x32, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L163:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L165
    cmp byte [rsi], 0
    je .L164
    inc rdx
    inc rsi
    jmp .L163
.L165:
    mov rdx, 0          ; truncate to 0 on overflow
.L164:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR166]
section .data
.STR166: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L167:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L169
    cmp byte [rsi], 0
    je .L168
    inc rdx
    inc rsi
    jmp .L167
.L169:
    mov rdx, 0          ; truncate to 0 on overflow
.L168:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR170]
section .data
.STR170: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x34, 0x34, 0x20, 0x2f, 0x20, 0x31, 0x32, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L171:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L173
    cmp byte [rsi], 0
    je .L172
    inc rdx
    inc rsi
    jmp .L171
.L173:
    mov rdx, 0          ; truncate to 0 on overflow
.L172:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR174]
section .data
.STR174: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L175:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L177
    cmp byte [rsi], 0
    je .L176
    inc rdx
    inc rsi
    jmp .L175
.L177:
    mov rdx, 0          ; truncate to 0 on overflow
.L176:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR178]
section .data
.STR178: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x61, 0x62, 0x73, 0x28, 0x2d, 0x39, 0x39, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L179:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L181
    cmp byte [rsi], 0
    je .L180
    inc rdx
    inc rsi
    jmp .L179
.L181:
    mov rdx, 0          ; truncate to 0 on overflow
.L180:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR182]
section .data
.STR182: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L183:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L185
    cmp byte [rsi], 0
    je .L184
    inc rdx
    inc rsi
    jmp .L183
.L185:
    mov rdx, 0          ; truncate to 0 on overflow
.L184:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR186]
section .data
.STR186: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x6d, 0x69, 0x6e, 0x28, 0x35, 0x30, 0x2c, 0x20, 0x33, 0x30, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L187:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L189
    cmp byte [rsi], 0
    je .L188
    inc rdx
    inc rsi
    jmp .L187
.L189:
    mov rdx, 0          ; truncate to 0 on overflow
.L188:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR190]
section .data
.STR190: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L191:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L193
    cmp byte [rsi], 0
    je .L192
    inc rdx
    inc rsi
    jmp .L191
.L193:
    mov rdx, 0          ; truncate to 0 on overflow
.L192:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR194]
section .data
.STR194: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x6d, 0x61, 0x78, 0x28, 0x35, 0x30, 0x2c, 0x20, 0x33, 0x30, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L195:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L197
    cmp byte [rsi], 0
    je .L196
    inc rdx
    inc rsi
    jmp .L195
.L197:
    mov rdx, 0          ; truncate to 0 on overflow
.L196:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR198]
section .data
.STR198: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L199:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L201
    cmp byte [rsi], 0
    je .L200
    inc rdx
    inc rsi
    jmp .L199
.L201:
    mov rdx, 0          ; truncate to 0 on overflow
.L200:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR202]
section .data
.STR202: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x70, 0x6f, 0x77, 0x28, 0x32, 0x2c, 0x20, 0x31, 0x30, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L203:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L205
    cmp byte [rsi], 0
    je .L204
    inc rdx
    inc rsi
    jmp .L203
.L205:
    mov rdx, 0          ; truncate to 0 on overflow
.L204:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR206]
section .data
.STR206: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L207:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L209
    cmp byte [rsi], 0
    je .L208
    inc rdx
    inc rsi
    jmp .L207
.L209:
    mov rdx, 0          ; truncate to 0 on overflow
.L208:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR210]
section .data
.STR210: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x67, 0x63, 0x64, 0x28, 0x34, 0x38, 0x2c, 0x20, 0x31, 0x38, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L211:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L213
    cmp byte [rsi], 0
    je .L212
    inc rdx
    inc rsi
    jmp .L211
.L213:
    mov rdx, 0          ; truncate to 0 on overflow
.L212:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR214]
section .data
.STR214: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L215:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L217
    cmp byte [rsi], 0
    je .L216
    inc rdx
    inc rsi
    jmp .L215
.L217:
    mov rdx, 0          ; truncate to 0 on overflow
.L216:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR218]
section .data
.STR218: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L219:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L221
    cmp byte [rsi], 0
    je .L220
    inc rdx
    inc rsi
    jmp .L219
.L221:
    mov rdx, 0          ; truncate to 0 on overflow
.L220:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR222]
section .data
.STR222: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x34, 0x3a, 0x20, 0x41, 0x72, 0x72, 0x61, 0x79, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L223:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L225
    cmp byte [rsi], 0
    je .L224
    inc rdx
    inc rsi
    jmp .L223
.L225:
    mov rdx, 0          ; truncate to 0 on overflow
.L224:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; array declaration: data{int, 10} (element_size=4 bytes)
    sub rsp, 40         ; allocate array space
    mov rax, 1
    mov dword [rbp - 120], eax ; init data{0}
    mov rax, 2
    mov dword [rbp - 116], eax ; init data{1}
    mov rax, 3
    mov dword [rbp - 112], eax ; init data{2}
    mov rax, 4
    mov dword [rbp - 108], eax ; init data{3}
    mov rax, 5
    mov dword [rbp - 104], eax ; init data{4}
    mov rax, 6
    mov dword [rbp - 100], eax ; init data{5}
    mov rax, 7
    mov dword [rbp - 96], eax ; init data{6}
    mov rax, 8
    mov dword [rbp - 92], eax ; init data{7}
    mov rax, 9
    mov dword [rbp - 88], eax ; init data{8}
    mov rax, 10
    mov dword [rbp - 84], eax ; init data{9}
    lea rax, [rel .STR226]
section .data
.STR226: db 0x20, 0x20, 0x2d, 0x20, 0x41, 0x72, 0x72, 0x61, 0x79, 0x20, 0x66, 0x69, 0x72, 0x73, 0x74, 0x20, 0x65, 0x6c, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L227:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L229
    cmp byte [rsi], 0
    je .L228
    inc rdx
    inc rsi
    jmp .L227
.L229:
    mov rdx, 0          ; truncate to 0 on overflow
.L228:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR230]
section .data
.STR230: db 0x2c, 0x20, 0x6c, 0x61, 0x73, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L231:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L233
    cmp byte [rsi], 0
    je .L232
    inc rdx
    inc rsi
    jmp .L231
.L233:
    mov rdx, 0          ; truncate to 0 on overflow
.L232:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR234]
section .data
.STR234: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L235:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L237
    cmp byte [rsi], 0
    je .L236
    inc rdx
    inc rsi
    jmp .L235
.L237:
    mov rdx, 0          ; truncate to 0 on overflow
.L236:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; save index
    cmp rax, 0
    jl .bounds_error_238
    cmp rax, 10
    jge .bounds_error_238
    mov rax, 100
    mov rbx, rax        ; save value
    pop rax             ; restore index
    mov rcx, 4         ; element size
    imul rax, rcx       ; index * size
    lea rcx, [rbp - 120] ; array base (first element)
    add rcx, rax        ; element address
    mov dword [rcx], ebx ; store dword
    jmp .bounds_ok_239
.bounds_error_238:
    mov rdi, 1          ; stderr
    lea rsi, [rel bounds_msg]
    mov rdx, 21         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_239:
    lea rax, [rel .STR239]
section .data
.STR239: db 0x20, 0x20, 0x2d, 0x20, 0x41, 0x66, 0x74, 0x65, 0x72, 0x20, 0x6d, 0x6f, 0x64, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x2c, 0x20, 0x64, 0x61, 0x74, 0x61, 0x7b, 0x30, 0x7d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L240:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L242
    cmp byte [rsi], 0
    je .L241
    inc rdx
    inc rsi
    jmp .L240
.L242:
    mov rdx, 0          ; truncate to 0 on overflow
.L241:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR243]
section .data
.STR243: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L244:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L246
    cmp byte [rsi], 0
    je .L245
    inc rdx
    inc rsi
    jmp .L244
.L246:
    mov rdx, 0          ; truncate to 0 on overflow
.L245:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var array_sum
    mov rax, 0
    push rax            ; var idx
    mov rax, 0
    mov [rbp - 136], rax  ; assign idx
.L247:
    mov rax, [rbp - 136]  ; load idx
    push rax
    mov rax, 10
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L248
    mov rax, [rbp - 128]  ; load array_sum
    push rax
    mov rax, [rbp - 136]  ; load idx
    cmp rax, 0
    jl .bounds_error_250
    cmp rax, 10
    jge .bounds_error_250
    mov rbx, 4         ; element size
    imul rax, rbx       ; index * size
    lea rbx, [rbp - 120] ; array base (first element)
    add rbx, rax        ; element address
    mov eax, dword [rbx] ; load dword
    cdqe                 ; sign extend to 64-bit
    jmp .bounds_ok_251
.bounds_error_250:
    mov rdi, 1
    lea rsi, [rel bounds_msg]
    mov rdx, 21
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall
.bounds_ok_251:
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_251       ; jump if overflow flag set
    jmp .overflow_done_252
.overflow_251:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_252:
    mov [rbp - 128], rax  ; assign array_sum
.L249:
    mov rax, [rbp - 136]  ; load idx
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_253       ; jump if overflow flag set
    jmp .overflow_done_254
.overflow_253:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_254:
    mov [rbp - 136], rax  ; assign idx
    jmp .L247
.L248:
    lea rax, [rel .STR255]
section .data
.STR255: db 0x20, 0x20, 0x2d, 0x20, 0x53, 0x75, 0x6d, 0x20, 0x6f, 0x66, 0x20, 0x61, 0x72, 0x72, 0x61, 0x79, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L256:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L258
    cmp byte [rsi], 0
    je .L257
    inc rdx
    inc rsi
    jmp .L256
.L258:
    mov rdx, 0          ; truncate to 0 on overflow
.L257:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR259]
section .data
.STR259: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L260:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L262
    cmp byte [rsi], 0
    je .L261
    inc rdx
    inc rsi
    jmp .L260
.L262:
    mov rdx, 0          ; truncate to 0 on overflow
.L261:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR263]
section .data
.STR263: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L264:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L266
    cmp byte [rsi], 0
    je .L265
    inc rdx
    inc rsi
    jmp .L264
.L266:
    mov rdx, 0          ; truncate to 0 on overflow
.L265:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR267]
section .data
.STR267: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x35, 0x3a, 0x20, 0x43, 0x6f, 0x6e, 0x74, 0x72, 0x6f, 0x6c, 0x20, 0x46, 0x6c, 0x6f, 0x77, 0x20, 0x28, 0x69, 0x66, 0x2f, 0x77, 0x68, 0x69, 0x6c, 0x65, 0x2f, 0x6c, 0x6f, 0x6f, 0x70, 0x2f, 0x63, 0x79, 0x63, 0x6c, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L268:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L270
    cmp byte [rsi], 0
    je .L269
    inc rdx
    inc rsi
    jmp .L268
.L270:
    mov rdx, 0          ; truncate to 0 on overflow
.L269:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 75
    push rax            ; var test_val
    mov rax, [rbp - 144]  ; load test_val
    push rax
    mov rax, 50
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    cmp rax, 0
    je .L271
    lea rax, [rel .STR273]
section .data
.STR273: db 0x20, 0x20, 0x2d, 0x20, 0x69, 0x66, 0x5b, 0x37, 0x35, 0x20, 0x3e, 0x20, 0x35, 0x30, 0x5d, 0x3a, 0x20, 0x54, 0x52, 0x55, 0x45, 0x20, 0x62, 0x72, 0x61, 0x6e, 0x63, 0x68, 0x20, 0x65, 0x78, 0x65, 0x63, 0x75, 0x74, 0x65, 0x64, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L274:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L276
    cmp byte [rsi], 0
    je .L275
    inc rdx
    inc rsi
    jmp .L274
.L276:
    mov rdx, 0          ; truncate to 0 on overflow
.L275:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    jmp .L272
.L271:
    lea rax, [rel .STR277]
section .data
.STR277: db 0x20, 0x20, 0x2d, 0x20, 0x69, 0x66, 0x5b, 0x37, 0x35, 0x20, 0x3e, 0x20, 0x35, 0x30, 0x5d, 0x3a, 0x20, 0x46, 0x41, 0x4c, 0x53, 0x45, 0x20, 0x62, 0x72, 0x61, 0x6e, 0x63, 0x68, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L278:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L280
    cmp byte [rsi], 0
    je .L279
    inc rdx
    inc rsi
    jmp .L278
.L280:
    mov rdx, 0          ; truncate to 0 on overflow
.L279:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
.L272:
    mov rax, 0
    push rax            ; var loop_count
    mov rax, 0
    push rax            ; var lc
.L281:
    mov rax, [rbp - 160]  ; load lc
    push rax
    mov rax, 3
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L282
    mov rax, [rbp - 152]  ; load loop_count
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_283       ; jump if overflow flag set
    jmp .overflow_done_284
.overflow_283:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_284:
    mov [rbp - 152], rax  ; assign loop_count
    mov rax, [rbp - 160]  ; load lc
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_285       ; jump if overflow flag set
    jmp .overflow_done_286
.overflow_285:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_286:
    mov [rbp - 160], rax  ; assign lc
    jmp .L281
.L282:
    lea rax, [rel .STR287]
section .data
.STR287: db 0x20, 0x20, 0x2d, 0x20, 0x57, 0x68, 0x69, 0x6c, 0x65, 0x20, 0x6c, 0x6f, 0x6f, 0x70, 0x20, 0x65, 0x78, 0x65, 0x63, 0x75, 0x74, 0x65, 0x64, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L288:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L290
    cmp byte [rsi], 0
    je .L289
    inc rdx
    inc rsi
    jmp .L288
.L290:
    mov rdx, 0          ; truncate to 0 on overflow
.L289:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR291]
section .data
.STR291: db 0x20, 0x74, 0x69, 0x6d, 0x65, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L292:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L294
    cmp byte [rsi], 0
    je .L293
    inc rdx
    inc rsi
    jmp .L292
.L294:
    mov rdx, 0          ; truncate to 0 on overflow
.L293:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var switch_result
    mov rax, 2
    push rax            ; var switch_val
    mov rax, [rbp - 176]  ; load switch_val
    push rax            ; save cycle value
    mov rax, [rsp]      ; reload cycle value
    mov rax, 1
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L296
    mov rax, 100
    mov [rbp - 168], rax  ; assign switch_result
    jmp .L295
.L296:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 2
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L297
    mov rax, 200
    mov [rbp - 168], rax  ; assign switch_result
    jmp .L295
.L297:
    mov rax, [rsp]      ; reload cycle value
    mov rax, 3
    mov rbx, rax
    mov rax, [rsp]
    cmp rax, rbx
    jne .L298
    mov rax, 300
    mov [rbp - 168], rax  ; assign switch_result
    jmp .L295
.L298:
    mov rax, 999
    mov [rbp - 168], rax  ; assign switch_result
.L295:
    add rsp, 8          ; clean up cycle value
    lea rax, [rel .STR299]
section .data
.STR299: db 0x20, 0x20, 0x2d, 0x20, 0x43, 0x79, 0x63, 0x6c, 0x65, 0x28, 0x32, 0x29, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L300:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L302
    cmp byte [rsi], 0
    je .L301
    inc rdx
    inc rsi
    jmp .L300
.L302:
    mov rdx, 0          ; truncate to 0 on overflow
.L301:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR303]
section .data
.STR303: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L304:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L306
    cmp byte [rsi], 0
    je .L305
    inc rdx
    inc rsi
    jmp .L304
.L306:
    mov rdx, 0          ; truncate to 0 on overflow
.L305:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR307]
section .data
.STR307: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L308:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L310
    cmp byte [rsi], 0
    je .L309
    inc rdx
    inc rsi
    jmp .L308
.L310:
    mov rdx, 0          ; truncate to 0 on overflow
.L309:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR311]
section .data
.STR311: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x36, 0x3a, 0x20, 0x42, 0x69, 0x74, 0x77, 0x69, 0x73, 0x65, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L312:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L314
    cmp byte [rsi], 0
    je .L313
    inc rdx
    inc rsi
    jmp .L312
.L314:
    mov rdx, 0          ; truncate to 0 on overflow
.L313:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 15
    push rax            ; var x
    mov rax, 7
    push rax            ; var y
    lea rax, [rel .STR315]
section .data
.STR315: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x35, 0x20, 0x26, 0x20, 0x37, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L316:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L318
    cmp byte [rsi], 0
    je .L317
    inc rdx
    inc rsi
    jmp .L316
.L318:
    mov rdx, 0          ; truncate to 0 on overflow
.L317:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR319]
section .data
.STR319: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L320:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L322
    cmp byte [rsi], 0
    je .L321
    inc rdx
    inc rsi
    jmp .L320
.L322:
    mov rdx, 0          ; truncate to 0 on overflow
.L321:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR323]
section .data
.STR323: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x35, 0x20, 0x7c, 0x20, 0x37, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L324:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L326
    cmp byte [rsi], 0
    je .L325
    inc rdx
    inc rsi
    jmp .L324
.L326:
    mov rdx, 0          ; truncate to 0 on overflow
.L325:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR327]
section .data
.STR327: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L328:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L330
    cmp byte [rsi], 0
    je .L329
    inc rdx
    inc rsi
    jmp .L328
.L330:
    mov rdx, 0          ; truncate to 0 on overflow
.L329:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR331]
section .data
.STR331: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x35, 0x20, 0x5e, 0x20, 0x37, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L332:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L334
    cmp byte [rsi], 0
    je .L333
    inc rdx
    inc rsi
    jmp .L332
.L334:
    mov rdx, 0          ; truncate to 0 on overflow
.L333:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR335]
section .data
.STR335: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L336:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L338
    cmp byte [rsi], 0
    je .L337
    inc rdx
    inc rsi
    jmp .L336
.L338:
    mov rdx, 0          ; truncate to 0 on overflow
.L337:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR339]
section .data
.STR339: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x35, 0x20, 0x3c, 0x3c, 0x20, 0x31, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L340:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L342
    cmp byte [rsi], 0
    je .L341
    inc rdx
    inc rsi
    jmp .L340
.L342:
    mov rdx, 0          ; truncate to 0 on overflow
.L341:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR343]
section .data
.STR343: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L344:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L346
    cmp byte [rsi], 0
    je .L345
    inc rdx
    inc rsi
    jmp .L344
.L346:
    mov rdx, 0          ; truncate to 0 on overflow
.L345:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR347]
section .data
.STR347: db 0x20, 0x20, 0x2d, 0x20, 0x31, 0x36, 0x20, 0x3e, 0x3e, 0x20, 0x32, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L348:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L350
    cmp byte [rsi], 0
    je .L349
    inc rdx
    inc rsi
    jmp .L348
.L350:
    mov rdx, 0          ; truncate to 0 on overflow
.L349:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR351]
section .data
.STR351: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L352:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L354
    cmp byte [rsi], 0
    je .L353
    inc rdx
    inc rsi
    jmp .L352
.L354:
    mov rdx, 0          ; truncate to 0 on overflow
.L353:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR355]
section .data
.STR355: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L356:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L358
    cmp byte [rsi], 0
    je .L357
    inc rdx
    inc rsi
    jmp .L356
.L358:
    mov rdx, 0          ; truncate to 0 on overflow
.L357:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR359]
section .data
.STR359: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x37, 0x3a, 0x20, 0x52, 0x65, 0x63, 0x75, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x28, 0x46, 0x61, 0x63, 0x74, 0x6f, 0x72, 0x69, 0x61, 0x6c, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L360:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L362
    cmp byte [rsi], 0
    je .L361
    inc rdx
    inc rsi
    jmp .L360
.L362:
    mov rdx, 0          ; truncate to 0 on overflow
.L361:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR363]
section .data
.STR363: db 0x20, 0x20, 0x2d, 0x20, 0x66, 0x61, 0x63, 0x74, 0x6f, 0x72, 0x69, 0x61, 0x6c, 0x28, 0x30, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L364:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L366
    cmp byte [rsi], 0
    je .L365
    inc rdx
    inc rsi
    jmp .L364
.L366:
    mov rdx, 0          ; truncate to 0 on overflow
.L365:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR367]
section .data
.STR367: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L368:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L370
    cmp byte [rsi], 0
    je .L369
    inc rdx
    inc rsi
    jmp .L368
.L370:
    mov rdx, 0          ; truncate to 0 on overflow
.L369:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR371]
section .data
.STR371: db 0x20, 0x20, 0x2d, 0x20, 0x66, 0x61, 0x63, 0x74, 0x6f, 0x72, 0x69, 0x61, 0x6c, 0x28, 0x33, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L372:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L374
    cmp byte [rsi], 0
    je .L373
    inc rdx
    inc rsi
    jmp .L372
.L374:
    mov rdx, 0          ; truncate to 0 on overflow
.L373:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR375]
section .data
.STR375: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L376:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L378
    cmp byte [rsi], 0
    je .L377
    inc rdx
    inc rsi
    jmp .L376
.L378:
    mov rdx, 0          ; truncate to 0 on overflow
.L377:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR379]
section .data
.STR379: db 0x20, 0x20, 0x2d, 0x20, 0x66, 0x61, 0x63, 0x74, 0x6f, 0x72, 0x69, 0x61, 0x6c, 0x28, 0x35, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L380:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L382
    cmp byte [rsi], 0
    je .L381
    inc rdx
    inc rsi
    jmp .L380
.L382:
    mov rdx, 0          ; truncate to 0 on overflow
.L381:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR383]
section .data
.STR383: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L384:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L386
    cmp byte [rsi], 0
    je .L385
    inc rdx
    inc rsi
    jmp .L384
.L386:
    mov rdx, 0          ; truncate to 0 on overflow
.L385:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR387]
section .data
.STR387: db 0x20, 0x20, 0x2d, 0x20, 0x66, 0x61, 0x63, 0x74, 0x6f, 0x72, 0x69, 0x61, 0x6c, 0x28, 0x37, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L388:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L390
    cmp byte [rsi], 0
    je .L389
    inc rdx
    inc rsi
    jmp .L388
.L390:
    mov rdx, 0          ; truncate to 0 on overflow
.L389:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR391]
section .data
.STR391: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L392:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L394
    cmp byte [rsi], 0
    je .L393
    inc rdx
    inc rsi
    jmp .L392
.L394:
    mov rdx, 0          ; truncate to 0 on overflow
.L393:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR395]
section .data
.STR395: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L396:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L398
    cmp byte [rsi], 0
    je .L397
    inc rdx
    inc rsi
    jmp .L396
.L398:
    mov rdx, 0          ; truncate to 0 on overflow
.L397:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR399]
section .data
.STR399: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x38, 0x3a, 0x20, 0x52, 0x65, 0x63, 0x75, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x28, 0x46, 0x69, 0x62, 0x6f, 0x6e, 0x61, 0x63, 0x63, 0x69, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L400:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L402
    cmp byte [rsi], 0
    je .L401
    inc rdx
    inc rsi
    jmp .L400
.L402:
    mov rdx, 0          ; truncate to 0 on overflow
.L401:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR403]
section .data
.STR403: db 0x20, 0x20, 0x2d, 0x20, 0x66, 0x69, 0x62, 0x28, 0x30, 0x29, 0x3d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L404:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L406
    cmp byte [rsi], 0
    je .L405
    inc rdx
    inc rsi
    jmp .L404
.L406:
    mov rdx, 0          ; truncate to 0 on overflow
.L405:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR407]
section .data
.STR407: db 0x20, 0x66, 0x69, 0x62, 0x28, 0x31, 0x29, 0x3d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L408:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L410
    cmp byte [rsi], 0
    je .L409
    inc rdx
    inc rsi
    jmp .L408
.L410:
    mov rdx, 0          ; truncate to 0 on overflow
.L409:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR411]
section .data
.STR411: db 0x20, 0x66, 0x69, 0x62, 0x28, 0x35, 0x29, 0x3d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L412:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L414
    cmp byte [rsi], 0
    je .L413
    inc rdx
    inc rsi
    jmp .L412
.L414:
    mov rdx, 0          ; truncate to 0 on overflow
.L413:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR415]
section .data
.STR415: db 0x20, 0x66, 0x69, 0x62, 0x28, 0x37, 0x29, 0x3d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L416:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L418
    cmp byte [rsi], 0
    je .L417
    inc rdx
    inc rsi
    jmp .L416
.L418:
    mov rdx, 0          ; truncate to 0 on overflow
.L417:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR419]
section .data
.STR419: db 0x20, 0x66, 0x69, 0x62, 0x28, 0x39, 0x29, 0x3d, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L420:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L422
    cmp byte [rsi], 0
    je .L421
    inc rdx
    inc rsi
    jmp .L420
.L422:
    mov rdx, 0          ; truncate to 0 on overflow
.L421:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR423]
section .data
.STR423: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L424:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L426
    cmp byte [rsi], 0
    je .L425
    inc rdx
    inc rsi
    jmp .L424
.L426:
    mov rdx, 0          ; truncate to 0 on overflow
.L425:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR427]
section .data
.STR427: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L428:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L430
    cmp byte [rsi], 0
    je .L429
    inc rdx
    inc rsi
    jmp .L428
.L430:
    mov rdx, 0          ; truncate to 0 on overflow
.L429:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR431]
section .data
.STR431: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x39, 0x3a, 0x20, 0x54, 0x79, 0x70, 0x65, 0x20, 0x43, 0x6f, 0x6e, 0x76, 0x65, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L432:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L434
    cmp byte [rsi], 0
    je .L433
    inc rdx
    inc rsi
    jmp .L432
.L434:
    mov rdx, 0          ; truncate to 0 on overflow
.L433:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 42
    push rax            ; var num
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    push rax            ; var num_str
    lea rax, [rel .STR435]
section .data
.STR435: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x73, 0x74, 0x72, 0x28, 0x34, 0x32, 0x29, 0x20, 0x6c, 0x65, 0x6e, 0x67, 0x74, 0x68, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L436:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L438
    cmp byte [rsi], 0
    je .L437
    inc rdx
    inc rsi
    jmp .L436
.L438:
    mov rdx, 0          ; truncate to 0 on overflow
.L437:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR439]
section .data
.STR439: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L440:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L442
    cmp byte [rsi], 0
    je .L441
    inc rdx
    inc rsi
    jmp .L440
.L442:
    mov rdx, 0          ; truncate to 0 on overflow
.L441:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR443]
section .data
.STR443: db 0x31, 0x32, 0x33, 0x34, 0x35, 0x00
section .text
    push rax            ; var test_str
    ; Builtin function @to_int
    mov rax, [rbp - 216]  ; load test_str
    push rax            ; var parsed
    lea rax, [rel .STR444]
section .data
.STR444: db 0x20, 0x20, 0x2d, 0x20, 0x40, 0x74, 0x6f, 0x5f, 0x69, 0x6e, 0x74, 0x28, 0x27, 0x31, 0x32, 0x33, 0x34, 0x35, 0x27, 0x29, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L445:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L447
    cmp byte [rsi], 0
    je .L446
    inc rdx
    inc rsi
    jmp .L445
.L447:
    mov rdx, 0          ; truncate to 0 on overflow
.L446:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR448]
section .data
.STR448: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L449:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L451
    cmp byte [rsi], 0
    je .L450
    inc rdx
    inc rsi
    jmp .L449
.L451:
    mov rdx, 0          ; truncate to 0 on overflow
.L450:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR452]
section .data
.STR452: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L453:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L455
    cmp byte [rsi], 0
    je .L454
    inc rdx
    inc rsi
    jmp .L453
.L455:
    mov rdx, 0          ; truncate to 0 on overflow
.L454:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR456]
section .data
.STR456: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x30, 0x3a, 0x20, 0x4d, 0x61, 0x70, 0x73, 0x2f, 0x44, 0x69, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x61, 0x72, 0x69, 0x65, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L457:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L459
    cmp byte [rsi], 0
    je .L458
    inc rdx
    inc rsi
    jmp .L457
.L459:
    mov rdx, 0          ; truncate to 0 on overflow
.L458:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov dword [rbp - 440], 16  ; inventory capacity
    mov dword [rbp - 436], 0   ; inventory size
    mov byte [rbp - 420], 0   ; bucket 0 occupied flag
    mov byte [rbp - 407], 0   ; bucket 1 occupied flag
    mov byte [rbp - 394], 0   ; bucket 2 occupied flag
    mov byte [rbp - 381], 0   ; bucket 3 occupied flag
    mov byte [rbp - 368], 0   ; bucket 4 occupied flag
    mov byte [rbp - 355], 0   ; bucket 5 occupied flag
    mov byte [rbp - 342], 0   ; bucket 6 occupied flag
    mov byte [rbp - 329], 0   ; bucket 7 occupied flag
    mov byte [rbp - 316], 0   ; bucket 8 occupied flag
    mov byte [rbp - 303], 0   ; bucket 9 occupied flag
    mov byte [rbp - 290], 0   ; bucket 10 occupied flag
    mov byte [rbp - 277], 0   ; bucket 11 occupied flag
    mov byte [rbp - 264], 0   ; bucket 12 occupied flag
    mov byte [rbp - 251], 0   ; bucket 13 occupied flag
    mov byte [rbp - 238], 0   ; bucket 14 occupied flag
    mov byte [rbp - 225], 0   ; bucket 15 occupied flag
    lea rax, [rel .STR460]
section .data
.STR460: db 0x20, 0x20, 0x2d, 0x20, 0x69, 0x6e, 0x76, 0x65, 0x6e, 0x74, 0x6f, 0x72, 0x79, 0x5b, 0x27, 0x61, 0x70, 0x70, 0x6c, 0x65, 0x73, 0x27, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L461:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L463
    cmp byte [rsi], 0
    je .L462
    inc rdx
    inc rsi
    jmp .L461
.L463:
    mov rdx, 0          ; truncate to 0 on overflow
.L462:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR464]
section .data
.STR464: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L465:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L467
    cmp byte [rsi], 0
    je .L466
    inc rdx
    inc rsi
    jmp .L465
.L467:
    mov rdx, 0          ; truncate to 0 on overflow
.L466:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR468]
section .data
.STR468: db 0x20, 0x20, 0x2d, 0x20, 0x41, 0x66, 0x74, 0x65, 0x72, 0x20, 0x75, 0x70, 0x64, 0x61, 0x74, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L469:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L471
    cmp byte [rsi], 0
    je .L470
    inc rdx
    inc rsi
    jmp .L469
.L471:
    mov rdx, 0          ; truncate to 0 on overflow
.L470:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR472]
section .data
.STR472: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L473:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L475
    cmp byte [rsi], 0
    je .L474
    inc rdx
    inc rsi
    jmp .L473
.L475:
    mov rdx, 0          ; truncate to 0 on overflow
.L474:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR476]
section .data
.STR476: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L477:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L479
    cmp byte [rsi], 0
    je .L478
    inc rdx
    inc rsi
    jmp .L477
.L479:
    mov rdx, 0          ; truncate to 0 on overflow
.L478:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR480]
section .data
.STR480: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x31, 0x3a, 0x20, 0x53, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L481:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L483
    cmp byte [rsi], 0
    je .L482
    inc rdx
    inc rsi
    jmp .L481
.L483:
    mov rdx, 0          ; truncate to 0 on overflow
.L482:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @getpid
    xor rax, rax        ; unsupported process function
    push rax            ; var process_id
    lea rax, [rel .STR484]
section .data
.STR484: db 0x20, 0x20, 0x2d, 0x20, 0x50, 0x72, 0x6f, 0x63, 0x65, 0x73, 0x73, 0x20, 0x49, 0x44, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L485:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L487
    cmp byte [rsi], 0
    je .L486
    inc rdx
    inc rsi
    jmp .L485
.L487:
    mov rdx, 0          ; truncate to 0 on overflow
.L486:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR488]
section .data
.STR488: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L489:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L491
    cmp byte [rsi], 0
    je .L490
    inc rdx
    inc rsi
    jmp .L489
.L491:
    mov rdx, 0          ; truncate to 0 on overflow
.L490:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @getcwd
    xor rax, rax        ; unsupported process function
    push rax            ; var current_dir
    lea rax, [rel .STR492]
section .data
.STR492: db 0x20, 0x20, 0x2d, 0x20, 0x43, 0x75, 0x72, 0x72, 0x65, 0x6e, 0x74, 0x20, 0x64, 0x69, 0x72, 0x65, 0x63, 0x74, 0x6f, 0x72, 0x79, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L493:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L495
    cmp byte [rsi], 0
    je .L494
    inc rdx
    inc rsi
    jmp .L493
.L495:
    mov rdx, 0          ; truncate to 0 on overflow
.L494:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 456]  ; load current_dir
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L496:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L498
    cmp byte [rsi], 0
    je .L497
    inc rdx
    inc rsi
    jmp .L496
.L498:
    mov rdx, 0          ; truncate to 0 on overflow
.L497:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR499]
section .data
.STR499: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L500:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L502
    cmp byte [rsi], 0
    je .L501
    inc rdx
    inc rsi
    jmp .L500
.L502:
    mov rdx, 0          ; truncate to 0 on overflow
.L501:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @getenv
    xor rax, rax        ; unsupported process function
    push rax            ; var path_var
    xor rax, rax        ; unknown builtin - return 0
    push rax
    mov rax, 0
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    test rax, rax       ; test condition
    jz .L503             ; if false, jump to false_expr
    mov rax, 1
    jmp .L504            ; skip false_expr
.L503:
    mov rax, 0
.L504:
    push rax            ; var path_exists
    lea rax, [rel .STR505]
section .data
.STR505: db 0x20, 0x20, 0x2d, 0x20, 0x50, 0x41, 0x54, 0x48, 0x20, 0x65, 0x6e, 0x76, 0x69, 0x72, 0x6f, 0x6e, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x76, 0x61, 0x72, 0x69, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x65, 0x78, 0x69, 0x73, 0x74, 0x73, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L506:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L508
    cmp byte [rsi], 0
    je .L507
    inc rdx
    inc rsi
    jmp .L506
.L508:
    mov rdx, 0          ; truncate to 0 on overflow
.L507:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 472]  ; load path_exists
    test rax, rax       ; test condition
    jz .L509             ; if false, jump to false_expr
    lea rax, [rel .STR511]
section .data
.STR511: db 0x79, 0x65, 0x73, 0x00
section .text
    jmp .L510            ; skip false_expr
.L509:
    lea rax, [rel .STR512]
section .data
.STR512: db 0x6e, 0x6f, 0x00
section .text
.L510:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR513]
section .data
.STR513: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L514:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L516
    cmp byte [rsi], 0
    je .L515
    inc rdx
    inc rsi
    jmp .L514
.L516:
    mov rdx, 0          ; truncate to 0 on overflow
.L515:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR517]
section .data
.STR517: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L518:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L520
    cmp byte [rsi], 0
    je .L519
    inc rdx
    inc rsi
    jmp .L518
.L520:
    mov rdx, 0          ; truncate to 0 on overflow
.L519:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR521]
section .data
.STR521: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x32, 0x3a, 0x20, 0x4c, 0x6f, 0x67, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x6f, 0x72, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L522:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L524
    cmp byte [rsi], 0
    je .L523
    inc rdx
    inc rsi
    jmp .L522
.L524:
    mov rdx, 0          ; truncate to 0 on overflow
.L523:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 1
    push rax            ; var t
    mov rax, 0
    push rax            ; var f
    mov rax, [rbp - 480]  ; load t
    test rax, rax       ; check left operand
    jz .L525             ; if false, skip right
    mov rax, [rbp - 488]  ; load f
    test rax, rax       ; check right operand
    jz .L525             ; if false, result is false
    mov rax, 1          ; both true, result is 1
    jmp .L526
.L525:
    xor rax, rax        ; result is 0
.L526:
    push rax            ; var and_result
    lea rax, [rel .STR527]
section .data
.STR527: db 0x20, 0x20, 0x2d, 0x20, 0x74, 0x72, 0x75, 0x65, 0x20, 0x26, 0x26, 0x20, 0x66, 0x61, 0x6c, 0x73, 0x65, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L528:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L530
    cmp byte [rsi], 0
    je .L529
    inc rdx
    inc rsi
    jmp .L528
.L530:
    mov rdx, 0          ; truncate to 0 on overflow
.L529:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 496]  ; load and_result
    test rax, rax       ; test condition
    jz .L531             ; if false, jump to false_expr
    lea rax, [rel .STR533]
section .data
.STR533: db 0x74, 0x72, 0x75, 0x65, 0x00
section .text
    jmp .L532            ; skip false_expr
.L531:
    lea rax, [rel .STR534]
section .data
.STR534: db 0x66, 0x61, 0x6c, 0x73, 0x65, 0x00
section .text
.L532:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR535]
section .data
.STR535: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L536:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L538
    cmp byte [rsi], 0
    je .L537
    inc rdx
    inc rsi
    jmp .L536
.L538:
    mov rdx, 0          ; truncate to 0 on overflow
.L537:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 480]  ; load t
    test rax, rax       ; check left operand
    jnz .L539            ; if true, result is true
    mov rax, [rbp - 488]  ; load f
    test rax, rax       ; check right operand
    jnz .L539            ; if true, result is true
    xor rax, rax        ; both false, result is 0
    jmp .L540
.L539:
    mov rax, 1          ; result is 1
.L540:
    push rax            ; var or_result
    lea rax, [rel .STR541]
section .data
.STR541: db 0x20, 0x20, 0x2d, 0x20, 0x74, 0x72, 0x75, 0x65, 0x20, 0x7c, 0x7c, 0x20, 0x66, 0x61, 0x6c, 0x73, 0x65, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L542:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L544
    cmp byte [rsi], 0
    je .L543
    inc rdx
    inc rsi
    jmp .L542
.L544:
    mov rdx, 0          ; truncate to 0 on overflow
.L543:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 504]  ; load or_result
    test rax, rax       ; test condition
    jz .L545             ; if false, jump to false_expr
    lea rax, [rel .STR547]
section .data
.STR547: db 0x74, 0x72, 0x75, 0x65, 0x00
section .text
    jmp .L546            ; skip false_expr
.L545:
    lea rax, [rel .STR548]
section .data
.STR548: db 0x66, 0x61, 0x6c, 0x73, 0x65, 0x00
section .text
.L546:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR549]
section .data
.STR549: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L550:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L552
    cmp byte [rsi], 0
    je .L551
    inc rdx
    inc rsi
    jmp .L550
.L552:
    mov rdx, 0          ; truncate to 0 on overflow
.L551:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR553]
section .data
.STR553: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L554:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L556
    cmp byte [rsi], 0
    je .L555
    inc rdx
    inc rsi
    jmp .L554
.L556:
    mov rdx, 0          ; truncate to 0 on overflow
.L555:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR557]
section .data
.STR557: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x33, 0x3a, 0x20, 0x54, 0x65, 0x72, 0x6e, 0x61, 0x72, 0x79, 0x20, 0x4f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x6f, 0x72, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L558:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L560
    cmp byte [rsi], 0
    je .L559
    inc rdx
    inc rsi
    jmp .L558
.L560:
    mov rdx, 0          ; truncate to 0 on overflow
.L559:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 85
    push rax            ; var score
    mov rax, [rbp - 512]  ; load score
    push rax
    mov rax, 80
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    test rax, rax       ; test condition
    jz .L561             ; if false, jump to false_expr
    lea rax, [rel .STR563]
section .data
.STR563: db 0x41, 0x00
section .text
    jmp .L562            ; skip false_expr
.L561:
    mov rax, [rbp - 512]  ; load score
    push rax
    mov rax, 70
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setg al
    movzx rax, al
    test rax, rax       ; test condition
    jz .L564             ; if false, jump to false_expr
    lea rax, [rel .STR566]
section .data
.STR566: db 0x42, 0x00
section .text
    jmp .L565            ; skip false_expr
.L564:
    lea rax, [rel .STR567]
section .data
.STR567: db 0x43, 0x00
section .text
.L565:
.L562:
    push rax            ; var grade
    lea rax, [rel .STR568]
section .data
.STR568: db 0x20, 0x20, 0x2d, 0x20, 0x53, 0x63, 0x6f, 0x72, 0x65, 0x20, 0x38, 0x35, 0x20, 0x67, 0x65, 0x74, 0x73, 0x20, 0x67, 0x72, 0x61, 0x64, 0x65, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L569:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L571
    cmp byte [rsi], 0
    je .L570
    inc rdx
    inc rsi
    jmp .L569
.L571:
    mov rdx, 0          ; truncate to 0 on overflow
.L570:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 520]  ; load grade
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L572:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L574
    cmp byte [rsi], 0
    je .L573
    inc rdx
    inc rsi
    jmp .L572
.L574:
    mov rdx, 0          ; truncate to 0 on overflow
.L573:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR575]
section .data
.STR575: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L576:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L578
    cmp byte [rsi], 0
    je .L577
    inc rdx
    inc rsi
    jmp .L576
.L578:
    mov rdx, 0          ; truncate to 0 on overflow
.L577:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR579]
section .data
.STR579: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L580:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L582
    cmp byte [rsi], 0
    je .L581
    inc rdx
    inc rsi
    jmp .L580
.L582:
    mov rdx, 0          ; truncate to 0 on overflow
.L581:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR583]
section .data
.STR583: db 0x54, 0x45, 0x53, 0x54, 0x20, 0x31, 0x34, 0x3a, 0x20, 0x4c, 0x6f, 0x6f, 0x70, 0x20, 0x43, 0x6f, 0x6e, 0x74, 0x72, 0x6f, 0x6c, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L584:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L586
    cmp byte [rsi], 0
    je .L585
    inc rdx
    inc rsi
    jmp .L584
.L586:
    mov rdx, 0          ; truncate to 0 on overflow
.L585:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    push rax            ; var sum_before_break
    mov rax, 0
    push rax            ; var i
    mov rax, 0
    mov [rbp - 536], rax  ; assign i
.L587:
    mov rax, [rbp - 536]  ; load i
    push rax
    mov rax, 20
    mov rbx, rax
    pop rax
    cmp rax, rbx
    setl al
    movzx rax, al
    cmp rax, 0
    je .L588
    mov rax, [rbp - 536]  ; load i
    push rax
    mov rax, 10
    mov rbx, rax
    pop rax
    cmp rax, rbx
    sete al
    movzx rax, al
    cmp rax, 0
    je .L590
    jmp .L588
    jmp .L591
.L590:
.L591:
    mov rax, [rbp - 528]  ; load sum_before_break
    push rax
    mov rax, [rbp - 536]  ; load i
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_592       ; jump if overflow flag set
    jmp .overflow_done_593
.overflow_592:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_593:
    mov [rbp - 528], rax  ; assign sum_before_break
.L589:
    mov rax, [rbp - 536]  ; load i
    push rax
    mov rax, 1
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_594       ; jump if overflow flag set
    jmp .overflow_done_595
.overflow_594:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_595:
    mov [rbp - 536], rax  ; assign i
    jmp .L587
.L588:
    lea rax, [rel .STR596]
section .data
.STR596: db 0x20, 0x20, 0x2d, 0x20, 0x53, 0x75, 0x6d, 0x20, 0x77, 0x69, 0x74, 0x68, 0x20, 0x62, 0x72, 0x65, 0x61, 0x6b, 0x20, 0x61, 0x74, 0x20, 0x31, 0x30, 0x3a, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L597:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L599
    cmp byte [rsi], 0
    je .L598
    inc rdx
    inc rsi
    jmp .L597
.L599:
    mov rdx, 0          ; truncate to 0 on overflow
.L598:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    ; Builtin function @to_str
    lea rax, [rel .TODO_STR]
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR600]
section .data
.STR600: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L601:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L603
    cmp byte [rsi], 0
    je .L602
    inc rdx
    inc rsi
    jmp .L601
.L603:
    mov rdx, 0          ; truncate to 0 on overflow
.L602:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR604]
section .data
.STR604: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L605:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L607
    cmp byte [rsi], 0
    je .L606
    inc rdx
    inc rsi
    jmp .L605
.L607:
    mov rdx, 0          ; truncate to 0 on overflow
.L606:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR608]
section .data
.STR608: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L609:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L611
    cmp byte [rsi], 0
    je .L610
    inc rdx
    inc rsi
    jmp .L609
.L611:
    mov rdx, 0          ; truncate to 0 on overflow
.L610:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR612]
section .data
.STR612: db 0x20, 0x20, 0x20, 0x41, 0x4c, 0x4c, 0x20, 0x54, 0x45, 0x53, 0x54, 0x53, 0x20, 0x43, 0x4f, 0x4d, 0x50, 0x4c, 0x45, 0x54, 0x45, 0x44, 0x20, 0x53, 0x55, 0x43, 0x43, 0x45, 0x53, 0x53, 0x46, 0x55, 0x4c, 0x4c, 0x59, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L613:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L615
    cmp byte [rsi], 0
    je .L614
    inc rdx
    inc rsi
    jmp .L613
.L615:
    mov rdx, 0          ; truncate to 0 on overflow
.L614:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR616]
section .data
.STR616: db 0x20, 0x20, 0x20, 0x52, 0x61, 0x73, 0x43, 0x6f, 0x64, 0x65, 0x20, 0x64, 0x65, 0x6d, 0x6f, 0x6e, 0x73, 0x74, 0x72, 0x61, 0x74, 0x65, 0x73, 0x3a, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L617:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L619
    cmp byte [rsi], 0
    je .L618
    inc rdx
    inc rsi
    jmp .L617
.L619:
    mov rdx, 0          ; truncate to 0 on overflow
.L618:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR620]
section .data
.STR620: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x4d, 0x65, 0x6d, 0x6f, 0x72, 0x79, 0x20, 0x6d, 0x61, 0x6e, 0x61, 0x67, 0x65, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x28, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x2f, 0x66, 0x72, 0x65, 0x65, 0x2f, 0x70, 0x65, 0x65, 0x6b, 0x2f, 0x70, 0x6f, 0x6b, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L621:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L623
    cmp byte [rsi], 0
    je .L622
    inc rdx
    inc rsi
    jmp .L621
.L623:
    mov rdx, 0          ; truncate to 0 on overflow
.L622:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR624]
section .data
.STR624: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x53, 0x74, 0x72, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x28, 0x63, 0x6f, 0x6e, 0x63, 0x61, 0x74, 0x2f, 0x73, 0x75, 0x62, 0x73, 0x74, 0x72, 0x2f, 0x75, 0x70, 0x70, 0x65, 0x72, 0x2f, 0x6c, 0x6f, 0x77, 0x65, 0x72, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L625:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L627
    cmp byte [rsi], 0
    je .L626
    inc rdx
    inc rsi
    jmp .L625
.L627:
    mov rdx, 0          ; truncate to 0 on overflow
.L626:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR628]
section .data
.STR628: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x4d, 0x61, 0x74, 0x68, 0x65, 0x6d, 0x61, 0x74, 0x69, 0x63, 0x73, 0x20, 0x28, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x6f, 0x72, 0x73, 0x20, 0x2b, 0x20, 0x31, 0x35, 0x2b, 0x20, 0x62, 0x75, 0x69, 0x6c, 0x74, 0x69, 0x6e, 0x73, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L629:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L631
    cmp byte [rsi], 0
    je .L630
    inc rdx
    inc rsi
    jmp .L629
.L631:
    mov rdx, 0          ; truncate to 0 on overflow
.L630:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR632]
section .data
.STR632: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x41, 0x72, 0x72, 0x61, 0x79, 0x73, 0x20, 0x28, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x65, 0x64, 0x20, 0x61, 0x63, 0x63, 0x65, 0x73, 0x73, 0x2c, 0x20, 0x69, 0x74, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L633:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L635
    cmp byte [rsi], 0
    je .L634
    inc rdx
    inc rsi
    jmp .L633
.L635:
    mov rdx, 0          ; truncate to 0 on overflow
.L634:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR636]
section .data
.STR636: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x43, 0x6f, 0x6e, 0x74, 0x72, 0x6f, 0x6c, 0x20, 0x66, 0x6c, 0x6f, 0x77, 0x20, 0x28, 0x69, 0x66, 0x2f, 0x77, 0x68, 0x69, 0x6c, 0x65, 0x2f, 0x6c, 0x6f, 0x6f, 0x70, 0x2f, 0x63, 0x79, 0x63, 0x6c, 0x65, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L637:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L639
    cmp byte [rsi], 0
    je .L638
    inc rdx
    inc rsi
    jmp .L637
.L639:
    mov rdx, 0          ; truncate to 0 on overflow
.L638:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR640]
section .data
.STR640: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x42, 0x69, 0x74, 0x77, 0x69, 0x73, 0x65, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x28, 0x26, 0x20, 0x7c, 0x20, 0x5e, 0x20, 0x3c, 0x3c, 0x20, 0x3e, 0x3e, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L641:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L643
    cmp byte [rsi], 0
    je .L642
    inc rdx
    inc rsi
    jmp .L641
.L643:
    mov rdx, 0          ; truncate to 0 on overflow
.L642:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR644]
section .data
.STR644: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x46, 0x75, 0x6c, 0x6c, 0x20, 0x72, 0x65, 0x63, 0x75, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L645:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L647
    cmp byte [rsi], 0
    je .L646
    inc rdx
    inc rsi
    jmp .L645
.L647:
    mov rdx, 0          ; truncate to 0 on overflow
.L646:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR648]
section .data
.STR648: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x54, 0x79, 0x70, 0x65, 0x20, 0x63, 0x6f, 0x6e, 0x76, 0x65, 0x72, 0x73, 0x69, 0x6f, 0x6e, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L649:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L651
    cmp byte [rsi], 0
    je .L650
    inc rdx
    inc rsi
    jmp .L649
.L651:
    mov rdx, 0          ; truncate to 0 on overflow
.L650:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR652]
section .data
.STR652: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x43, 0x6f, 0x6c, 0x6c, 0x65, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x28, 0x6d, 0x61, 0x70, 0x73, 0x2f, 0x61, 0x72, 0x72, 0x61, 0x79, 0x73, 0x2f, 0x67, 0x72, 0x6f, 0x75, 0x70, 0x73, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L653:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L655
    cmp byte [rsi], 0
    je .L654
    inc rdx
    inc rsi
    jmp .L653
.L655:
    mov rdx, 0          ; truncate to 0 on overflow
.L654:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR656]
section .data
.STR656: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x53, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x20, 0x69, 0x6e, 0x74, 0x65, 0x67, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L657:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L659
    cmp byte [rsi], 0
    je .L658
    inc rdx
    inc rsi
    jmp .L657
.L659:
    mov rdx, 0          ; truncate to 0 on overflow
.L658:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR660]
section .data
.STR660: db 0x20, 0x20, 0x20, 0x2d, 0x20, 0x41, 0x64, 0x76, 0x61, 0x6e, 0x63, 0x65, 0x64, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x6f, 0x72, 0x73, 0x20, 0x28, 0x74, 0x65, 0x72, 0x6e, 0x61, 0x72, 0x79, 0x2c, 0x20, 0x6c, 0x6f, 0x67, 0x69, 0x63, 0x61, 0x6c, 0x29, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L661:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L663
    cmp byte [rsi], 0
    je .L662
    inc rdx
    inc rsi
    jmp .L661
.L663:
    mov rdx, 0          ; truncate to 0 on overflow
.L662:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR664]
section .data
.STR664: db 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x3d, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L665:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L667
    cmp byte [rsi], 0
    je .L666
    inc rdx
    inc rsi
    jmp .L665
.L667:
    mov rdx, 0          ; truncate to 0 on overflow
.L666:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR668]
section .data
.STR668: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L669:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L671
    cmp byte [rsi], 0
    je .L670
    inc rdx
    inc rsi
    jmp .L669
.L671:
    mov rdx, 0          ; truncate to 0 on overflow
.L670:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    add rsp, 536         ; pop 67 block-local variables
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
