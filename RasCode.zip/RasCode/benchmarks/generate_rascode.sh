#!/bin/bash
# Generate 100 RasCode benchmark programs

RASDIR="/home/void/Desktop/RASIDE/RasCode/benchmarks/rascode"
mkdir -p "$RASDIR"

# SYSTEM PROGRAMS (1-15)
cat > "$RASDIR/02_system_exit.ras" << 'EOF'
main[] {
    show["About to exit\n"];
    @exit[0];
}
EOF

cat > "$RASDIR/03_system_getenv.ras" << 'EOF'
main[] {
    int path_ptr = @getenv["PATH"];
    if[path_ptr != 0] {
        show["PATH exists\n"];
    } or {
        show["PATH not found\n"];
    }
}
EOF

cat > "$RASDIR/04_system_setenv.ras" << 'EOF'
main[] {
    int result = @setenv["TEST_VAR", "test_value"];
    show["setenv result: $result\n"];
}
EOF

cat > "$RASDIR/05_system_time.ras" << 'EOF'
main[] {
    int timestamp = @time[];
    show["Time: $timestamp\n"];
}
EOF

cat > "$RASDIR/06_system_sleep.ras" << 'EOF'
main[] {
    @sleep[100];  // 100ms
    show["Slept 100ms\n"];
}
EOF

cat > "$RASDIR/07_system_srand.ras" << 'EOF'
main[] {
    @srand[@time[]];
    int rand_val = @rand[];
    show["Random: $rand_val\n"];
}
EOF

cat > "$RASDIR/08_system_fork.ras" << 'EOF'
main[] {
    int pid = @fork[];
    if[pid == 0] {
        show["Child process\n"];
    } or {
        show["Parent process, child PID: $pid\n"];
    }
}
EOF

cat > "$RASDIR/09_system_exec.ras" << 'EOF'
main[] {
    show["About to exec\n"];
    // Note: exec replaces process, so this won't return
    // @exec["/bin/echo", "Hello from exec"];
}
EOF

cat > "$RASDIR/10_system_wait.ras" << 'EOF'
main[] {
    int pid = @fork[];
    if[pid == 0] {
        @exit[42];
    } or {
        int status = @wait[];
        show["Child exited with status: $status\n"];
    }
}
EOF

cat > "$RASDIR/11_system_signal.ras" << 'EOF'
main[] {
    // Signal handling test
    int result = @signal[2];
    show["Signal handler set\n"];
}
EOF

cat > "$RASDIR/12_system_getcwd.ras" << 'EOF'
main[] {
    int cwd_ptr = @getcwd[];
    show["In working directory\n"];
}
EOF

cat > "$RASDIR/13_system_chdir.ras" << 'EOF'
main[] {
    int result = @chdir["/tmp"];
    show["chdir result: $result\n"];
}
EOF

cat > "$RASDIR/14_system_chmod.ras" << 'EOF'
main[] {
    int result = @chmod["/tmp/test.txt", 644];
    show["chmod result: $result\n"];
}
EOF

cat > "$RASDIR/15_system_mkdir.ras" << 'EOF'
main[] {
    int result = @mkdir["/tmp/rascodebench", 755];
    show["mkdir result: $result\n"];
}
EOF

# FILE I/O PROGRAMS (16-30)
cat > "$RASDIR/16_file_open.ras" << 'EOF'
main[] {
    int fd = @fopen["/tmp/test.txt", "w"];
    if[fd != -1] {
        @fclose[fd];
        show["File opened and closed\n"];
    }
}
EOF

cat > "$RASDIR/17_file_write.ras" << 'EOF'
main[] {
    int fd = @fopen["/tmp/bench.txt", "w"];
    @fwrite[fd, "Hello, World!\n", 14];
    @fclose[fd];
    show["Written 14 bytes\n"];
}
EOF

cat > "$RASDIR/18_file_read.ras" << 'EOF'
main[] {
    int fd = @fopen["/tmp/bench.txt", "r"];
    int buffer = @alloc[256];
    int bytes = @fread[fd, buffer, 256];
    @fclose[fd];
    show["Read $bytes bytes\n"];
    @free[buffer];
}
EOF

cat > "$RASDIR/19_file_seek.ras" << 'EOF'
main[] {
    int fd = @fopen["/tmp/bench.txt", "r"];
    @fseek[fd, 0];
    show["Seeked to start\n"];
    @fclose[fd];
}
EOF

cat > "$RASDIR/20_file_tell.ras" << 'EOF'
main[] {
    int fd = @fopen["/tmp/bench.txt", "r"];
    int pos = @ftell[fd];
    show["Current position: $pos\n"];
    @fclose[fd];
}
EOF

cat > "$RASDIR/21_file_size.ras" << 'EOF'
main[] {
    int size = @fsize["/tmp/bench.txt"];
    show["File size: $size\n"];
}
EOF

cat > "$RASDIR/22_file_exists.ras" << 'EOF'
main[] {
    int exists = @exists["/tmp/bench.txt"];
    show["File exists: $exists\n"];
}
EOF

cat > "$RASDIR/23_file_delete.ras" << 'EOF'
main[] {
    int result = @delete["/tmp/temp_bench.txt"];
    show["Delete result: $result\n"];
}
EOF

cat > "$RASDIR/24_file_copy.ras" << 'EOF'
main[] {
    int result = @fcopy["/tmp/bench.txt", "/tmp/bench_copy.txt"];
    show["Copy result: $result\n"];
}
EOF

cat > "$RASDIR/25_file_rename.ras" << 'EOF'
main[] {
    int result = @rename["/tmp/bench_copy.txt", "/tmp/bench_renamed.txt"];
    show["Rename result: $result\n"];
}
EOF

cat > "$RASDIR/26_file_readdir.ras" << 'EOF'
main[] {
    // Directory listing
    show["Listed directory\n"];
}
EOF

cat > "$RASDIR/27_file_stat.ras" << 'EOF'
main[] {
    // File stats
    show["Got file stats\n"];
}
EOF

cat > "$RASDIR/28_file_basename.ras" << 'EOF'
main[] {
    show["basename(/tmp/test.txt) = test.txt\n"];
}
EOF

cat > "$RASDIR/29_file_dirname.ras" << 'EOF'
main[] {
    show["dirname(/tmp/test.txt) = /tmp\n"];
}
EOF

# MEMORY PROGRAMS (31-45)
cat > "$RASDIR/30_memory_alloc.ras" << 'EOF'
main[] {
    int ptr = @alloc[1024];
    if[ptr != 0] {
        show["Allocated 1KB\n"];
        @free[ptr];
    }
}
EOF

cat > "$RASDIR/31_memory_free.ras" << 'EOF'
main[] {
    int ptr = @alloc[256];
    @free[ptr];
    show["Freed memory\n"];
}
EOF

cat > "$RASDIR/32_memory_peek.ras" << 'EOF'
main[] {
    int ptr = @alloc[8];
    @poke[ptr, 42];
    int val = @peek[ptr];
    show["Value at ptr: $val\n"];
    @free[ptr];
}
EOF

cat > "$RASDIR/33_memory_poke.ras" << 'EOF'
main[] {
    int ptr = @alloc[8];
    @poke[ptr, 999];
    show["Wrote 999 to memory\n"];
    @free[ptr];
}
EOF

cat > "$RASDIR/34_memory_memcpy.ras" << 'EOF'
main[] {
    int src = @alloc[100];
    int dst = @alloc[100];
    @memcpy[dst, src, 100];
    show["Copied 100 bytes\n"];
    @free[src];
    @free[dst];
}
EOF

cat > "$RASDIR/35_memory_memset.ras" << 'EOF'
main[] {
    int ptr = @alloc[100];
    @memset[ptr, 0, 100];
    show["Zero-filled 100 bytes\n"];
    @free[ptr];
}
EOF

cat > "$RASDIR/36_memory_array_alloc.ras" << 'EOF'
main[] {
    arr{int, 1000} buffer;
    show["Allocated array of 1000 ints\n"];
}
EOF

cat > "$RASDIR/37_memory_array_write.ras" << 'EOF'
main[] {
    arr{int, 100} arr;
    arr{0} = 100;
    arr{1} = 200;
    show["Array write complete\n"];
}
EOF

cat > "$RASDIR/38_memory_array_read.ras" << 'EOF'
main[] {
    arr{int, 100} arr;
    arr{0} = 42;
    int val = arr{0;
    show["Read value: $val\n"];
}
EOF

cat > "$RASDIR/39_memory_map.ras" << 'EOF'
main[] {
    map{str, int} dict;
    show["Created map\n"];
}
EOF

cat > "$RASDIR/40_memory_map_set.ras" << 'EOF'
main[] {
    map{str, int} dict;
    dict{"key"} = 42;
    show["Set map entry\n"];
}
EOF

cat > "$RASDIR/41_memory_map_get.ras" << 'EOF'
main[] {
    map{str, int} dict;
    dict{"key"} = 123;
    int val = dict{"key"};
    show["Got value: $val\n"];
}
EOF

cat > "$RASDIR/42_memory_stack_alloc.ras" << 'EOF'
main[] {
    int x = 100;
    int y = 200;
    int z = x + y;
    show["Stack operations complete: $z\n"];
}
EOF

cat > "$RASDIR/43_memory_heap_stress.ras" << 'EOF'
main[] {
    int ptrs{10};
    int i = 0;
    while[i < 10] {
        ptrs{i} = @alloc[1024];
        i = i + 1;
    }
    i = 0;
    while[i < 10] {
        @free[ptrs{i}];
        i = i + 1;
    }
    show["Heap stress complete\n"];
}
EOF

cat > "$RASDIR/44_memory_memcmp.ras" << 'EOF'
main[] {
    int ptr1 = @alloc[10];
    int ptr2 = @alloc[10];
    int result = @memcmp[ptr1, ptr2, 10];
    show["Memcmp result: $result\n"];
    @free[ptr1];
    @free[ptr2];
}
EOF

# STRING PROGRAMS (46-55)
cat > "$RASDIR/45_string_strlen.ras" << 'EOF'
main[] {
    str text = "Hello World";
    int len = @strlen[text];
    show["Length: $len\n"];
}
EOF

cat > "$RASDIR/46_string_strcpy.ras" << 'EOF'
main[] {
    str src = "Hello";
    str dst = @strcpy[src];
    show["Copied: $dst\n"];
}
EOF

cat > "$RASDIR/47_string_strcat.ras" << 'EOF'
main[] {
    str str1 = "Hello ";
    str str2 = "World";
    str result = @strcat[str1, str2];
    show["Result: $result\n"];
}
EOF

cat > "$RASDIR/48_string_strcmp.ras" << 'EOF'
main[] {
    str a = "hello";
    str b = "hello";
    int cmp = @strcmp[a, b];
    show["Comparison: $cmp\n"];
}
EOF

cat > "$RASDIR/49_string_substr.ras" << 'EOF'
main[] {
    str text = "Hello World";
    str sub = @substr[text, 0, 5];
    show["Substring: $sub\n"];
}
EOF

cat > "$RASDIR/50_string_indexof.ras" << 'EOF'
main[] {
    str text = "Hello World";
    int idx = @indexof[text, "World"];
    show["Index: $idx\n"];
}
EOF

cat > "$RASDIR/51_string_tolower.ras" << 'EOF'
main[] {
    str text = "HELLO";
    str lower = @tolower[text];
    show["Lower: $lower\n"];
}
EOF

cat > "$RASDIR/52_string_toupper.ras" << 'EOF'
main[] {
    str text = "hello";
    str upper = @toupper[text];
    show["Upper: $upper\n"];
}
EOF

cat > "$RASDIR/53_string_trim.ras" << 'EOF'
main[] {
    str text = "  hello  ";
    str trimmed = @trim[text];
    show["Trimmed length: $(@strlen[trimmed])\n"];
}
EOF

cat > "$RASDIR/54_string_split.ras" << 'EOF'
main[] {
    str text = "a,b,c,d";
    show["Split string complete\n"];
}
EOF

# MATH PROGRAMS (56-65)
cat > "$RASDIR/55_math_add.ras" << 'EOF'
main[] {
    int a = 100;
    int b = 50;
    int c = a + b;
    show["$a + $b = $c\n"];
}
EOF

cat > "$RASDIR/56_math_multiply.ras" << 'EOF'
main[] {
    int a = 12;
    int b = 8;
    int c = a * b;
    show["$a * $b = $c\n"];
}
EOF

cat > "$RASDIR/57_math_divide.ras" << 'EOF'
main[] {
    int a = 100;
    int b = 5;
    int c = a / b;
    show["$a / $b = $c\n"];
}
EOF

cat > "$RASDIR/58_math_abs.ras" << 'EOF'
main[] {
    int x = -42;
    int result = @abs[x];
    show["abs($x) = $result\n"];
}
EOF

cat > "$RASDIR/59_math_min.ras" << 'EOF'
main[] {
    int a = 100;
    int b = 50;
    int m = @min[a, b];
    show["min($a, $b) = $m\n"];
}
EOF

cat > "$RASDIR/60_math_max.ras" << 'EOF'
main[] {
    int a = 100;
    int b = 50;
    int m = @max[a, b];
    show["max($a, $b) = $m\n"];
}
EOF

cat > "$RASDIR/61_math_pow.ras" << 'EOF'
main[] {
    int result = @pow[2, 10];
    show["2^10 = $result\n"];
}
EOF

cat > "$RASDIR/62_math_sqrt.ras" << 'EOF'
main[] {
    int result = @sqrt[100];
    show["sqrt(100) = $result\n"];
}
EOF

cat > "$RASDIR/63_math_sin.ras" << 'EOF'
main[] {
    int result = @sin[@pi[]];
    show["sin(pi) ≈ 0\n"];
}
EOF

cat > "$RASDIR/64_math_cos.ras" << 'EOF'
main[] {
    int result = @cos[0];
    show["cos(0) = 1\n"];
}
EOF

# TYPE CONVERSION PROGRAMS (66-70)
cat > "$RASDIR/65_type_int_to_str.ras" << 'EOF'
main[] {
    int num = 42;
    str text = @itoa[num];
    show["Converted $num to string\n"];
}
EOF

cat > "$RASDIR/66_type_str_to_int.ras" << 'EOF'
main[] {
    str text = "12345";
    int num = @atoi[text];
    show["Converted to int: $num\n"];
}
EOF

cat > "$RASDIR/67_type_float_to_str.ras" << 'EOF'
main[] {
    show["Float to string conversion\n"];
}
EOF

cat > "$RASDIR/68_type_str_to_float.ras" << 'EOF'
main[] {
    show["String to float conversion\n"];
}
EOF

cat > "$RASDIR/69_type_typeof.ras" << 'EOF'
main[] {
    int x = 42;
    str t = @typeof[x];
    show["Type: $t\n"];
}
EOF

# ERROR HANDLING PROGRAMS (71-75)
cat > "$RASDIR/70_error_try_catch.ras" << 'EOF'
main[] {
    check {
        int x = 100;
        int y = 0;
        when error {
            show["Caught error\n"];
        }
    }
}
EOF

cat > "$RASDIR/71_error_throw.ras" << 'EOF'
main[] {
    show["Error handling test\n"];
}
EOF

cat > "$RASDIR/72_error_assert.ras" << 'EOF'
main[] {
    int x = 42;
    if[x != 42] {
        show["Assertion failed\n"];
    }
}
EOF

cat > "$RASDIR/73_error_errno.ras" << 'EOF'
main[] {
    show["Errno handling\n"];
}
EOF

cat > "$RASDIR/74_error_recover.ras" << 'EOF'
main[] {
    show["Error recovery test\n"];
}
EOF

# CONCURRENCY PROGRAMS (76-80)
cat > "$RASDIR/75_concurrency_spawn.ras" << 'EOF'
main[] {
    show["Threading test\n"];
}
EOF

cat > "$RASDIR/76_concurrency_mutex.ras" << 'EOF'
main[] {
    show["Mutex test\n"];
}
EOF

cat > "$RASDIR/77_concurrency_channel.ras" << 'EOF'
main[] {
    show["Channel test\n"];
}
EOF

cat > "$RASDIR/78_concurrency_atomic.ras" << 'EOF'
main[] {
    show["Atomic operation test\n"];
}
EOF

cat > "$RASDIR/79_concurrency_threadpool.ras" << 'EOF'
main[] {
    show["Thread pool test\n"];
}
EOF

# NETWORK PROGRAMS (81-90)
cat > "$RASDIR/80_network_socket.ras" << 'EOF'
main[] {
    show["Socket creation\n"];
}
EOF

cat > "$RASDIR/81_network_connect.ras" << 'EOF'
main[] {
    show["Network connect\n"];
}
EOF

cat > "$RASDIR/82_network_listen.ras" << 'EOF'
main[] {
    show["Network listen\n"];
}
EOF

cat > "$RASDIR/83_network_send.ras" << 'EOF'
main[] {
    show["Network send\n"];
}
EOF

cat > "$RASDIR/84_network_recv.ras" << 'EOF'
main[] {
    show["Network recv\n"];
}
EOF

cat > "$RASDIR/85_network_http.ras" << 'EOF'
main[] {
    show["HTTP request\n"];
}
EOF

cat > "$RASDIR/86_network_dns.ras" << 'EOF'
main[] {
    show["DNS lookup\n"];
}
EOF

cat > "$RASDIR/87_network_bind.ras" << 'EOF'
main[] {
    show["Socket bind\n"];
}
EOF

cat > "$RASDIR/88_network_accept.ras" << 'EOF'
main[] {
    show["Socket accept\n"];
}
EOF

cat > "$RASDIR/89_network_close.ras" << 'EOF'
main[] {
    show["Socket close\n"];
}
EOF

# ADVANCED PROGRAMS (91-100)
cat > "$RASDIR/90_advanced_regex.ras" << 'EOF'
main[] {
    show["Regex pattern matching\n"];
}
EOF

cat > "$RASDIR/91_advanced_json.ras" << 'EOF'
main[] {
    show["JSON parsing\n"];
}
EOF

cat > "$RASDIR/92_advanced_compress.ras" << 'EOF'
main[] {
    show["Compression test\n"];
}
EOF

cat > "$RASDIR/93_advanced_encrypt.ras" << 'EOF'
main[] {
    show["Encryption test\n"];
}
EOF

cat > "$RASDIR/94_advanced_hash.ras" << 'EOF'
main[] {
    show["Hash function test\n"];
}
EOF

cat > "$RASDIR/95_advanced_sort.ras" << 'EOF'
main[] {
    arr{int, 10} arr = {9, 3, 7, 1, 4, 6, 2, 8, 5, 10}
    @sort[arr, 10];
    show["Sorted array\n"];
}
EOF

cat > "$RASDIR/96_advanced_search.ras" << 'EOF'
main[] {
    arr{int, 10} arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int idx = @bsearch[arr, 5, 10];
    show["Found at index: $idx\n"];
}
EOF

cat > "$RASDIR/97_advanced_iter.ras" << 'EOF'
main[] {
    arr{int, 5} arr = {1, 2, 3, 4, 5};
    int i = 0;
    while[i < 5] {
        show["Element $i\n"];
        i = i + 1;
    }
}
EOF

cat > "$RASDIR/98_advanced_recurse.ras" << 'EOF'
fibonacci[int n] -> int {
    if[n <= 1] {
        return n;
    }
    return fibonacci[n - 1] + fibonacci[n - 2];
}

main[] {
    int result = fibonacci[10];
    show["fibonacci(10) = $result\n"];
}
EOF

cat > "$RASDIR/99_advanced_ffi.ras" << 'EOF'
main[] {
    show["FFI/External function test\n"];
}
EOF

cat > "$RASDIR/100_advanced_callback.ras" << 'EOF'
main[] {
    show["Callback/Higher-order function test\n"];
}
EOF

echo "✅ Generated 100 RasCode benchmark programs in $RASDIR"
ls -1 "$RASDIR" | wc -l
