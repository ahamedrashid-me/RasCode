#!/bin/bash
# Benchmark runner - compiles and runs all RasCode programs

RASCOM="/home/void/Desktop/RASIDE/RasCode/rascom"
RASDIR="/home/void/Desktop/RASIDE/RasCode/benchmarks/rascode"
OUTDIR="/home/void/Desktop/RASIDE/RasCode/benchmarks/results"
mkdir -p "$OUTDIR"

echo "🔥 RasCode Benchmark Suite - Testing All 100 Programs"
echo "======================================================"
echo ""

TOTAL=0
PASSED=0
FAILED=0

for rasfile in "$RASDIR"/*.ras; do
    filename=$(basename "$rasfile")
    # Skip the original first one since it was corrected
    if [ "$filename" == "01_system_getpid.ras" ]; then
        # Check if corrected (has fnc keyword)
        if ! grep -q "fnc main" "$rasfile"; then
            continue
        fi
    fi
    
    TOTAL=$((TOTAL + 1))
    
    outfile="$OUTDIR/${filename%.ras}"
    
    # Compile
    timeout 5 "$RASCOM" "$rasfile" -o "$outfile.exe" >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        # Run compiled program
        timeout 2 "$outfile.exe" > "$outfile.out" 2>&1
        
        if [ $? -eq 0 ] || [ $? -eq 124 ]; then
            PASSED=$((PASSED + 1))
            status="✅"
        else
            FAILED=$((FAILED + 1))
            status="❌"
        fi
    else
        FAILED=$((FAILED + 1))
        status="❌"
    fi
    
    printf "%s %-40s" "$status" "$filename"
    printf " [%3d/%3d]\n" "$PASSED" "$TOTAL"
done

echo ""
echo "======================================================"
echo "Results:"
echo "  ✅ Passed: $PASSED"
echo "  ❌ Failed: $FAILED"
echo "  📊 Total:  $TOTAL"
echo "  🎯 Success Rate: $(( PASSED * 100 / TOTAL ))%"
echo ""
echo "Output files saved to: $OUTDIR"
