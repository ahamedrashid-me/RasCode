use std::thread;

fn main() {
    let mut handles = vec![];
    for _ in 0..4 {
        handles.push(thread::spawn(|| {
            // work
        }));
    }
    for h in handles {
        let _ = h.join();
    }
    println!("Thread pool test");
}
