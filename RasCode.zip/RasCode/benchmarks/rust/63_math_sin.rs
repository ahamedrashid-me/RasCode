fn main() {
    let result = (std::f64::consts::PI).sin();
    println!("sin(pi) ≈ {}", result);
}
