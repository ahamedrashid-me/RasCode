use std::fs::File;

fn main() {
    match File::create("/tmp/test.txt") {
        Ok(_f) => println!("File opened and closed"),
        Err(_) => println!("Error"),
    }
}
