fn main() {
    let mut arr = vec![0i32; 100];
    arr[0] = 42;
    let val = arr[0];
    println!("Read value: {}", val);
}
