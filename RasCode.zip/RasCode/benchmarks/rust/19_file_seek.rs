use std::fs::File;
use std::io::Seek;

fn main() {
    let mut f = File::open("/tmp/bench.txt").unwrap();
    let _ = f.seek(std::io::SeekFrom::Start(0));
    println!("Seeked to start");
}
