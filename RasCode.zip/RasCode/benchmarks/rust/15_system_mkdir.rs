use std::fs;

fn main() {
    let result = fs::create_dir_all("/tmp/rustbench");
    println!("mkdir result: {}", if result.is_ok() { 0 } else { -1 });
}
