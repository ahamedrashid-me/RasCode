use std::fs;

fn main() {
    let result = fs::copy("/tmp/bench.txt", "/tmp/bench_copy.txt");
    println!("Copy result: {}", if result.is_ok() { 0 } else { -1 });
}
