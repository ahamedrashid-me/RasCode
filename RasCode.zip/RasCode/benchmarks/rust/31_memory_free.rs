fn main() {
    let _buffer: Vec<u8> = vec![0; 256];
    drop(_buffer);
    println!("Freed memory");
}
