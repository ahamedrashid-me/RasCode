fn main() {
    let text = "a,b,c,d";
    let _parts: Vec<&str> = text.split(',').collect();
    println!("Split string complete");
}
