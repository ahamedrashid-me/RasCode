fn main() {
    let x: i32 = 42;
    println!("Type: i32");
}
