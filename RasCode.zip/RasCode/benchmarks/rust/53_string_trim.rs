fn main() {
    let text = "  hello  ";
    let trimmed = text.trim();
    println!("Trimmed length: {}", trimmed.len());
}
