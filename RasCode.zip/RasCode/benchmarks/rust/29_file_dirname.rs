use std::path::Path;

fn main() {
    let path = Path::new("/tmp/test.txt");
    let dir = path.parent().unwrap();
    println!("dirname(/tmp/test.txt) = {}", dir.display());
}
