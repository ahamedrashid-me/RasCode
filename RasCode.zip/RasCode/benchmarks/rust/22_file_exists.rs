use std::path::Path;

fn main() {
    let exists = Path::new("/tmp/bench.txt").exists();
    println!("File exists: {}", if exists { 1 } else { 0 });
}
