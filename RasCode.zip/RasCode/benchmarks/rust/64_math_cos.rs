fn main() {
    let result = (0.0_f64).cos();
    println!("cos(0) = {}", result);
}
