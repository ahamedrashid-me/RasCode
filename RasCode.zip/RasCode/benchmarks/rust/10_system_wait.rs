use std::process::Command;

fn main() {
    let mut child = Command::new("echo")
        .arg("hello")
        .spawn()
        .unwrap();
    let status = child.wait().unwrap();
    println!("Child exited with status: {}", status);
}
