fn main() {
    println!("Error recovery test");
}
