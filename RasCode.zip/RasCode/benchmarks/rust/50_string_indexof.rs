fn main() {
    let text = "Hello World";
    let idx = text.find("World").unwrap_or(0);
    println!("Index: {}", idx);
}
