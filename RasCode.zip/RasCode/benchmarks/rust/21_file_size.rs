use std::fs;

fn main() {
    let metadata = fs::metadata("/tmp/bench.txt").unwrap();
    println!("File size: {}", metadata.len());
}
