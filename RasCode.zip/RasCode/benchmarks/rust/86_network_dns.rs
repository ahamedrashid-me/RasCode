use std::net::ToSocketAddrs;

fn main() {
    if let Ok(_addrs) = "localhost:80".to_socket_addrs() {
        println!("DNS lookup");
    }
}
