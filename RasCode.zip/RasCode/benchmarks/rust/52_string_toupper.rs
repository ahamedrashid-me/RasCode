fn main() {
    let text = "hello";
    let upper = text.to_uppercase();
    println!("Upper: {}", upper);
}
