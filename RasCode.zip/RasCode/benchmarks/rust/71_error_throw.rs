fn main() {
    println!("Error handling test");
}
