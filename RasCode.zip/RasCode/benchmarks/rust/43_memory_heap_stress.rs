fn main() {
    let mut ptrs: Vec<Vec<u8>> = Vec::new();
    for _ in 0..10 {
        ptrs.push(vec![0u8; 1024]);
    }
    drop(ptrs);
    println!("Heap stress complete");
}
