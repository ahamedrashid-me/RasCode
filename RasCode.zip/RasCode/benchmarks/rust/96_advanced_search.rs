fn main() {
    let arr = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    if let Ok(idx) = arr.binary_search(&5) {
        println!("Found at index: {}", idx);
    }
}
