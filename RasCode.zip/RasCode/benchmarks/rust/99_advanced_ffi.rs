fn main() {
    println!("FFI/External function test");
}
