use std::fs;

fn main() {
    let contents = fs::read_to_string("/tmp/bench.txt").unwrap_or_default();
    println!("Read {} bytes", contents.len());
}
