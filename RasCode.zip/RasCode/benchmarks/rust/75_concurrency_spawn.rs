use std::thread;

fn main() {
    let _handle = thread::spawn(|| {
        println!("Thread test");
    });
    println!("Threading test");
}
