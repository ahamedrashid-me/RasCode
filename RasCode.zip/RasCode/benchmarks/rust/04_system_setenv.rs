use std::env;

fn main() {
    env::set_var("TEST_VAR", "test_value");
    println!("setenv result: 0");
}
