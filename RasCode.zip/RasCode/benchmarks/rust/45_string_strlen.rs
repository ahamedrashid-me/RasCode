fn main() {
    let text = "Hello World";
    println!("Length: {}", text.len());
}
