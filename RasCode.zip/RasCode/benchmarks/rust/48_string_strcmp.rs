fn main() {
    let a = "hello";
    let b = "hello";
    let cmp = if a == b { 0 } else { 1 };
    println!("Comparison: {}", cmp);
}
