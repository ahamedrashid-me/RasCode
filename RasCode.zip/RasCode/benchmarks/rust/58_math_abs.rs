fn main() {
    let x = -42i32;
    let result = x.abs();
    println!("abs({}) = {}", x, result);
}
