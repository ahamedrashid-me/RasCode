use std::sync::mpsc;

fn main() {
    let (_tx, _rx) = mpsc::channel();
    println!("Channel test");
}
