use std::fs;
use std::os::unix::fs::PermissionsExt;

fn main() {
    let perms = fs::Permissions::from_mode(0o644);
    let result = fs::set_permissions("/tmp/test.txt", perms);
    println!("chmod result: {}", if result.is_ok() { 0 } else { -1 });
}
