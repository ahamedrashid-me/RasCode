fn main() {
    let a = 100;
    let b = 50;
    let c = a + b;
    println!("{} + {} = {}", a, b, c);
}
