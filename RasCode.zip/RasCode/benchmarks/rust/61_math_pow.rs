fn main() {
    let result = 2i32.pow(10);
    println!("2^10 = {}", result);
}
