use std::collections::HashMap;

fn main() {
    let mut dict = HashMap::new();
    dict.insert("key".to_string(), 123);
    let val = dict.get("key").copied().unwrap_or(0);
    println!("Got value: {}", val);
}
