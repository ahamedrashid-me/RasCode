fn main() {
    println!("Encryption test");
}
