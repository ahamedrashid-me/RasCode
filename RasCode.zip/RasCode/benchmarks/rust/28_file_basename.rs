use std::path::Path;

fn main() {
    let path = Path::new("/tmp/test.txt");
    let name = path.file_name().unwrap().to_string_lossy();
    println!("basename(/tmp/test.txt) = {}", name);
}
