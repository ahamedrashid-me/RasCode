fn main() {
    let x = 42;
    assert_eq!(x, 42);
    println!("Assertion passed");
}
