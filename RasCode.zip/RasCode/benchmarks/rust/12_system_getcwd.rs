use std::env;

fn main() {
    let _cwd = env::current_dir().unwrap();
    println!("In working directory");
}
