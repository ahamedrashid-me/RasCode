use std::io::Write;
use std::net::TcpStream;

fn main() {
    if let Ok(mut stream) = TcpStream::connect("127.0.0.1:80") {
        let _ = stream.write_all(b"GET / HTTP/1.0\r\n\r\n");
        println!("Network send");
    }
}
