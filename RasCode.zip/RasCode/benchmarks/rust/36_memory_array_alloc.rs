fn main() {
    let _buffer: Vec<i32> = Vec::with_capacity(1000);
    println!("Allocated array of 1000 ints");
}
