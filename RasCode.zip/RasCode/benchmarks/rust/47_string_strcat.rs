fn main() {
    let str1 = "Hello ";
    let str2 = "World";
    let result = format!("{}{}", str1, str2);
    println!("Result: {}", result);
}
