use std::net::TcpListener;

fn main() {
    if let Ok(_listener) = TcpListener::bind("127.0.0.1:9000") {
        println!("Socket bind");
    }
}
