fn main() {
    let mut buffer = vec![0u64; 1];
    buffer[0] = 999;
    println!("Wrote 999 to memory");
}
