fn main() {
    println!("About to exit");
    std::process::exit(0);
}
