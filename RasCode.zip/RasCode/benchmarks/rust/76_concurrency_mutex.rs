use std::sync::Mutex;

fn main() {
    let _data = Mutex::new(42);
    println!("Mutex test");
}
