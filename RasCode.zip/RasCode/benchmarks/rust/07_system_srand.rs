use rand::Rng;
use std::time::{SystemTime, UNIX_EPOCH};

fn main() {
    let seed = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();
    let mut rng = rand::thread_rng();
    let rand_val: u32 = rng.gen();
    println!("Random: {}", rand_val);
}
