fn main() {
    let a = 100;
    let b = 50;
    let m = a.max(b);
    println!("max({}, {}) = {}", a, b, m);
}
