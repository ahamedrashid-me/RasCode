use std::fs;

fn main() {
    let result = fs::rename("/tmp/bench_copy.txt", "/tmp/bench_renamed.txt");
    println!("Rename result: {}", if result.is_ok() { 0 } else { -1 });
}
