use std::fs;

fn main() {
    let _entries = fs::read_dir("/tmp").ok();
    println!("Listed directory");
}
