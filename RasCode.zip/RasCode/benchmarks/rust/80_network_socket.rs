use std::net::TcpListener;

fn main() {
    if let Ok(_listener) = TcpListener::bind("127.0.0.1:8080") {
        println!("Socket creation");
    }
}
