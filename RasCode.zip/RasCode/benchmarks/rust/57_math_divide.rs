fn main() {
    let a = 100;
    let b = 5;
    let c = a / b;
    println!("{} / {} = {}", a, b, c);
}
