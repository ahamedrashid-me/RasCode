fn main() {
    let text = "Hello World";
    let sub = &text[0..5];
    println!("Substring: {}", sub);
}
