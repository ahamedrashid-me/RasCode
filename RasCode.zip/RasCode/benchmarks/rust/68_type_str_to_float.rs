fn main() {
    let text = "3.14";
    let _f: f64 = text.parse().unwrap();
    println!("String to float conversion");
}
