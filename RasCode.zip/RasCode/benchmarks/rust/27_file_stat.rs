use std::fs;

fn main() {
    let _metadata = fs::metadata("/tmp").ok();
    println!("Got file stats");
}
