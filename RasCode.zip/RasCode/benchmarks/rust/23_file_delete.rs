use std::fs;

fn main() {
    let result = fs::remove_file("/tmp/temp_bench.txt");
    println!("Delete result: {}", if result.is_ok() { 0 } else { -1 });
}
