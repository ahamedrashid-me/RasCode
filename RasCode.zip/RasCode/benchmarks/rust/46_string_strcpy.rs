fn main() {
    let src = "Hello";
    let dst = src.to_string();
    println!("Copied: {}", dst);
}
