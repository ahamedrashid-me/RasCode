fn main() {
    println!("Compression test");
}
