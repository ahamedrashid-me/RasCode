use std::net::TcpStream;

fn main() {
    if TcpStream::connect("127.0.0.1:80").is_ok() {
        println!("Network connect");
    }
}
