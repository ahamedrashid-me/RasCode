fn main() {
    let src = vec![0u8; 100];
    let mut dst = vec![0u8; 100];
    dst.copy_from_slice(&src);
    println!("Copied 100 bytes");
}
