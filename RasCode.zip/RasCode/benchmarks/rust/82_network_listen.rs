use std::net::TcpListener;

fn main() {
    if let Ok(listener) = TcpListener::bind("127.0.0.1:8000") {
        for _ in listener.incoming().take(1) {
            println!("Network listen");
        }
    }
}
