fn main() {
    let _buffer: Vec<u8> = vec![0; 1024];
    println!("Allocated 1KB");
}
