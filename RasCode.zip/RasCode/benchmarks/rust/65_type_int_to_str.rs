fn main() {
    let num = 42;
    let text = num.to_string();
    println!("Converted {} to string", num);
}
