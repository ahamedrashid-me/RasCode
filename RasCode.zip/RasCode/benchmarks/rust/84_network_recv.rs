use std::io::Read;
use std::net::TcpStream;

fn main() {
    if let Ok(mut stream) = TcpStream::connect("127.0.0.1:80") {
        let mut buf = [0u8; 1024];
        if let Ok(_n) = stream.read(&mut buf) {
            println!("Network recv");
        }
    }
}
