fn main() {
    let mut buffer = vec![0u8; 100];
    for i in 0..100 {
        buffer[i] = 0;
    }
    println!("Zero-filled 100 bytes");
}
