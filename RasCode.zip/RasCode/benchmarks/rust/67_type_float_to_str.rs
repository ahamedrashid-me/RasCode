fn main() {
    let f = 3.14;
    let _text = f.to_string();
    println!("Float to string conversion");
}
