fn main() {
    let a = 100;
    let b = 50;
    let m = a.min(b);
    println!("min({}, {}) = {}", a, b, m);
}
