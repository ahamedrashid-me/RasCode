fn main() {
    let f = |x: i32| x * 2;
    let _result = f(21);
    println!("Callback/Higher-order function test");
}
