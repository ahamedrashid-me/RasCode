fn main() {
    let mut buffer = vec![0u64; 1];
    buffer[0] = 42;
    let val = buffer[0];
    println!("Value at ptr: {}", val);
}
