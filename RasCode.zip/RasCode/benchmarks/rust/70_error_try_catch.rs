fn main() {
    match std::panic::catch_unwind(|| {
        let _x = 100;
    }) {
        Ok(_) => println!("Success"),
        Err(_) => println!("Caught error"),
    }
}
