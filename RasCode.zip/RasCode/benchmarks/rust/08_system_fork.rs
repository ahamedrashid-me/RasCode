use std::process::Command;

fn main() {
    // Rust doesn't use fork, use thread instead
    std::thread::spawn(|| {
        println!("Child process");
    });
    println!("Parent process");
}
