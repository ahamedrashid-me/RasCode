fn main() {
    let text = "HELLO";
    let lower = text.to_lowercase();
    println!("Lower: {}", lower);
}
