fn main() {
    let result = (100.0_f64).sqrt() as i32;
    println!("sqrt(100) = {}", result);
}
