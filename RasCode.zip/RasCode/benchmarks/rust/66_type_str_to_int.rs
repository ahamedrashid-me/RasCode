fn main() {
    let text = "12345";
    let num: i32 = text.parse().unwrap();
    println!("Converted to int: {}", num);
}
