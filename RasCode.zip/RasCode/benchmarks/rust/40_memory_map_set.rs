use std::collections::HashMap;

fn main() {
    let mut dict = HashMap::new();
    dict.insert("key".to_string(), 42);
    println!("Set map entry");
}
