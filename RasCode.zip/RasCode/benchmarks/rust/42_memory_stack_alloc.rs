fn main() {
    let x = 100;
    let y = 200;
    let z = x + y;
    println!("Stack operations complete: {}", z);
}
