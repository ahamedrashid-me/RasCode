use std::collections::HashMap;

fn main() {
    let _dict: HashMap<String, i32> = HashMap::new();
    println!("Created map");
}
