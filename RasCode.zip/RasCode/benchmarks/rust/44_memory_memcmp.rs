fn main() {
    let ptr1 = vec![0u8; 10];
    let ptr2 = vec![0u8; 10];
    let result = ptr1 == ptr2;
    println!("Memcmp result: {}", if result { 0 } else { 1 });
}
