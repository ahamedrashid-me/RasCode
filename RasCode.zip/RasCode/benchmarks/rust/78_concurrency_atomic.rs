use std::sync::atomic::{AtomicI32, Ordering};

fn main() {
    let _atomic = AtomicI32::new(0);
    println!("Atomic operation test");
}
