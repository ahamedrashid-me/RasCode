use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};

fn main() {
    let mut hasher = DefaultHasher::new();
    42.hash(&mut hasher);
    let _hash = hasher.finish();
    println!("Hash function test");
}
