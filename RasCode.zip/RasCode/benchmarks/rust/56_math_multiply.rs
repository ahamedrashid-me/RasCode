fn main() {
    let a = 12;
    let b = 8;
    let c = a * b;
    println!("{} * {} = {}", a, b, c);
}
