fn main() {
    println!("Regex pattern matching");
}
