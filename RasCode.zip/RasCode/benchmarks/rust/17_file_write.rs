use std::fs::File;
use std::io::Write;

fn main() {
    let mut f = File::create("/tmp/bench.txt").unwrap();
    f.write_all(b"Hello, World!\n").unwrap();
    println!("Written 14 bytes");
}
