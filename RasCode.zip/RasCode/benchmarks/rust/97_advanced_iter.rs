fn main() {
    let arr = vec![1, 2, 3, 4, 5];
    for (i, elem) in arr.iter().enumerate() {
        println!("Element {}", i);
    }
}
