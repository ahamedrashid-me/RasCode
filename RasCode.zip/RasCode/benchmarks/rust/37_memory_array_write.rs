fn main() {
    let mut arr = vec![0i32; 100];
    arr[0] = 100;
    arr[1] = 200;
    println!("Array write complete");
}
