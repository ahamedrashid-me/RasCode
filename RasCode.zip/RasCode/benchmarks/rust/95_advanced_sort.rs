fn main() {
    let mut arr = vec![9, 3, 7, 1, 4, 6, 2, 8, 5, 10];
    arr.sort();
    println!("Sorted array");
}
