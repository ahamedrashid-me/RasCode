use std::env;

fn main() {
    if let Ok(path) = env::var("PATH") {
        println!("PATH exists");
    } else {
        println!("PATH not found");
    }
}
