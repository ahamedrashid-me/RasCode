use std::fs::File;
use std::io::{Seek, SeekFrom};

fn main() {
    let mut f = File::open("/tmp/bench.txt").unwrap();
    let pos = f.seek(SeekFrom::Current(0)).unwrap();
    println!("Current position: {}", pos);
}
