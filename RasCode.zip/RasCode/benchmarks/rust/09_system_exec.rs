use std::process::Command;

fn main() {
    println!("About to exec");
    // Would replace process with exec
}
