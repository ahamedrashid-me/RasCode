use std::thread;
use std::time::Duration;

fn main() {
    thread::sleep(Duration::from_millis(100));
    println!("Slept 100ms");
}
