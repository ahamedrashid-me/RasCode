use std::env;

fn main() {
    let result = env::set_current_dir("/tmp");
    println!("chdir result: {}", if result.is_ok() { 0 } else { -1 });
}
