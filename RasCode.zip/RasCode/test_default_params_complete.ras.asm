global _start

extern sc_mutex_create, sc_mutex_lock, sc_mutex_unlock, sc_mutex_trylock, sc_mutex_destroy
extern sc_semaphore_create, sc_semaphore_wait, sc_semaphore_signal
extern sc_cond_create, sc_cond_wait, sc_cond_signal, sc_cond_broadcast
extern sc_atomic_cmp_swap, sc_atomic_increment, sc_atomic_decrement
extern sc_channel_create, sc_channel_send, sc_channel_recv, sc_channel_close, sc_channel_empty, sc_channel_full
extern sc_pool_create, sc_pool_submit, sc_pool_wait, sc_pool_destroy
extern sc_socket, sc_connect, sc_bind, sc_listen, sc_accept, sc_send, sc_recv, sc_close
extern sc_fopen, sc_fread, sc_fwrite, sc_fseek, sc_fclose
extern sc_mmap, sc_munmap, sc_mprotect
extern sc_port_in, sc_port_out, sc_ioread, sc_iowrite
extern sc_syscall, sc_irq_enable, sc_irq_disable, sc_verify

section .data
newline: db 10
bounds_msg: db 'Array bounds error!', 10
type_error_msg: db 'Type error!', 10
unimported_func_msg: db 'Unimplemented function!', 10
stack_limit_msg: db 'Recursion depth limit exceeded', 10
stack_warn_msg: db 'Warning: Approaching the recursion limit now', 10
empty_string: db '', 0       ; empty string for uninitialized str variables
g_recursion_depth: dq 0       ; global recursion depth counter (SECURITY)
.heap_start: dq 0             ; stores initial heap brk for @heap_size

section .text

print_int:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov byte [rsi], 10     ; newline
    mov rbx, 10
    test rax, rax
    jns .convert
    neg rax
.convert:
    xor rcx, rcx
.loop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop
    cmp rdi, 0
    jge .print
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    lea rdx, [rcx + 1]     ; length
    syscall
    leave
    ret

print_int_no_newline:
    push rbp
    mov rbp, rsp
    sub rsp, 32
    mov rax, rdi
    lea rsi, [rbp - 1]
    mov rbx, 10
    test rax, rax
    jns .convert_nn
    neg rax
.convert_nn:
    xor rcx, rcx
.loop_nn:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rsi
    mov [rsi], dl
    inc rcx
    test rax, rax
    jnz .loop_nn
    cmp rdi, 0
    jge .print_nn
    dec rsi
    mov byte [rsi], '-'
    inc rcx
.print_nn:
    mov rax, 1             ; sys_write
    mov rdi, 1             ; stdout
    mov rdx, rcx           ; length (no newline)
    syscall
    leave
    ret

print_float:
    push rbp
    mov rbp, rsp
    sub rsp, 64             ; space for buffer and saving xmm0
    movsd [rbp-64], xmm0    ; save original value
    ; Check for negative
    xorpd xmm1, xmm1
    ucomisd xmm0, xmm1
    jae .pf_positive
    ; Print minus sign
    mov byte [rbp-1], '-'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1              ; sys_write
    syscall
    ; Make positive
    movsd xmm1, xmm0
    xorpd xmm0, xmm0
    subsd xmm0, xmm1
    movsd [rbp-64], xmm0    ; save positive value
.pf_positive:
    ; Extract integer part
    cvttsd2si rdi, xmm0     ; convert to int
    call print_int_no_newline
    ; Print decimal point
    mov byte [rbp-1], '.'
    mov rdi, 1
    lea rsi, [rbp-1]
    mov rdx, 1
    mov rax, 1
    syscall
    ; Extract fractional part
    movsd xmm0, [rbp-64]    ; reload positive value
    cvttsd2si rax, xmm0     ; get integer part
    cvtsi2sd xmm1, rax      ; convert back to double
    subsd xmm0, xmm1        ; xmm0 = fractional part
    ; Multiply by 100 for 2 decimal places
    mov rax, 100
    cvtsi2sd xmm1, rax
    mulsd xmm0, xmm1
    cvttsd2si rdi, xmm0     ; convert to int
    ; Pad with zero if needed
    cmp rdi, 10
    jge .pf_print_frac
    ; Print leading zero
    mov byte [rbp-1], '0'
    mov rax, 1
    mov rdx, 1
    push rdi                ; save fraction
    mov rdi, 1
    lea rsi, [rbp-1]
    syscall
    pop rdi                 ; restore fraction
.pf_print_frac:
    call print_int_no_newline
    leave
    ret

strlen:
    push rbp
    mov rbp, rsp
    xor rax, rax            ; counter
.strlen_loop:
    cmp byte [rdi+rax], 0
    je .strlen_done
    inc rax
    jmp .strlen_loop
.strlen_done:
    leave
    ret

strcpy:
    push rbp
    mov rbp, rsp
    mov rax, rdi            ; save dest
.strcpy_loop:
    mov cl, [rsi]
    mov [rdi], cl
    test cl, cl
    jz .strcpy_done
    inc rdi
    inc rsi
    jmp .strcpy_loop
.strcpy_done:
    leave
    ret

strcmp:
    push rbp
    mov rbp, rsp
.strcmp_loop:
    mov al, [rdi]
    mov cl, [rsi]
    cmp al, cl
    jne .strcmp_diff
    test al, al
    jz .strcmp_equal
    inc rdi
    inc rsi
    jmp .strcmp_loop
.strcmp_equal:
    xor rax, rax
    leave
    ret
.strcmp_diff:
    movzx rax, al
    movzx rcx, cl
    sub rax, rcx
    leave
    ret

malloc:
    push rbp
    mov rbp, rsp
    ; Simple bump allocator using brk syscall
    mov rsi, rdi            ; size to allocate
    mov rax, 12             ; sys_brk
    xor rdi, rdi            ; get current brk
    syscall
    mov rbx, rax            ; save current brk
    add rax, rsi            ; new brk = current + size
    mov rdi, rax
    mov rax, 12             ; sys_brk
    syscall
    mov rax, rbx            ; return old brk
    leave
    ret

runtime_type_error:
    mov rdi, 1
    lea rsi, [rel type_error_msg]
    mov rdx, 12
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall

runtime_unimplemented_func:
    mov rdi, 1
    lea rsi, [rel unimported_func_msg]
    mov rdx, 24
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1
    mov rax, 60         ; sys_exit
    syscall



greet:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_0
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_0:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_1
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_1:
    sub rsp, 16         ; allocate space for 2 parameters
    mov [rbp-8], rdi     ; parameter name
    mov [rbp-16], rsi     ; parameter greeting
    mov rax, [rbp - 16]  ; load greeting
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L2:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L4
    cmp byte [rsi], 0
    je .L3
    inc rdx
    inc rsi
    jmp .L2
.L4:
    mov rdx, 0          ; truncate to 0 on overflow
.L3:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR5]
section .data
.STR5: db 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L6:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L8
    cmp byte [rsi], 0
    je .L7
    inc rdx
    inc rsi
    jmp .L6
.L8:
    mov rdx, 0          ; truncate to 0 on overflow
.L7:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, [rbp - 8]  ; load name
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L9:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L11
    cmp byte [rsi], 0
    je .L10
    inc rdx
    inc rsi
    jmp .L9
.L11:
    mov rdx, 0          ; truncate to 0 on overflow
.L10:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR12]
section .data
.STR12: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L13:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L15
    cmp byte [rsi], 0
    je .L14
    inc rdx
    inc rsi
    jmp .L13
.L15:
    mov rdx, 0          ; truncate to 0 on overflow
.L14:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

add:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_16
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_16:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_17
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_17:
    sub rsp, 24         ; allocate space for 3 parameters
    mov [rbp-8], rdi     ; parameter a
    mov [rbp-16], rsi     ; parameter b
    mov [rbp-24], rdx     ; parameter c
    mov rax, [rbp - 8]  ; load a
    push rax
    mov rax, [rbp - 16]  ; load b
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_18       ; jump if overflow flag set
    jmp .overflow_done_19
.overflow_18:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_19:
    push rax
    mov rax, [rbp - 24]  ; load c
    mov rbx, rax
    pop rax
    add rax, rbx
    jo .overflow_20       ; jump if overflow flag set
    jmp .overflow_done_21
.overflow_20:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_21:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

multiply:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_22
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_22:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_23
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_23:
    sub rsp, 24         ; allocate space for 3 parameters
    mov [rbp-8], rdi     ; parameter x
    mov [rbp-16], rsi     ; parameter y
    mov [rbp-24], rdx     ; parameter z
    mov rax, [rbp - 8]  ; load x
    push rax
    mov rax, [rbp - 16]  ; load y
    mov rbx, rax
    pop rax
    imul rax, rbx
    jo .overflow_24       ; jump if overflow flag set
    jmp .overflow_done_25
.overflow_24:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_25:
    push rax
    mov rax, [rbp - 24]  ; load z
    mov rbx, rax
    pop rax
    imul rax, rbx
    jo .overflow_26       ; jump if overflow flag set
    jmp .overflow_done_27
.overflow_26:
    mov rax, -1            ; return -1 to signal overflow
.overflow_done_27:
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

main:
    push rbp
    mov rbp, rsp
    inc qword [rel g_recursion_depth]  ; increment depth counter
    mov rax, [rel g_recursion_depth]
    cmp rax, 1000                       ; MAX_RECURSION_DEPTH
    jle .recursion_ok_28
    dec qword [rel g_recursion_depth]  ; undo increment on error
    mov rdi, 1          ; stderr
    lea rsi, [rel stack_limit_msg]
    mov rdx, 31         ; message length
    mov rax, 1          ; sys_write
    syscall
    mov rdi, 1          ; exit code
    mov rax, 60         ; sys_exit
    syscall
.recursion_ok_28:
    cmp rax, 900         ; STACK_WARN_THRESHOLD
    jle .stack_ok_29
    mov rdi, 2          ; stderr
    lea rsi, [rel stack_warn_msg]
    mov rdx, 45         ; message length
    mov rax, 1          ; sys_write
    syscall
.stack_ok_29:
    lea rax, [rel .STR30]
section .data
.STR30: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x31, 0x3a, 0x20, 0x67, 0x72, 0x65, 0x65, 0x74, 0x20, 0x77, 0x69, 0x74, 0x68, 0x20, 0x62, 0x6f, 0x74, 0x68, 0x20, 0x61, 0x72, 0x67, 0x73, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L31:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L33
    cmp byte [rsi], 0
    je .L32
    inc rdx
    inc rsi
    jmp .L31
.L33:
    mov rdx, 0          ; truncate to 0 on overflow
.L32:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR34]
section .data
.STR34: db 0x41, 0x6c, 0x69, 0x63, 0x65, 0x00
section .text
    push rax            ; save arg 0
    lea rax, [rel .STR35]
section .data
.STR35: db 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x00
section .text
    push rax            ; save arg 1
    pop rsi              ; load arg 1
    pop rdi              ; load arg 0
    call greet
    lea rax, [rel .STR36]
section .data
.STR36: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x32, 0x3a, 0x20, 0x67, 0x72, 0x65, 0x65, 0x74, 0x20, 0x77, 0x69, 0x74, 0x68, 0x20, 0x64, 0x65, 0x66, 0x61, 0x75, 0x6c, 0x74, 0x20, 0x67, 0x72, 0x65, 0x65, 0x74, 0x69, 0x6e, 0x67, 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L37:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L39
    cmp byte [rsi], 0
    je .L38
    inc rdx
    inc rsi
    jmp .L37
.L39:
    mov rdx, 0          ; truncate to 0 on overflow
.L38:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR40]
section .data
.STR40: db 0x42, 0x6f, 0x62, 0x00
section .text
    push rax            ; save arg 0
    lea rax, [rel .STR41]
section .data
.STR41: db 0x48, 0x69, 0x00
section .text
    push rax            ; save arg 1
    pop rsi              ; load arg 1
    pop rdi              ; load arg 0
    call greet
    lea rax, [rel .STR42]
section .data
.STR42: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x33, 0x3a, 0x20, 0x61, 0x64, 0x64, 0x5b, 0x31, 0x30, 0x2c, 0x20, 0x32, 0x30, 0x2c, 0x20, 0x33, 0x30, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L43:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L45
    cmp byte [rsi], 0
    je .L44
    inc rdx
    inc rsi
    jmp .L43
.L45:
    mov rdx, 0          ; truncate to 0 on overflow
.L44:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 10
    push rax            ; save arg 0
    mov rax, 20
    push rax            ; save arg 1
    mov rax, 30
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_46
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call add
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_46
.recursion_limit_46:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_46:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR47]
section .data
.STR47: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L48:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L50
    cmp byte [rsi], 0
    je .L49
    inc rdx
    inc rsi
    jmp .L48
.L50:
    mov rdx, 0          ; truncate to 0 on overflow
.L49:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR51]
section .data
.STR51: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x34, 0x3a, 0x20, 0x61, 0x64, 0x64, 0x5b, 0x31, 0x30, 0x2c, 0x20, 0x32, 0x30, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L52:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L54
    cmp byte [rsi], 0
    je .L53
    inc rdx
    inc rsi
    jmp .L52
.L54:
    mov rdx, 0          ; truncate to 0 on overflow
.L53:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 10
    push rax            ; save arg 0
    mov rax, 20
    push rax            ; save arg 1
    mov rax, 5
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_55
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call add
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_55
.recursion_limit_55:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_55:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR56]
section .data
.STR56: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L57:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L59
    cmp byte [rsi], 0
    je .L58
    inc rdx
    inc rsi
    jmp .L57
.L59:
    mov rdx, 0          ; truncate to 0 on overflow
.L58:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR60]
section .data
.STR60: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x35, 0x3a, 0x20, 0x61, 0x64, 0x64, 0x5b, 0x31, 0x30, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L61:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L63
    cmp byte [rsi], 0
    je .L62
    inc rdx
    inc rsi
    jmp .L61
.L63:
    mov rdx, 0          ; truncate to 0 on overflow
.L62:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 10
    push rax            ; save arg 0
    mov rax, 10
    push rax            ; save arg 1
    mov rax, 5
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_64
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call add
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_64
.recursion_limit_64:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_64:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR65]
section .data
.STR65: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L66:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L68
    cmp byte [rsi], 0
    je .L67
    inc rdx
    inc rsi
    jmp .L66
.L68:
    mov rdx, 0          ; truncate to 0 on overflow
.L67:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR69]
section .data
.STR69: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x36, 0x3a, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x5b, 0x32, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L70:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L72
    cmp byte [rsi], 0
    je .L71
    inc rdx
    inc rsi
    jmp .L70
.L72:
    mov rdx, 0          ; truncate to 0 on overflow
.L71:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 2
    push rax            ; save arg 0
    mov rax, 2
    push rax            ; save arg 1
    mov rax, 3
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_73
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call multiply
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_73
.recursion_limit_73:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_73:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR74]
section .data
.STR74: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L75:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L77
    cmp byte [rsi], 0
    je .L76
    inc rdx
    inc rsi
    jmp .L75
.L77:
    mov rdx, 0          ; truncate to 0 on overflow
.L76:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR78]
section .data
.STR78: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x37, 0x3a, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x5b, 0x33, 0x2c, 0x20, 0x34, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L79:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L81
    cmp byte [rsi], 0
    je .L80
    inc rdx
    inc rsi
    jmp .L79
.L81:
    mov rdx, 0          ; truncate to 0 on overflow
.L80:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 3
    push rax            ; save arg 0
    mov rax, 4
    push rax            ; save arg 1
    mov rax, 3
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_82
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call multiply
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_82
.recursion_limit_82:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_82:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR83]
section .data
.STR83: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L84:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L86
    cmp byte [rsi], 0
    je .L85
    inc rdx
    inc rsi
    jmp .L84
.L86:
    mov rdx, 0          ; truncate to 0 on overflow
.L85:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    lea rax, [rel .STR87]
section .data
.STR87: db 0x54, 0x65, 0x73, 0x74, 0x20, 0x38, 0x3a, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x79, 0x5b, 0x35, 0x2c, 0x20, 0x36, 0x2c, 0x20, 0x37, 0x5d, 0x20, 0x3d, 0x20, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L88:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L90
    cmp byte [rsi], 0
    je .L89
    inc rdx
    inc rsi
    jmp .L88
.L90:
    mov rdx, 0          ; truncate to 0 on overflow
.L89:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 5
    push rax            ; save arg 0
    mov rax, 6
    push rax            ; save arg 1
    mov rax, 7
    push rax            ; save arg 2
    pop rax              ; get arg 2
    mov rdx, rax         ; load arg 2 into register
    pop rax              ; get arg 1
    mov rsi, rax         ; load arg 1 into register
    pop rax              ; get arg 0
    mov rdi, rax         ; load arg 0 into register
    ; Check recursion depth limit (1000 levels max)
    mov rcx, [rel g_recursion_depth]
    cmp rcx, 1000
    jge .recursion_limit_91
    mov rcx, [rel g_recursion_depth]
    inc rcx
    mov [rel g_recursion_depth], rcx
    call multiply
    mov rcx, [rel g_recursion_depth]
    dec rcx
    mov [rel g_recursion_depth], rcx
    jmp .recursion_ok_91
.recursion_limit_91:
    xor rax, rax        ; return 0 on recursion limit
.recursion_ok_91:
    mov rdi, rax
    call print_int_no_newline
    lea rax, [rel .STR92]
section .data
.STR92: db 0x0a, 0x00
section .text
    mov rdi, rax        ; string address
    mov rsi, rax
    xor rdx, rdx        ; length counter
.L93:
    cmp rdx, 1048576    ; MAX_STRING_SIZE (1MB) check
    jge .L95
    cmp byte [rsi], 0
    je .L94
    inc rdx
    inc rsi
    jmp .L93
.L95:
    mov rdx, 0          ; truncate to 0 on overflow
.L94:
    mov rsi, rdi        ; restore string address
    mov rdi, 1          ; stdout
    mov rax, 1          ; sys_write
    syscall
    mov rax, 0
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rsp, rbp
    pop rbp
    ret
    dec qword [rel g_recursion_depth]  ; decrement depth counter
    mov rax, 0
    mov rsp, rbp
    pop rbp
    ret

_start:
    call main
    mov rdi, rax           ; exit code
    mov rax, 60            ; sys_exit
    syscall
